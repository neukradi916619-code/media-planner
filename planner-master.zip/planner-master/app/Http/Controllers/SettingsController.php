<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\Sku;
use App\Services\IndexmClient;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class SettingsController extends Controller
{
    public function index(): Response
    {
        $settings = Setting::allByGroup();
        // Токен в форму не отдаём — только признак, что он задан.
        if (isset($settings['indexm']['indexm_api_token'])) {
            $settings['indexm']['indexm_api_token']['is_set'] = (string) $settings['indexm']['indexm_api_token']['value'] !== '';
            $settings['indexm']['indexm_api_token']['value'] = '';
        }

        return Inertia::render('Settings/Index', ['settings' => $settings]);
    }

    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'settings'   => 'required|array',
            'settings.*' => 'nullable|string|max:1000',
        ]);

        foreach ($data['settings'] as $key => $value) {
            // пустой токен — «не менять»
            if ($key === 'indexm_api_token' && ($value ?? '') === '') {
                continue;
            }
            Setting::set($key, $value ?? '');
        }

        return back()->with('success', 'Настройки сохранены.');
    }

    /** Проверка подключения к indexM ДО сохранения: значения из формы, пустой токен — сохранённый. */
    public function testIndexm(Request $request): JsonResponse
    {
        $url = rtrim((string) $request->input('indexm_url', ''), '/');
        $token = (string) $request->input('indexm_api_token', '') ?: (string) Setting::get('indexm_api_token', '');

        if ($url === '' || $token === '') {
            return response()->json(['ok' => false, 'message' => 'Укажите адрес и токен.']);
        }

        $article = Sku::whereNotNull('article')->value('article') ?? '0';
        try {
            $resp = (new IndexmClient($url, $token))->probe($article);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => 'Не удалось подключиться: '.$e->getMessage()]);
        }

        return response()->json(match (true) {
            $resp->status() === 401 => ['ok' => false, 'message' => 'Неверный или отключённый токен (401).'],
            $resp->successful()     => ['ok' => true, 'message' => "Подключение успешно. Артикул {$article}: "
                .($resp->json('image') ? 'картинка есть.' : 'картинки нет.')],
            $resp->status() === 404 => ['ok' => true, 'message' => "Подключение успешно (артикул {$article} в indexM не найден)."],
            default                 => ['ok' => false, 'message' => "indexM ответил {$resp->status()}: ".($resp->json('message') ?? mb_substr($resp->body(), 0, 200))],
        });
    }
}
