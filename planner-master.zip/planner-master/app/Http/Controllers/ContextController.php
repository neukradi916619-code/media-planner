<?php

namespace App\Http\Controllers;

use App\Models\Collection;
use App\Models\ContextItem;
use App\Models\ContextType;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Календарь контекста (поводы, сезонность, события, лончи). Редактор — всё;
 * БМ — только записи, привязанные к своим коллекциям; общий контекст — редактор.
 */
class ContextController extends Controller
{
    public function index(Request $request): Response
    {
        $user = $request->user();
        return Inertia::render('Context/Index', [
            'items'       => ContextItem::orderBy('start_date')->orderBy('name')->get()
                ->map(fn (ContextItem $i) => $this->present($i) + ['can_edit' => $user->canEditCollection($i->collection_id)]),
            'types'       => ContextType::orderBy('sort_order')->get(['id', 'name', 'color']),
            'collections' => Collection::orderBy('name')->get(['id', 'name', 'color']),
            'editable_collection_ids' => $user->editableCollectionIds(),
            'can_create'  => $user->canWrite(),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validated($request);
        $this->authorizeCollection($request, $data['collection_id'] ?? null);
        $item = ContextItem::create($data);
        return response()->json(['item' => $this->present($item) + ['can_edit' => true]], 201);
    }

    public function update(Request $request, ContextItem $contextItem): JsonResponse
    {
        $this->authorizeCollection($request, $contextItem->collection_id);
        $data = $this->validated($request);
        $this->authorizeCollection($request, $data['collection_id'] ?? null);
        $contextItem->update($data);
        return response()->json(['item' => $this->present($contextItem->fresh()) + ['can_edit' => true]]);
    }

    public function destroy(Request $request, ContextItem $contextItem): JsonResponse
    {
        $this->authorizeCollection($request, $contextItem->collection_id);
        $contextItem->delete();
        return response()->json(['ok' => true]);
    }

    private function authorizeCollection(Request $request, ?int $collectionId): void
    {
        $user = $request->user();
        if (! $user->canEditCollection($collectionId)) {
            abort(403, $user->isBm() ? 'БМ правит только контекст своих коллекций; общий контекст — редактор.' : 'Доступ запрещён.');
        }
    }

    private function validated(Request $request): array
    {
        $data = $request->validate([
            'context_type_id' => 'required|exists:context_types,id',
            'name'            => 'required|string|max:255',
            'start_date'      => 'required|date',
            'end_date'        => 'nullable|date|after_or_equal:start_date',
            'collection_id'   => 'nullable|exists:collections,id',
            'comment'         => 'nullable|string|max:5000',
            'color'           => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'is_active'       => 'boolean',
        ]);
        if (! empty($data['color'])) {
            $data['color'] = strtoupper($data['color']);
        }
        return $data;
    }

    private function present(ContextItem $i): array
    {
        return [
            'id'              => $i->id,
            'context_type_id' => $i->context_type_id,
            'name'            => $i->name,
            'start_date'      => $i->start_date?->format('Y-m-d'),
            'end_date'        => $i->end_date?->format('Y-m-d'),
            'collection_id'   => $i->collection_id,
            'comment'         => $i->comment,
            'color'           => $i->color,
            'is_active'       => $i->is_active,
        ];
    }
}
