<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\ActivityLog;
use App\Models\Block;
use App\Models\Collection;
use App\Models\Direction;
use App\Models\Flight;
use App\Models\Sku;
use App\Models\Status;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Флайты и их активности. Читают все; правят редактор/админ — любые, БМ — флайты своих
 * коллекций (collection_user). Наследование (ЦА, клейм, БМ из коллекции; даты, SKU, ЦА,
 * клейм активности из флайта) считается здесь и на клиенте, в БД — только override.
 */
class FlightController extends Controller
{
    public function index(Request $request): Response
    {
        $user = $request->user();
        $flights = Flight::with(['collection', 'status', 'directions:id,name', 'skus:id,name,article'])
            ->withCount('activities')
            ->orderBy('start_date')->orderBy('name')
            ->get()
            ->map(fn (Flight $f) => $this->summary($f) + ['can_edit' => $user->canEditCollection($f->collection_id)]);

        return Inertia::render('Flights/Index', [
            'flights'    => $flights,
            'can_create' => $user->canWrite(),
        ]);
    }

    public function create(Request $request): Response
    {
        abort_unless($request->user()->canWrite(), 403);
        return Inertia::render('Flights/Edit', ['flight' => null] + $this->dictionaries($request->user()));
    }

    public function show(Request $request, Flight $flight): Response
    {
        $flight->load(['collection', 'status', 'directions:id', 'skus:id', 'activities.skus:id', 'activities.direction:id,name', 'activities.block:id,name']);
        $user = $request->user();

        return Inertia::render('Flights/Edit', [
            'flight' => [
                'id'                => $flight->id,
                'name'              => $flight->name,
                'collection_id'     => $flight->collection_id,
                'start_date'        => $flight->start_date?->format('Y-m-d'),
                'end_date'          => $flight->end_date?->format('Y-m-d'),
                'status_id'         => $flight->status_id,
                'audience_override' => $flight->audience_override,
                'claim_override'    => $flight->claim_override,
                'brief'             => $flight->brief,
                'materials_url'     => $flight->materials_url,
                'comment'           => $flight->comment,
                'direction_ids'     => $flight->directions->pluck('id'),
                'sku_ids'           => $flight->skus->pluck('id'),
                'activities'        => $flight->activities->map(fn (Activity $a) => $this->presentActivity($a)),
                'can_edit'          => $user->canEditCollection($flight->collection_id),
                'history'           => $this->history($flight),
            ],
        ] + $this->dictionaries($user));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);
        $this->authorizeCollection($request->user(), $data['collection_id']);

        $flight = DB::transaction(function () use ($data, $request) {
            $flight = Flight::create($this->attributes($data) + ['created_by' => $request->user()->id]);
            $this->syncRelations($flight, $data);
            return $flight;
        });

        return redirect("/flights/{$flight->id}")->with('success', 'Флайт создан. Добавьте активности.');
    }

    public function update(Request $request, Flight $flight): RedirectResponse
    {
        $this->authorizeCollection($request->user(), $flight->collection_id);
        $data = $this->validated($request, $flight);
        // БМ не может «увести» флайт в чужую коллекцию
        $this->authorizeCollection($request->user(), $data['collection_id']);

        $removed = $flight->directions()->pluck('directions.id')->diff($data['direction_ids'] ?? []);
        if ($removed->isNotEmpty() && ($used = $flight->activities()->whereIn('direction_id', $removed)->with('direction:id,name')->get())->isNotEmpty()) {
            throw ValidationException::withMessages([
                'direction_ids' => 'Нельзя снять направление, по которому есть активности: '
                    .$used->pluck('direction.name')->unique()->join(', ').'.',
            ]);
        }

        DB::transaction(function () use ($flight, $data) {
            $flight->update($this->attributes($data));
            $this->syncRelations($flight, $data);
        });

        return back()->with('success', 'Флайт сохранён.');
    }

    public function destroy(Request $request, Flight $flight): RedirectResponse
    {
        $this->authorizeCollection($request->user(), $flight->collection_id);
        $name = $flight->name;
        $flight->delete();
        return redirect('/flights')->with('success', "Флайт «{$name}» удалён.");
    }

    // ── Активности (JSON, правятся на странице флайта) ───────────────────────

    public function storeActivity(Request $request, Flight $flight): JsonResponse
    {
        $this->authorizeCollection($request->user(), $flight->collection_id);
        $data = $this->validatedActivity($request, $flight);

        $activity = DB::transaction(function () use ($flight, $data) {
            $activity = $flight->activities()->create(
                collect($data)->except('sku_ids')->all() + ['sort_order' => (int) $flight->activities()->max('sort_order') + 1]
            );
            $this->syncSkus($activity->skus(), $data['sku_ids'] ?? []);
            return $activity;
        });

        return response()->json(['activity' => $this->presentActivity($activity->fresh(['skus:id', 'direction:id,name', 'block:id,name']))], 201);
    }

    public function updateActivity(Request $request, Activity $activity): JsonResponse
    {
        $flight = $activity->flight;
        $this->authorizeCollection($request->user(), $flight->collection_id);
        $data = $this->validatedActivity($request, $flight);

        DB::transaction(function () use ($activity, $data) {
            $activity->update(collect($data)->except('sku_ids')->all());
            $this->syncSkus($activity->skus(), $data['sku_ids'] ?? []);
        });

        return response()->json(['activity' => $this->presentActivity($activity->fresh(['skus:id', 'direction:id,name', 'block:id,name']))]);
    }

    public function destroyActivity(Request $request, Activity $activity): JsonResponse
    {
        $this->authorizeCollection($request->user(), $activity->flight->collection_id);
        $activity->delete();
        return response()->json(['ok' => true]);
    }

    // ── Внутреннее ───────────────────────────────────────────────────────────

    private function authorizeCollection(User $user, ?int $collectionId): void
    {
        if (! $user->canEditCollection($collectionId)) {
            abort(403, $user->isBm() ? 'Можно править только флайты своих коллекций.' : 'Доступ запрещён.');
        }
    }

    private function validated(Request $request, ?Flight $flight = null): array
    {
        $data = $request->validate([
            // название уникально: таймлайн связывает активности с флайтом по названию
            'name'              => ['required', 'string', 'max:255', Rule::unique('flights', 'name')->ignore($flight?->id)],
            'collection_id'     => 'required|exists:collections,id',
            'start_date'        => 'required|date',
            'end_date'          => 'required|date|after_or_equal:start_date',
            'status_id'         => 'required|exists:statuses,id',
            'audience_override' => 'nullable|string|max:2000',
            'claim_override'    => 'nullable|string|max:2000',
            'brief'             => 'nullable|string|max:10000',
            'materials_url'     => 'nullable|string|max:2000',
            'comment'           => 'nullable|string|max:5000',
            'direction_ids'     => 'array',
            'direction_ids.*'   => 'integer|exists:directions,id',
            'sku_ids'           => 'array',
            'sku_ids.*'         => 'integer|exists:skus,id',
        ], ['name.unique' => 'Флайт с таким названием уже есть.'], ['end_date' => 'дата окончания', 'start_date' => 'дата начала']);

        // SKU — только из коллекции флайта (как multiselect в таблице)
        $foreign = Sku::whereIn('id', $data['sku_ids'] ?? [])->where(fn ($q) => $q->where('collection_id', '!=', $data['collection_id'])->orWhereNull('collection_id'))->pluck('name');
        if ($foreign->isNotEmpty()) {
            throw ValidationException::withMessages(['sku_ids' => 'SKU не из коллекции флайта: '.$foreign->join('; ')]);
        }
        return $data;
    }

    private function attributes(array $data): array
    {
        return collect($data)->except(['direction_ids', 'sku_ids'])->all();
    }

    private function syncRelations(Flight $flight, array $data): void
    {
        $flight->directions()->sync($data['direction_ids'] ?? []);
        $this->syncSkus($flight->skus(), $data['sku_ids'] ?? []);
    }

    private function syncSkus($relation, array $ids): void
    {
        $relation->sync(collect(array_values(array_unique($ids)))->mapWithKeys(fn ($id, $i) => [$id => ['position' => $i]])->all());
    }

    private function validatedActivity(Request $request, Flight $flight): array
    {
        $data = $request->validate([
            'direction_id'      => ['required', Rule::in($flight->directions()->pluck('directions.id')->all())],
            'block_id'          => ['nullable', Rule::exists('blocks', 'id')->where('direction_id', $request->input('direction_id'))],
            'start_date'        => 'nullable|date',
            'end_date'          => 'nullable|date',
            'platforms'         => 'nullable|string|max:2000',
            'format'            => 'nullable|string|max:2000',
            'audience_override' => 'nullable|string|max:2000',
            'claim_override'    => 'nullable|string|max:2000',
            'materials_url'     => 'nullable|string|max:2000',
            'special_doc_url'   => 'nullable|string|max:2000',
            'comment'           => 'nullable|string|max:5000',
            'sku_ids'           => 'array',
            'sku_ids.*'         => ['integer', Rule::exists('skus', 'id')->where('collection_id', $flight->collection_id)],
        ], [
            'direction_id.in' => 'Направление должно быть отмечено во флайте.',
            'block_id.exists' => 'Блок не относится к выбранному направлению.',
            'sku_ids.*.exists' => 'SKU должен быть из коллекции флайта.',
        ]);

        $start = $data['start_date'] ?? $flight->start_date?->format('Y-m-d');
        $end = $data['end_date'] ?? $flight->end_date?->format('Y-m-d');
        if ($start && $end && $end < $start) {
            throw ValidationException::withMessages(['end_date' => 'Дата окончания раньше даты начала.']);
        }
        return $data;
    }

    private function presentActivity(Activity $a): array
    {
        return [
            'id'                => $a->id,
            'direction_id'      => $a->direction_id,
            'block_id'          => $a->block_id,
            'start_date'        => $a->start_date?->format('Y-m-d'),
            'end_date'          => $a->end_date?->format('Y-m-d'),
            'platforms'         => $a->platforms,
            'format'            => $a->format,
            'audience_override' => $a->audience_override,
            'claim_override'    => $a->claim_override,
            'materials_url'     => $a->materials_url,
            'special_doc_url'   => $a->special_doc_url,
            'comment'           => $a->comment,
            'sku_ids'           => $a->skus->pluck('id'),
        ];
    }

    private function summary(Flight $f): array
    {
        return [
            'id'               => $f->id,
            'name'             => $f->name,
            'collection'       => $f->collection?->only('id', 'name', 'color'),
            'bm'               => $f->collection?->bm_name,
            'start_date'       => $f->start_date?->format('Y-m-d'),
            'end_date'         => $f->end_date?->format('Y-m-d'),
            'status'           => $f->status?->only('id', 'name', 'behavior', 'color'),
            'audience'         => $f->audience(),
            'claim'            => $f->claim(),
            'directions'       => $f->directions->pluck('name'),
            'skus'             => $f->skus->map->only('id', 'name', 'article'),
            'activities_count' => $f->activities_count,
        ];
    }

    /** Справочники для формы. БМ видит в выборе коллекции только свои. */
    private function dictionaries(User $user): array
    {
        $editable = $user->editableCollectionIds();
        return [
            'collections' => Collection::orderBy('name')->get(['id', 'name', 'color', 'bm_name', 'default_audience', 'default_claim', 'is_active'])
                ->map(fn ($c) => $c->toArray() + ['editable' => $editable === null || in_array($c->id, $editable, true)]),
            'statuses'    => Status::orderBy('sort_order')->get(['id', 'name', 'behavior', 'color']),
            'directions'  => Direction::orderBy('sort_order')->get(['id', 'name', 'is_active']),
            'blocks'      => Block::orderBy('sort_order')->get(['id', 'direction_id', 'name', 'is_active']),
            'skus'        => Sku::orderBy('name')->get(['id', 'collection_id', 'name', 'article', 'is_active']),
        ];
    }

    /** Последние изменения флайта и его активностей. */
    private function history(Flight $flight): array
    {
        $activityIds = $flight->activities->pluck('id');
        return ActivityLog::with('user:id,name')
            ->where(fn ($q) => $q->where(fn ($w) => $w->where('entity_type', 'Flight')->where('entity_id', $flight->id))
                ->orWhere(fn ($w) => $w->where('entity_type', 'Activity')->whereIn('entity_id', $activityIds)))
            ->latest('created_at')->limit(30)->get()
            ->map(fn ($l) => [
                'at'     => $l->created_at?->toIso8601String(),
                'user'   => $l->user?->name,
                'entity' => $l->entity_type === 'Flight' ? 'флайт' : 'активность',
                'action' => $l->action,
                'fields' => collect($l->changes ?? [])->pluck('field')->all(),
            ])->all();
    }
}
