<?php

namespace App\Http\Controllers;

use App\Models\Collection;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Inertia\Inertia;
use Inertia\Response;

/** Пользователи Planner — только admin. У БМ — список коллекций, которые он правит. */
class UserController extends Controller
{
    public function index(): Response
    {
        return Inertia::render('Users/Index', [
            'users'       => User::with('collections:id')->orderBy('name')->get()->map(fn (User $u) => [
                'id'             => $u->id,
                'name'           => $u->name,
                'email'          => $u->email,
                'role'           => $u->role,
                'collection_ids' => $u->collections->pluck('id'),
            ]),
            'collections' => Collection::orderBy('name')->get(['id', 'name', 'bm_name', 'color']),
            'roles'       => User::ROLES,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);
        $user = User::create($data);
        $user->collections()->sync($data['role'] === 'bm' ? ($data['collection_ids'] ?? []) : []);

        return back()->with('success', "Пользователь {$user->name} создан.");
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        $data = $this->validated($request, $user);

        if ($user->id === auth()->id() && $data['role'] !== 'admin') {
            return back()->withErrors(['role' => 'Нельзя понизить свою роль.']);
        }
        if (empty($data['password'])) {
            unset($data['password']);
        }
        $user->update($data);
        $user->collections()->sync($data['role'] === 'bm' ? ($data['collection_ids'] ?? []) : []);

        return back()->with('success', "Пользователь {$user->name} сохранён.");
    }

    public function destroy(User $user): RedirectResponse
    {
        abort_if($user->id === auth()->id(), 403, 'Нельзя удалить себя.');

        $name = $user->name;
        $user->delete();

        return back()->with('success', "Пользователь {$name} удалён.");
    }

    private function validated(Request $request, ?User $user = null): array
    {
        return $request->validate([
            'name'             => 'required|string|max:255',
            'email'            => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user?->id)],
            'password'         => [$user ? 'nullable' : 'required', Password::min(8)],
            'role'             => ['required', Rule::in(array_keys(User::ROLES))],
            'collection_ids'   => 'array',
            'collection_ids.*' => 'integer|exists:collections,id',
        ]);
    }
}
