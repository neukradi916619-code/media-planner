<?php

namespace App\Http\Controllers;

use App\Models\Block;
use App\Models\Collection;
use App\Models\ContextType;
use App\Models\Direction;
use App\Models\Sku;
use App\Models\Status;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Справочники Planner — одна страница с вкладками. Читают все, правят editor и admin.
 * Запись — JSON (страница сама обновляет строку, без перезагрузки 750 SKU).
 */
class ReferencesController extends Controller
{
    private const MODELS = [
        'collections'   => Collection::class,
        'skus'          => Sku::class,
        'directions'    => Direction::class,
        'blocks'        => Block::class,
        'statuses'      => Status::class,
        'context-types' => ContextType::class,
    ];

    public function index(): Response
    {
        return Inertia::render('References/Index', [
            'collections'  => Collection::withCount(['skus', 'flights'])->orderBy('name')->get(),
            'skus'         => Sku::orderBy('name')->get(['id', 'collection_id', 'name', 'article', 'is_active']),
            'directions'   => Direction::withCount('blocks')->orderBy('sort_order')->orderBy('name')->get(),
            'blocks'       => Block::orderBy('sort_order')->orderBy('name')->get(),
            'statuses'     => Status::orderBy('sort_order')->get(),
            'contextTypes' => ContextType::orderBy('sort_order')->get(),
            'behaviors'    => Status::BEHAVIORS,
        ]);
    }

    public function store(Request $request, string $type): JsonResponse
    {
        $class = $this->model($type);
        $item = $class::create($this->validated($request, $type));
        return response()->json(['item' => $this->present($type, $item->fresh())], 201);
    }

    public function update(Request $request, string $type, int $id): JsonResponse
    {
        $item = $this->model($type)::findOrFail($id);
        $item->update($this->validated($request, $type, $item));
        return response()->json(['item' => $this->present($type, $item->fresh())]);
    }

    public function destroy(string $type, int $id): JsonResponse
    {
        $item = $this->model($type)::findOrFail($id);
        if ($reason = $this->inUse($type, $item)) {
            return response()->json(['message' => "Нельзя удалить: {$reason}. Снимите отметку «активно» вместо удаления."], 422);
        }
        $item->delete();
        return response()->json(['ok' => true]);
    }

    /** @return class-string<Model> */
    private function model(string $type): string
    {
        abort_unless(isset(self::MODELS[$type]), 404);
        return self::MODELS[$type];
    }

    private function validated(Request $request, string $type, ?Model $item = null): array
    {
        $unique = fn (string $table) => Rule::unique($table, 'name')->ignore($item?->id);
        $color = ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'];

        $data = $request->validate(match ($type) {
            'collections' => [
                'name'             => ['required', 'string', 'max:255', $unique('collections')],
                'color'            => $color,
                'bm_name'          => 'nullable|string|max:255',
                'default_audience' => 'nullable|string|max:2000',
                'default_claim'    => 'nullable|string|max:2000',
                'is_active'        => 'boolean',
            ],
            'skus' => [
                'collection_id' => 'nullable|exists:collections,id',
                'name'          => 'required|string|max:500',
                'article'       => 'nullable|string|max:50',
                'is_active'     => 'boolean',
            ],
            'directions' => [
                'name'       => ['required', 'string', 'max:255', $unique('directions')],
                'sort_order' => 'nullable|integer|min:0',
                'is_active'  => 'boolean',
            ],
            'blocks' => [
                'direction_id' => 'required|exists:directions,id',
                'name'         => ['required', 'string', 'max:255',
                    Rule::unique('blocks')->where('direction_id', $request->input('direction_id'))->ignore($item?->id)],
                'sort_order'   => 'nullable|integer|min:0',
                'is_active'    => 'boolean',
            ],
            'statuses' => [
                'name'        => ['required', 'string', 'max:255', $unique('statuses')],
                'behavior'    => ['required', Rule::in(array_keys(Status::BEHAVIORS))],
                'color'       => $color,
                'description' => 'nullable|string|max:255',
                'sort_order'  => 'nullable|integer|min:0',
            ],
            'context-types' => [
                'name'       => ['required', 'string', 'max:255', $unique('context_types')],
                'color'      => $color,
                'sort_order' => 'nullable|integer|min:0',
            ],
        });

        if (array_key_exists('color', $data) && $data['color']) {
            $data['color'] = strtoupper($data['color']);
        }
        if (array_key_exists('sort_order', $data)) {
            $data['sort_order'] = (int) $data['sort_order'];
        }
        return $data;
    }

    private function present(string $type, Model $item): array
    {
        if ($type === 'collections') {
            $item->loadCount(['skus', 'flights']);
        }
        if ($type === 'directions') {
            $item->loadCount('blocks');
        }
        return $item->toArray();
    }

    /** Что мешает удалить запись справочника (null — можно удалять). */
    private function inUse(string $type, Model $item): ?string
    {
        $n = fn (string $table, string $col) => DB::table($table)->where($col, $item->id)->count();
        return match ($type) {
            'collections'   => ($c = $n('flights', 'collection_id')) ? "у коллекции {$c} флайт(ов)"
                : (($s = $n('skus', 'collection_id')) ? "у коллекции {$s} SKU" : null),
            'skus'          => ($c = $n('flight_sku', 'sku_id') + $n('activity_sku', 'sku_id')) ? "SKU используется во флайтах/активностях ({$c})" : null,
            'directions'    => ($c = $n('activities', 'direction_id') + $n('direction_flight', 'direction_id')) ? "направление используется ({$c})" : null,
            'blocks'        => ($c = $n('activities', 'block_id')) ? "блок используется в {$c} активност(ях)" : null,
            'statuses'      => ($c = $n('flights', 'status_id')) ? "статус у {$c} флайт(ов)" : null,
            'context-types' => ($c = $n('context_items', 'context_type_id')) ? "тип у {$c} записей контекста" : null,
        };
    }
}
