<?php

namespace App\Http\Controllers;

use App\Services\IndexmClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * Картинка SKU из indexM через сервер Planner: браузер не знает токена indexM.
 * Кэш на диске (storage/app/private/sku-images), раз в сутки ревалидация по ETag;
 * indexM недоступен — отдаём то, что есть в кэше, или 404 (страницы работают без картинок).
 */
class SkuImageController extends Controller
{
    private const TTL = 86400;

    public function show(Request $request, string $article): Response
    {
        abort_unless(preg_match('/^[A-Za-z0-9._-]{1,50}$/', $article), 404);
        $size = $request->query('size') === 'full' ? 'full' : 'preview';

        $dir = storage_path('app/private/sku-images');
        $file = "{$dir}/{$article}-{$size}";
        $meta = is_file("{$file}.json") ? (json_decode((string) file_get_contents("{$file}.json"), true) ?: []) : [];

        if (! $meta || time() - ($meta['checked_at'] ?? 0) > self::TTL) {
            $meta = $this->refresh($article, $size, $file, $meta);
        }

        if (empty($meta['image_id']) || ! is_file($file)) {
            return response('', 404, ['Cache-Control' => 'private, max-age=3600']);
        }

        return response()->file($file, [
            'Content-Type'  => $meta['type'] ?? 'image/jpeg',
            'Cache-Control' => 'private, max-age=3600',
        ]);
    }

    private function refresh(string $article, string $size, string $file, array $meta): array
    {
        $client = new IndexmClient();
        if (! $client->configured()) {
            return $meta;   // не настроено — не кэшируем «нет картинки»
        }
        @mkdir(dirname($file), 0775, true);

        try {
            $info = $client->imageInfo($article);
            $image = $info['image'] ?? null;
            if (! $image) {
                // артикула нет в indexM или у главного релиза нет обложки
                @unlink($file);
                return $this->saveMeta($file, ['image_id' => null, 'checked_at' => time()]);
            }

            $sameImage = ($meta['image_id'] ?? null) === $image['id'] && is_file($file);
            $resp = $client->file($image[$size === 'full' ? 'full_url' : 'preview_url'], $sameImage ? ($meta['etag'] ?? null) : null);

            if ($resp['status'] === 304 && $sameImage) {
                return $this->saveMeta($file, ['checked_at' => time()] + $meta);
            }
            if ($resp['status'] !== 200 || $resp['body'] === '') {
                throw new \RuntimeException("indexM: файл картинки {$image['id']} — код {$resp['status']}");
            }
            file_put_contents("{$file}.tmp", $resp['body']);
            rename("{$file}.tmp", $file);

            return $this->saveMeta($file, [
                'image_id'   => $image['id'],
                'etag'       => $resp['etag'],
                'type'       => $resp['type'] ?: ($image['mime_type'] ?? 'image/jpeg'),
                'checked_at' => time(),
            ]);
        } catch (\Throwable $e) {
            Log::warning("SKU {$article}: картинка из indexM недоступна — {$e->getMessage()}");
            // работаем на старом кэше (если есть); повторная попытка — через 10 минут,
            // чтобы недоступный indexM не тормозил каждую карточку
            return $this->saveMeta($file, ['checked_at' => time() - self::TTL + 600] + $meta);
        }
    }

    private function saveMeta(string $file, array $meta): array
    {
        file_put_contents("{$file}.json", json_encode($meta));
        return $meta;
    }
}
