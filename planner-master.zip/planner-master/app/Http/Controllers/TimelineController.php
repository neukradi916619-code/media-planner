<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Collection;
use App\Models\ContextItem;
use App\Models\Flight;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Inertia\Inertia;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;

/**
 * Таймлайн — перенос прежнего index.html (Ганта, слой контекста, карточка флайта,
 * выгрузка PPTX) почти без изменений: его JS получает данные в том же формате, что
 * отдавал Apps Script из Google-таблицы (строки листов по номерам столбцов), только
 * теперь из БД Planner. Файлы страницы — public/timeline-assets/*.
 */
class TimelineController extends Controller
{
    /** Поведение статуса → ключ статуса, на который рассчитан JS таймлайна. */
    private const STATUS_KEYS = [
        'normal' => 'план',
        'bright' => 'подтверждено',
        'muted'  => 'завершено',
        'hidden' => 'отменено',
    ];

    public function index(Request $request): View|SymfonyResponse
    {
        // Таймлайн — не Inertia-страница. Если сюда пришёл Inertia-запрос (например,
        // редирект после входа), Inertia показала бы HTML в модальном iframe поверх
        // страницы — вместо этого просим браузер загрузить страницу целиком.
        if ($request->header('X-Inertia')) {
            return Inertia::location($request->fullUrl());
        }

        return view('timeline', [
            'data' => $this->payload($request),
            'v'    => @filemtime(public_path('timeline-assets/timeline.js')) ?: 1,
        ]);
    }

    /** Обновление данных открытой страницы (раз в 5 минут, как раньше). */
    public function data(Request $request): JsonResponse
    {
        return response()->json($this->payload($request));
    }

    private function payload(Request $request): array
    {
        $user = $request->user();
        $flights = Flight::with(['collection', 'status', 'skus:id,name,article', 'activities.direction', 'activities.block', 'activities.skus:id,name'])
            ->orderBy('start_date')->orderBy('name')->get();

        return [
            'collections' => Collection::where('is_active', true)->orderBy('name')->get()
                ->map(fn (Collection $c) => [$this->t($c->name), $c->color, $this->t($c->bm_name), $this->t($c->default_audience), $this->t($c->default_claim), 'Да'])
                ->all(),
            'flights'    => $flights->map(fn (Flight $f) => $this->flightRow($f, $user))->all(),
            'activities' => $flights->flatMap(fn (Flight $f) => $f->activities->map(fn (Activity $a) => $this->activityRow($a, $f)))->values()->all(),
            'context'    => ContextItem::with(['type', 'collection'])->where('is_active', true)->orderBy('start_date')->get()
                ->map(fn (ContextItem $i) => [
                    $this->t($i->type?->name), $this->t($i->name),
                    $i->start_date?->format('Y-m-d'), ($i->end_date ?? $i->start_date)?->format('Y-m-d'),
                    $this->t($i->collection?->name), $this->t($i->comment), $i->color ?: $i->type?->color, 'Да',
                ])->all(),
            'user' => ['name' => $user->name, 'can_write' => $user->canWrite(), 'is_admin' => $user->isAdmin()],
        ];
    }

    private function flightRow(Flight $f, $user): array
    {
        $c = $f->collection;
        $skus = $f->skus;
        $row = [
            $this->t($f->name), $this->t($c?->name),
            $f->start_date?->format('Y-m-d'), $f->end_date?->format('Y-m-d'),
            self::STATUS_KEYS[$f->status?->behavior ?? 'normal'],
            $this->t($c?->bm_name),
            $this->t($c?->default_audience), $this->t($f->audience_override), $this->t($f->audience()),
            $this->t($c?->default_claim), $this->t($f->claim_override), $this->t($f->claim()),
            $this->t($skus[0]->name ?? null), $this->t($skus[1]->name ?? null), $this->t($skus[2]->name ?? null),
        ];
        $row = array_pad($row, 23, '');
        $row[23] = $this->t($f->brief);
        $row[24] = $this->url($f->materials_url);
        $row[25] = $this->t($f->comment);
        $row[26] = '';
        // Дополнения Planner (в таблице их не было): id для ссылки на форму, все SKU с артикулами
        $row[27] = [
            'id'       => $f->id,
            'status'   => $this->t($f->status?->name),
            'can_edit' => $user->canEditCollection($f->collection_id),
            'skus'     => $skus->map(fn ($s) => ['name' => $this->t($s->name), 'article' => $s->article])->all(),
        ];
        return $row;
    }

    private function activityRow(Activity $a, Flight $f): array
    {
        $start = $a->start_date ?? $f->start_date;
        $end = $a->end_date ?? $f->end_date;
        $skus = $a->skus->isNotEmpty() ? $a->skus : $f->skus;
        $row = array_fill(0, 23, '');
        $row[0] = $this->t($f->name);
        $row[1] = $this->t($a->direction?->name);
        $row[2] = $this->t($a->block?->name);
        $row[3] = $a->start_date?->format('Y-m-d') ?? '';
        $row[4] = $a->end_date?->format('Y-m-d') ?? '';
        $row[5] = $start?->format('Y-m-d') ?? '';
        $row[6] = $end?->format('Y-m-d') ?? '';
        $row[7] = $this->t($a->platforms);
        $row[8] = $this->t($a->format);
        $row[12] = $this->t($skus->pluck('name')->join(', '));
        $row[14] = $this->t($a->audience_override ?: $f->audience());
        $row[16] = $this->t($a->claim_override ?: $f->claim());
        $row[17] = $this->url($a->materials_url);
        $row[18] = $this->url($a->special_doc_url);
        $row[20] = $this->t($f->collection?->name);
        $row[21] = $this->t($a->comment);
        $row[22] = $this->t($f->collection?->bm_name);
        return $row;
    }

    /**
     * JS таймлайна местами собирает HTML строками (innerHTML) — угловые скобки в данных
     * заменяем на похожие кавычки, чтобы введённый текст не стал разметкой.
     */
    private function t(?string $v): string
    {
        return $v === null ? '' : strtr($v, ['<' => '‹', '>' => '›']);
    }

    /** Ссылки — только http(s): иначе в href мог бы попасть javascript:. */
    private function url(?string $v): string
    {
        return $v && preg_match('#^https?://#i', trim($v)) ? $this->t(trim($v)) : '';
    }
}
