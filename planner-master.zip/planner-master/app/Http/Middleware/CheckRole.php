<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();
        $authorized = $user && collect($roles)->contains(fn (string $role) => $user->hasRole($role));

        if (! $authorized) {
            if ($request->wantsJson() || $request->header('X-Inertia')) {
                return response()->json(['message' => 'Доступ запрещён.'], 403);
            }

            abort(403, 'Доступ запрещён.');
        }

        return $next($request);
    }
}
