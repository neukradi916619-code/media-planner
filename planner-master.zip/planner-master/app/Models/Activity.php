<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * Активность флайта. Даты, SKU, ЦА и клейм наследуются из флайта, если нет override.
 */
class Activity extends Model
{
    use LogsActivity;

    protected $fillable = [
        'flight_id', 'direction_id', 'block_id', 'start_date', 'end_date', 'platforms', 'format',
        'audience_override', 'claim_override', 'materials_url', 'special_doc_url', 'comment', 'sort_order',
    ];
    protected $casts = ['start_date' => 'date:Y-m-d', 'end_date' => 'date:Y-m-d'];

    public function flight(): BelongsTo { return $this->belongsTo(Flight::class); }
    public function direction(): BelongsTo { return $this->belongsTo(Direction::class); }
    public function block(): BelongsTo { return $this->belongsTo(Block::class); }
    public function skus(): BelongsToMany { return $this->belongsToMany(Sku::class)->withPivot('position')->orderByPivot('position'); }
}
