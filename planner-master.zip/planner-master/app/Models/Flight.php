<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Флайт (кампания). БМ, ЦА и клейм наследуются из коллекции, если нет override.
 */
class Flight extends Model
{
    use LogsActivity;

    protected $fillable = [
        'name', 'collection_id', 'start_date', 'end_date', 'status_id',
        'audience_override', 'claim_override', 'brief', 'materials_url', 'comment', 'created_by',
    ];
    protected $casts = ['start_date' => 'date:Y-m-d', 'end_date' => 'date:Y-m-d'];

    public function collection(): BelongsTo { return $this->belongsTo(Collection::class); }
    public function status(): BelongsTo { return $this->belongsTo(Status::class); }
    public function directions(): BelongsToMany { return $this->belongsToMany(Direction::class); }
    public function skus(): BelongsToMany { return $this->belongsToMany(Sku::class)->withPivot('position')->orderByPivot('position'); }
    public function activities(): HasMany { return $this->hasMany(Activity::class)->orderBy('sort_order')->orderBy('id'); }

    public function audience(): ?string { return $this->audience_override ?: $this->collection?->default_audience; }
    public function claim(): ?string { return $this->claim_override ?: $this->collection?->default_claim; }
}
