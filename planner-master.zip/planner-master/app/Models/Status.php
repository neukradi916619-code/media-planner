<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    use LogsActivity;

    /** Поведение флайта со статусом на таймлайне. */
    public const BEHAVIORS = [
        'normal' => 'Обычное',
        'bright' => 'Ярко',
        'muted'  => 'Приглушено',
        'hidden' => 'Скрыто по умолчанию',
    ];

    protected $fillable = ['name', 'behavior', 'color', 'description', 'sort_order'];
}
