<?php

namespace App\Models\Concerns;

use App\Models\ActivityLog;

trait LogsActivity
{
    /** Публичный метод — доступен из замыканий Eloquent-событий. */
    public function getActivityEntityType(): string
    {
        return $this->activityType ?? class_basename(static::class);
    }

    /** Публичный метод — список полей, исключённых из лога. */
    public function getActivityExclusions(): array
    {
        return $this->activityExclude ?? [];
    }

    protected static function bootLogsActivity(): void
    {
        static::created(function ($model) {
            ActivityLog::create([
                'entity_type' => $model->getActivityEntityType(),
                'entity_id'   => $model->id,
                'user_id'     => auth()->id(),
                'action'      => 'created',
                'changes'     => null,
            ]);
        });

        static::updating(function ($model) {
            $skip = array_merge(
                ['updated_at', 'created_at'],
                $model->getActivityExclusions()
            );
            $changes = [];
            foreach ($model->getDirty() as $field => $newVal) {
                if (in_array($field, $skip, true)) {
                    continue;
                }
                $changes[] = [
                    'field' => $field,
                    'old'   => $model->getOriginal($field),
                    'new'   => $newVal,
                ];
            }
            if (! empty($changes)) {
                ActivityLog::create([
                    'entity_type' => $model->getActivityEntityType(),
                    'entity_id'   => $model->id,
                    'user_id'     => auth()->id(),
                    'action'      => 'updated',
                    'changes'     => $changes,
                ]);
            }
        });

        static::deleted(function ($model) {
            ActivityLog::create([
                'entity_type' => $model->getActivityEntityType(),
                'entity_id'   => $model->id,
                'user_id'     => auth()->id(),
                'action'      => 'deleted',
                'changes'     => null,
            ]);
        });
    }
}
