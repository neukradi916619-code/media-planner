<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * Роли Planner:
 *  admin  — всё, плюс пользователи и настройки;
 *  editor — все данные и справочники;
 *  bm     — флайты, активности и контекст своих коллекций (collection_user), справочники — просмотр;
 *  viewer — только просмотр и выгрузка PPTX.
 */
class User extends Authenticatable
{
    use Notifiable;

    public const ROLES = [
        'admin'  => 'Администратор',
        'editor' => 'Редактор',
        'bm'     => 'Бренд-менеджер',
        'viewer' => 'Просмотр',
    ];

    protected $fillable = ['name', 'email', 'password', 'role'];
    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
        ];
    }

    public function collections(): BelongsToMany
    {
        return $this->belongsToMany(Collection::class);
    }

    public function isAdmin(): bool  { return $this->role === 'admin'; }
    public function isEditor(): bool { return in_array($this->role, ['admin', 'editor'], true); }
    public function isBm(): bool     { return $this->role === 'bm'; }

    /** Может ли править данные (флайты/активности/контекст) — хотя бы какие-то. */
    public function canWrite(): bool { return $this->isEditor() || $this->isBm(); }

    /** id коллекций, которые БМ может править; null — без ограничения (редактор/админ). */
    public function editableCollectionIds(): ?array
    {
        if ($this->isEditor()) {
            return null;
        }
        if (! $this->isBm()) {
            return [];
        }
        return $this->collections()->pluck('collections.id')->all();
    }

    /** Может ли править запись, привязанную к коллекции (null — запись без коллекции). */
    public function canEditCollection(?int $collectionId): bool
    {
        if ($this->isEditor()) {
            return true;
        }
        // У БМ записи без коллекции (общий контекст) — только просмотр.
        return $this->isBm() && $collectionId !== null
            && in_array($collectionId, $this->editableCollectionIds(), true);
    }

    public function hasRole(string $role): bool
    {
        return match ($role) {
            'admin'  => $this->isAdmin(),
            'editor' => $this->isEditor(),
            'writer' => $this->canWrite(),
            default  => false,
        };
    }
}
