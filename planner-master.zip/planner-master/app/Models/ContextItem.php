<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Календарь контекста: поводы, сезонность, события, лончи. */
class ContextItem extends Model
{
    use LogsActivity;

    protected $activityType = 'Context';
    protected $fillable = ['context_type_id', 'name', 'start_date', 'end_date', 'collection_id', 'comment', 'color', 'is_active'];
    protected $casts = ['start_date' => 'date:Y-m-d', 'end_date' => 'date:Y-m-d', 'is_active' => 'boolean'];

    public function type(): BelongsTo { return $this->belongsTo(ContextType::class, 'context_type_id'); }
    public function collection(): BelongsTo { return $this->belongsTo(Collection::class); }
}
