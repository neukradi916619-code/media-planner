<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = ['key', 'value', 'group', 'label', 'description'];

    public static function get(string $key, mixed $default = null): mixed
    {
        return static::where('key', $key)->value('value') ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        static::where('key', $key)->update(['value' => $value]);
    }

    public static function allByGroup(): array
    {
        return static::orderBy('group')->orderBy('id')
            ->get()
            ->groupBy('group')
            ->map(fn ($items) => $items->keyBy('key'))
            ->toArray();
    }
}
