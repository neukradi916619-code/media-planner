<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;

class ContextType extends Model
{
    use LogsActivity;

    protected $fillable = ['name', 'color', 'sort_order'];
}
