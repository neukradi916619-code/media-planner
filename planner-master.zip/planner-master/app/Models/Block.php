<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Рекламный блок — подвид направления (Медиа → ТВ, Digital → Таргет …). */
class Block extends Model
{
    use LogsActivity;

    protected $fillable = ['direction_id', 'name', 'sort_order', 'is_active'];
    protected $casts = ['is_active' => 'boolean'];

    public function direction(): BelongsTo { return $this->belongsTo(Direction::class); }
}
