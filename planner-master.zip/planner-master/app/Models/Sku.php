<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Sku extends Model
{
    use LogsActivity;

    protected $activityType = 'SKU';
    protected $fillable = ['collection_id', 'name', 'article', 'is_active'];
    protected $casts = ['is_active' => 'boolean'];

    public function collection(): BelongsTo { return $this->belongsTo(Collection::class); }
}
