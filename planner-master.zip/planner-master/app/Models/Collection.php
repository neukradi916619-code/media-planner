<?php

namespace App\Models;

use App\Models\Concerns\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Collection extends Model
{
    use LogsActivity;

    protected $fillable = ['name', 'color', 'bm_name', 'default_audience', 'default_claim', 'is_active'];
    protected $casts = ['is_active' => 'boolean'];

    public function skus(): HasMany { return $this->hasMany(Sku::class); }
    public function flights(): HasMany { return $this->hasMany(Flight::class); }
    /** Пользователи-БМ, которые правят флайты этой коллекции. */
    public function users(): BelongsToMany { return $this->belongsToMany(User::class); }
}
