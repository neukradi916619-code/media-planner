<?php

namespace App\Console\Commands;

use App\Models\Activity;
use App\Models\Block;
use App\Models\Collection;
use App\Models\ContextItem;
use App\Models\ContextType;
use App\Models\Direction;
use App\Models\Flight;
use App\Models\Sku;
use App\Models\Status;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

/**
 * Перенос данных из Google-таблицы «Librederm Campaign Planner» (выгрузка .xlsx:
 * https://docs.google.com/spreadsheets/d/<id>/export?format=xlsx).
 *
 * Идемпотентна: справочники и флайты сопоставляются по названию, контекст — по
 * типу+названию+дате начала. Активности импортируемого флайта пересоздаются целиком
 * (как в таблице), поэтому после начала работы в Planner повторный запуск затрёт
 * правки активностей — команда для однократного переноса.
 */
class ImportSheet extends Command
{
    protected $signature = 'planner:import-sheet {file : путь к .xlsx-выгрузке таблицы}';
    protected $description = 'Импорт справочников, флайтов, активностей и контекста из выгрузки Google-таблицы';

    private array $warnings = [];
    private array $stats = [];

    public function handle(): int
    {
        $path = $this->argument('file');
        if (! is_file($path)) {
            $this->error("Файл не найден: {$path}");
            return self::FAILURE;
        }

        $book = IOFactory::load($path);

        // Импорт — системная операция: журнал изменений не засоряем тысячами «создано».
        Model::withoutEvents(fn () => DB::transaction(function () use ($book) {
            $this->collections($this->sheet($book, 'СПР_КОЛЛЕКЦИИ', 'Коллекция'));
            $this->skus($this->sheet($book, 'СПР_SKU', 'Коллекция'));
            $this->directions($this->sheet($book, 'СПР_НАПРАВЛЕНИЯ', 'Порядок'));
            $this->blocks($this->sheet($book, 'СПР_БЛОКИ', 'Направление'));
            $this->statuses($this->sheet($book, 'СПР_СТАТУСЫ', 'Статус'));
            $this->contextTypes($this->sheet($book, 'СПР_ТИПЫ_КОНТЕКСТА', 'Тип контекста'));
            $this->flights($this->sheet($book, 'ФЛАЙТЫ', 'Название флайта'));
            $this->activities($this->sheet($book, 'АКТИВНОСТИ', 'Флайт'));
            $this->contextItems($this->sheet($book, 'КОНТЕКСТ', 'Тип контекста'));
        }));

        $this->table(['Лист', 'Записей'], collect($this->stats)->map(fn ($n, $k) => [$k, $n])->values()->all());
        foreach (array_unique($this->warnings) as $w) {
            $this->warn($w);
        }
        $this->info('Готово.');
        return self::SUCCESS;
    }

    // ── Чтение листов ──────────────────────────────────────────────────────────

    /**
     * Строки листа как ассоциативные массивы «заголовок → значение». Строка заголовков
     * ищется по первому столбцу (над таблицей на листах есть пояснительный текст).
     *
     * @return array<int, array<string, mixed>>
     */
    private function sheet($book, string $name, string $firstHeader): array
    {
        $ws = $book->getSheetByName($name);
        if (! $ws) {
            $this->warnings[] = "Нет листа «{$name}» — пропущен.";
            return [];
        }
        $rows = $ws->toArray(null, true, false, false);
        $headerIdx = null;
        foreach ($rows as $i => $r) {
            if ($this->str($r[0] ?? null) === $firstHeader) {
                $headerIdx = $i;
                break;
            }
        }
        if ($headerIdx === null) {
            $this->warnings[] = "На листе «{$name}» не найден заголовок «{$firstHeader}» — пропущен.";
            return [];
        }
        $headers = array_map(fn ($h) => $this->str($h), $rows[$headerIdx]);
        $out = [];
        foreach (array_slice($rows, $headerIdx + 1) as $r) {
            $row = [];
            foreach ($headers as $j => $h) {
                if ($h !== null) {
                    $row[$h] = $r[$j] ?? null;
                }
            }
            if (collect($row)->filter(fn ($v) => $this->str($v) !== null)->isNotEmpty()) {
                $out[] = $row;
            }
        }
        return $out;
    }

    private function str(mixed $v): ?string
    {
        if ($v === null) {
            return null;
        }
        $s = trim(is_float($v) && floor($v) == $v ? (string) (int) $v : (string) $v);
        return $s === '' ? null : $s;
    }

    private function yes(mixed $v, bool $default = true): bool
    {
        $s = mb_strtolower((string) $this->str($v));
        return $s === '' ? $default : in_array($s, ['да', 'yes', 'true', '1'], true);
    }

    private function date(mixed $v): ?string
    {
        if ($v === null || $v === '') {
            return null;
        }
        if ($v instanceof \DateTimeInterface) {
            return $v->format('Y-m-d');
        }
        if (is_numeric($v)) {
            return ExcelDate::excelToDateTimeObject((float) $v)->format('Y-m-d');
        }
        $ts = strtotime((string) $v);
        return $ts ? date('Y-m-d', $ts) : null;
    }

    private function color(mixed $v): ?string
    {
        $s = $this->str($v);
        return $s && preg_match('/^#[0-9a-f]{6}$/i', $s) ? strtoupper($s) : null;
    }

    // ── Справочники ────────────────────────────────────────────────────────────

    private function collections(array $rows): void
    {
        foreach ($rows as $r) {
            if (! $name = $this->str($r['Коллекция'] ?? null)) {
                continue;
            }
            Collection::updateOrCreate(['name' => $name], [
                'color'            => $this->color($r['Цвет_HEX'] ?? null),
                'bm_name'          => $this->str($r['БМ / контакт'] ?? null),
                'default_audience' => $this->str($r['ЦА по умолчанию'] ?? null),
                'default_claim'    => $this->str($r['Клейм по умолчанию'] ?? null),
                'is_active'        => $this->yes($r['Активна'] ?? null),
            ]);
        }
        $this->stats['Коллекции'] = Collection::count();
    }

    private function collectionId(?string $name, string $where): ?int
    {
        if ($name === null) {
            return null;
        }
        $id = Collection::where('name', $name)->value('id');
        if (! $id) {
            $this->warnings[] = "{$where}: коллекция «{$name}» не найдена в справочнике.";
        }
        return $id;
    }

    private function skus(array $rows): void
    {
        foreach ($rows as $r) {
            $name = $this->str($r['SKU (полное название из прайс-листа)'] ?? null);
            if (! $name) {
                continue;
            }
            $article = $this->str($r['Артикул'] ?? null);
            $attrs = [
                'collection_id' => $this->collectionId($this->str($r['Коллекция'] ?? null), 'SKU'),
                'name'          => $name,
                'article'       => $article,
                'is_active'     => $this->yes($r['Активен'] ?? null),
            ];
            $sku = ($article ? Sku::where('article', $article)->first() : null)
                ?? Sku::where('name', $name)->where('collection_id', $attrs['collection_id'])->first();
            $sku ? $sku->update($attrs) : Sku::create($attrs);
        }
        $this->stats['SKU'] = Sku::count();
    }

    private function directions(array $rows): void
    {
        foreach ($rows as $r) {
            if (! $name = $this->str($r['Направление'] ?? null)) {
                continue;
            }
            Direction::updateOrCreate(['name' => $name], [
                'sort_order' => (int) ($r['Порядок'] ?? 0),
                'is_active'  => $this->yes($r['Активно'] ?? null),
            ]);
        }
        $this->stats['Направления'] = Direction::count();
    }

    /** Направление по названию; заголовки флайтов пишут его чуть иначе («Мед продвижения»). */
    private function directionByName(?string $name): ?Direction
    {
        if ($name === null) {
            return null;
        }
        static $all = null;
        $all ??= Direction::all();
        $norm = fn ($s) => mb_strtolower(preg_replace('/\s+/u', ' ', $s));
        $best = null;
        $bestDist = PHP_INT_MAX;
        foreach ($all as $d) {
            $dist = levenshtein($norm($d->name), $norm($name));
            if ($dist < $bestDist) {
                [$best, $bestDist] = [$d, $dist];
            }
        }
        return $bestDist <= 4 ? $best : null;
    }

    private function blocks(array $rows): void
    {
        $order = 0;
        foreach ($rows as $r) {
            $dir = $this->directionByName($this->str($r['Направление'] ?? null));
            $name = $this->str($r['Рекламный блок'] ?? null);
            if (! $dir || ! $name) {
                $this->warnings[] = 'Блоки: строка без направления или названия пропущена.';
                continue;
            }
            Block::updateOrCreate(['direction_id' => $dir->id, 'name' => $name], [
                'sort_order' => ++$order,
                'is_active'  => $this->yes($r['Активен'] ?? null),
            ]);
        }
        $this->stats['Рекламные блоки'] = Block::count();
    }

    private function statuses(array $rows): void
    {
        $colors = ['normal' => '#94A3B8', 'bright' => '#16A34A', 'muted' => '#CBD5E1', 'hidden' => '#EF4444'];
        $order = 0;
        foreach ($rows as $r) {
            if (! $name = $this->str($r['Статус'] ?? null)) {
                continue;
            }
            $desc = (string) $this->str($r['Поведение в дашборде'] ?? null);
            $low = mb_strtolower($desc);
            $behavior = match (true) {
                str_contains($low, 'скрыт')   => 'hidden',
                str_contains($low, 'приглуш') => 'muted',
                str_contains($low, 'ярк')     => 'bright',
                default                       => 'normal',
            };
            $status = Status::firstOrNew(['name' => $name]);
            $status->fill(['behavior' => $behavior, 'description' => $desc ?: null, 'sort_order' => ++$order]);
            $status->color ??= $colors[$behavior];
            $status->save();
        }
        $this->stats['Статусы'] = Status::count();
    }

    private function contextTypes(array $rows): void
    {
        foreach ($rows as $r) {
            if (! $name = $this->str($r['Тип контекста'] ?? null)) {
                continue;
            }
            ContextType::updateOrCreate(['name' => $name], [
                'color'      => $this->color($r['Цвет_HEX'] ?? null),
                'sort_order' => (int) ($r['Порядок'] ?? 0),
            ]);
        }
        $this->stats['Типы контекста'] = ContextType::count();
    }

    // ── Данные ─────────────────────────────────────────────────────────────────

    /** SKU по полному названию (или артикулу) — сначала в коллекции, потом во всём справочнике. */
    private function skuIds(array $values, ?int $collectionId, string $where): array
    {
        $ids = [];
        foreach ($values as $v) {
            if (! $v = $this->str($v)) {
                continue;
            }
            if (in_array(mb_strtolower($v), ['нет', '—', '-'], true)) {
                continue;
            }
            $q = fn () => Sku::where(fn ($w) => $w->where('name', $v)->orWhere('article', $v));
            $id = ($collectionId ? $q()->where('collection_id', $collectionId)->value('id') : null) ?? $q()->value('id');
            // В таблице длинные названия бывают обрезаны: «… для кожи вокруг гл...» — ищем по началу,
            // только если совпадение однозначное.
            if (! $id && preg_match('/^(.+?)\s*(\.\.\.|…)$/u', $v, $m)) {
                $prefix = Sku::where('name', 'like', str_replace(['%', '_'], ['\%', '\_'], $m[1]).'%');
                if ($collectionId && (clone $prefix)->where('collection_id', $collectionId)->count() === 1) {
                    $id = $prefix->where('collection_id', $collectionId)->value('id');
                } elseif ($prefix->count() === 1) {
                    $id = $prefix->value('id');
                }
            }
            if ($id) {
                $ids[] = $id;
            } else {
                $this->warnings[] = "{$where}: SKU «{$v}» не найден в справочнике.";
            }
        }
        return array_values(array_unique($ids));
    }

    private function syncSkus($relation, array $ids): void
    {
        $relation->sync(collect($ids)->mapWithKeys(fn ($id, $i) => [$id => ['position' => $i]])->all());
    }

    private function flights(array $rows): void
    {
        $statuses = Status::pluck('id', 'name');
        // Направления — столбцы «Да/Нет» после SKU 3 и до «Общий бриф»
        $dirColumns = [];
        if ($rows) {
            $keys = array_keys($rows[0]);
            $from = array_search('SKU 3', $keys, true);
            $to = array_search('Общий бриф', $keys, true);
            foreach (array_slice($keys, $from + 1, $to - $from - 1) as $col) {
                if ($dir = $this->directionByName($col)) {
                    $dirColumns[$col] = $dir->id;
                } else {
                    $this->warnings[] = "Флайты: столбец «{$col}» не сопоставлен с направлением.";
                }
            }
        }

        foreach ($rows as $r) {
            if (! $name = $this->str($r['Название флайта'] ?? null)) {
                continue;
            }
            $collectionId = $this->collectionId($this->str($r['Коллекция'] ?? null), "Флайт «{$name}»");
            $statusName = $this->str($r['Статус'] ?? null);
            if ($statusName && ! isset($statuses[$statusName])) {
                $this->warnings[] = "Флайт «{$name}»: статус «{$statusName}» не найден.";
            }
            $flight = Flight::updateOrCreate(['name' => $name], [
                'collection_id'     => $collectionId,
                'start_date'        => $this->date($r['Дата начала'] ?? null),
                'end_date'          => $this->date($r['Дата окончания'] ?? null),
                'status_id'         => $statusName ? ($statuses[$statusName] ?? null) : null,
                'audience_override' => $this->str($r['ЦА override'] ?? null),
                'claim_override'    => $this->str($r['Клейм override'] ?? null),
                'brief'             => $this->str($r['Общий бриф'] ?? null),
                'materials_url'     => $this->str($r['Материалы / общая папка'] ?? null),
                'comment'           => $this->str($r['Комментарий'] ?? null),
            ]);
            $flight->directions()->sync(
                collect($dirColumns)->filter(fn ($id, $col) => $this->yes($r[$col] ?? null, false))->values()->all()
            );
            $this->syncSkus($flight->skus(), $this->skuIds(
                [$r['SKU 1'] ?? null, $r['SKU 2'] ?? null, $r['SKU 3'] ?? null], $collectionId, "Флайт «{$name}»"
            ));
        }
        $this->stats['Флайты'] = Flight::count();
    }

    private function activities(array $rows): void
    {
        $seen = [];
        $order = 0;
        foreach ($rows as $r) {
            $flightName = $this->str($r['Флайт'] ?? null);
            $flight = $flightName ? Flight::where('name', $flightName)->first() : null;
            if (! $flight) {
                $this->warnings[] = "Активности: флайт «{$flightName}» не найден — строка пропущена.";
                continue;
            }
            $dir = $this->directionByName($this->str($r['Направление'] ?? null));
            if (! $dir) {
                $this->warnings[] = "Активности «{$flightName}»: направление «{$r['Направление']}» не найдено — строка пропущена.";
                continue;
            }
            if (! isset($seen[$flight->id])) {
                $flight->activities()->delete();   // пересоздаём активности флайта целиком
                $seen[$flight->id] = true;
            }
            if (! $flight->directions()->whereKey($dir->id)->exists()) {
                $this->warnings[] = "Флайт «{$flightName}»: у активности направление «{$dir->name}», не отмеченное во флайте — отмечено.";
                $flight->directions()->attach($dir->id);
            }
            $blockName = $this->str($r['Рекламный блок'] ?? null);
            $blockId = $blockName ? Block::where('direction_id', $dir->id)->where('name', $blockName)->value('id') : null;
            if ($blockName && ! $blockId) {
                $this->warnings[] = "Активности «{$flightName}»: блок «{$blockName}» не найден в направлении «{$dir->name}».";
            }
            $activity = Activity::create([
                'flight_id'         => $flight->id,
                'direction_id'      => $dir->id,
                'block_id'          => $blockId,
                'start_date'        => $this->date($r['Дата начала override'] ?? null),
                'end_date'          => $this->date($r['Дата окончания override'] ?? null),
                'platforms'         => $this->str($r['Площадки / краткое описание'] ?? null),
                'format'            => $this->str($r['Формат / механика'] ?? null),
                'audience_override' => $this->str($r['ЦА override'] ?? null),
                'claim_override'    => $this->str($r['Клейм override'] ?? null),
                'materials_url'     => $this->str($r['Материалы / результаты'] ?? null),
                'special_doc_url'   => $this->str($r['Спец. документ'] ?? null),
                'comment'           => $this->str($r['Комментарий'] ?? null),
                'sort_order'        => ++$order,
            ]);
            $this->syncSkus($activity->skus(), $this->skuIds(
                [$r['SKU override 1'] ?? null, $r['SKU override 2'] ?? null, $r['SKU override 3'] ?? null],
                $flight->collection_id, "Активность «{$flightName}»"
            ));
        }
        $this->stats['Активности'] = Activity::count();
    }

    private function contextItems(array $rows): void
    {
        $types = ContextType::pluck('id', 'name');
        $typeColors = ContextType::pluck('color', 'name');
        foreach ($rows as $r) {
            $name = $this->str($r['Название'] ?? null);
            $typeName = $this->str($r['Тип контекста'] ?? null);
            $start = $this->date($r['Дата начала'] ?? null);
            if (! $name || ! $start) {
                continue;
            }
            if (! isset($types[$typeName])) {
                $this->warnings[] = "Контекст «{$name}»: тип «{$typeName}» не найден — пропущен.";
                continue;
            }
            ContextItem::updateOrCreate(
                ['context_type_id' => $types[$typeName], 'name' => $name, 'start_date' => $start],
                [
                    'end_date'      => $this->date($r['Дата окончания'] ?? null),
                    'collection_id' => $this->collectionId($this->str($r['Связанная коллекция (необязательно)'] ?? null), "Контекст «{$name}»"),
                    'comment'       => $this->str($r['Комментарий'] ?? null),
                    // «Цвет (авто)» храним, только если отличается от цвета типа
                    'color'         => ($c = $this->color($r['Цвет (авто)'] ?? null)) && $c !== strtoupper((string) $typeColors[$typeName]) ? $c : null,
                    'is_active'     => $this->yes($r['Активен'] ?? null),
                ]
            );
        }
        $this->stats['Контекст'] = ContextItem::count();
    }
}
