<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

/** Первый администратор (дальше пользователей заводят в интерфейсе). */
class CreateAdmin extends Command
{
    protected $signature = 'planner:create-admin {email} {name} {--password= : если не задан — сгенерируется}';
    protected $description = 'Создать администратора Planner (или сбросить пароль существующему)';

    public function handle(): int
    {
        $password = $this->option('password') ?: \Illuminate\Support\Str::password(14, symbols: false);
        $user = User::updateOrCreate(
            ['email' => $this->argument('email')],
            ['name' => $this->argument('name'), 'password' => $password, 'role' => 'admin'],
        );
        $this->info("Администратор {$user->email} готов. Пароль: {$password}");
        return self::SUCCESS;
    }
}
