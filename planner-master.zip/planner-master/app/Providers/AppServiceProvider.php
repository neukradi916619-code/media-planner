<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Gate::define('admin',  fn ($user) => $user->isAdmin());
        Gate::define('editor', fn ($user) => $user->isEditor());
        Gate::before(fn ($user) => $user->isAdmin() ?: null);
    }
}
