<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;

/**
 * Клиент к API indexM для внешних приложений (docs/external-api.md в indexM):
 * главная картинка SKU по артикулу. Токен — подключение «Planner» в indexM
 * (Настройки → Интеграции → «Внешние API»); хранится в настройках Planner и
 * в браузер не уходит — картинки отдаются через /sku-image/{article}.
 */
class IndexmClient
{
    public function __construct(private ?string $url = null, private ?string $token = null)
    {
        $this->url = rtrim($url ?? (string) Setting::get('indexm_url', ''), '/');
        $this->token = $token ?? (string) Setting::get('indexm_api_token', '');
    }

    public function configured(): bool
    {
        return $this->url !== '' && $this->token !== '';
    }

    private function client(): PendingRequest
    {
        // indexm.zeldis.ru — самоподписанный сертификат, доверяем именно этому файлу.
        $certFile = base_path('docker/nginx/certs/indexm.crt');

        return Http::withToken($this->token)
            ->withOptions(file_exists($certFile) ? ['verify' => $certFile] : [])
            ->timeout(10);
    }

    /** Описание главной картинки по артикулу; null — артикул не найден или indexM недоступен. */
    public function imageInfo(string $article): ?array
    {
        $resp = $this->client()->acceptJson()->get($this->url.'/api/v1/images', ['article' => $article]);
        return $resp->successful() ? $resp->json() : null;
    }

    /** Сырой ответ по запросу картинки — для «Проверить соединение» (с кодом ответа). */
    public function probe(string $article): \Illuminate\Http\Client\Response
    {
        return $this->client()->acceptJson()->get($this->url.'/api/v1/images', ['article' => $article]);
    }

    /**
     * Файл картинки по постоянной ссылке indexM (preview_url / full_url).
     * @return array{status:int, body:string, type:?string, etag:?string}
     */
    public function file(string $url, ?string $etag = null): array
    {
        $req = $this->client();
        if ($etag) {
            $req = $req->withHeaders(['If-None-Match' => $etag]);
        }
        $resp = $req->get($url);
        return [
            'status' => $resp->status(),
            'body'   => $resp->successful() ? $resp->body() : '',
            'type'   => $resp->header('Content-Type') ?: null,
            'etag'   => $resp->header('ETag') ?: null,
        ];
    }
}
