<div align="center">

# 📅 Planner

**Годовой медиаплан Librederm: кампании, рекламная поддержка и календарь инфоповодов в одном месте**

`v1.0.0` · Laravel 13 · Vue 3 · PostgreSQL 16 · Docker

[Возможности](#-возможности) ·
[Скриншоты](#-скриншоты) ·
[Роли](#-роли) ·
[Как устроено](#-как-устроено) ·
[Установка](#-установка) ·
[Эксплуатация](#-эксплуатация)

</div>

---

Planner заменил одностраничный дашборд `index.html` на бесплатном хостинге и Google-таблицу
за ним. Данные теперь живут в своей базе, правятся в формах с проверками и правами доступа,
а таймлайн и выгрузка в PowerPoint остались такими же, к каким все привыкли.

🌐 **https://planner.zeldis.ru:8444** (пока нет DNS-записи — `https://192.168.7.99:8444`)

## ✨ Возможности

| | |
|---|---|
| 🗓 **Таймлайн** | Диаграмма Ганта по месяцам, цвет — коллекции, разворот флайта по активностям, фильтры по году, коллекции, статусу и направлению. «Завершено» приглушено, «Отменено» скрыто по умолчанию. |
| 🌤 **Слой контекста** | Поводы, сезонность, события и лончи — отдельной полосой над кампаниями. |
| 🗂 **Карточка флайта** | ЦА, клейм, БМ, бриф, материалы, активности и SKU **с картинками из [indexM](https://indexm.zeldis.ru)**. |
| ✏️ **Формы** | Флайт и его активности: зависимые списки «направление → рекламный блок», SKU только из коллекции флайта, наследуемые значения показаны подсказкой. |
| 📊 **PowerPoint** | Выгрузка презентации за год с учётом фильтров; в слайдах кампаний — картинки SKU. |
| 📚 **Справочники** | Коллекции, 750+ SKU с артикулами, направления, рекламные блоки, статусы, типы контекста. |
| 🔐 **Роли** | БМ правит только свои коллекции; журнал изменений флайтов и активностей. |
| 📥 **Импорт** | Однократный перенос всего из Google-таблицы одной командой. |

## 📸 Скриншоты

<table>
<tr>
<td width="50%"><img src="docs/screenshots/timeline.png" alt="Таймлайн"><br><sub><b>Таймлайн</b> — флайты 2026 года</sub></td>
<td width="50%"><img src="docs/screenshots/card.png" alt="Карточка флайта"><br><sub><b>Карточка флайта</b> — SKU с картинками из indexM, активности</sub></td>
</tr>
<tr>
<td width="50%"><img src="docs/screenshots/flight.png" alt="Форма флайта"><br><sub><b>Форма флайта</b> — ЦА и клейм наследуются из коллекции</sub></td>
<td width="50%"><img src="docs/screenshots/references.png" alt="Справочники"><br><sub><b>Справочники</b> — всё, что раньше было листами СПР_*</sub></td>
</tr>
</table>

## 👥 Роли

| Роль | Таймлайн, PPTX | Флайты, активности, контекст | Справочники | Пользователи, настройки |
|---|:-:|:-:|:-:|:-:|
| **Администратор** | ✅ | ✅ все | ✅ | ✅ |
| **Редактор** | ✅ | ✅ все | ✅ | — |
| **Бренд-менеджер** | ✅ | ✅ своих коллекций | 👁 | — |
| **Просмотр** | ✅ | 👁 | 👁 | — |

Коллекции бренд-менеджера назначает администратор в разделе «Пользователи». Контекст без
коллекции («общий») правит редактор.

## 🧩 Как устроено

```mermaid
flowchart LR
    U([Сотрудники]) -->|https :8444| N[nginx]
    N --> A[app<br/>Laravel 13 + Vue 3]
    A --> P[(PostgreSQL 16)]
    A -->|API v1, Bearer-токен| I[indexM<br/>главные картинки SKU]
    A -.->|кэш картинок, ETag| S[(storage/sku-images)]
    G[(Google-таблица)] -.->|planner:import-sheet<br/>однократно| A
```

Три контейнера, без Redis и S3: кэш и сессии — в PostgreSQL, картинки SKU — в файловом кэше.
Весь стек — один каталог плюс дамп базы, поэтому его легко перенести на другой сервер.

### Модель данных

```mermaid
erDiagram
    COLLECTION ||--o{ SKU : "содержит"
    COLLECTION ||--o{ FLIGHT : "кампании"
    COLLECTION }o--o{ USER : "БМ коллекции"
    FLIGHT }o--|| STATUS : ""
    FLIGHT }o--o{ DIRECTION : "отмеченные направления"
    FLIGHT }o--o{ SKU : "SKU флайта"
    FLIGHT ||--o{ ACTIVITY : "рекламная поддержка"
    ACTIVITY }o--|| DIRECTION : ""
    ACTIVITY }o--o| BLOCK : "рекламный блок"
    ACTIVITY }o--o{ SKU : "свои SKU"
    DIRECTION ||--o{ BLOCK : ""
    CONTEXT_ITEM }o--|| CONTEXT_TYPE : ""
    CONTEXT_ITEM }o--o| COLLECTION : ""
```

**Наследование — как было в таблице.** В базе хранятся только собственные значения, итоговые
считаются на лету:

```
Коллекция ──► Флайт ──► Активность
  БМ            ЦА        даты
  ЦА            клейм     SKU
  клейм         даты      ЦА
                SKU       клейм
```

Пустое поле флайта берёт значение коллекции, пустое поле активности — значение флайта.

### Картинки SKU из indexM

Браузер запрашивает `/sku-image/{артикул}`, а Planner сам идёт в
[API indexM](https://indexm.zeldis.ru) за главной обложкой SKU — токен indexM в браузер не
попадает. Картинка кэшируется на диске и раз в сутки сверяется по ETag; «картинки нет»
тоже запоминается на сутки. Если indexM недоступен, страницы работают без картинок.

### Таймлайн

`/timeline` — прежний `index.html`, перенесённый почти без изменений: его JavaScript получает
данные в том же формате, что раньше отдавал Google Apps Script, только из базы Planner
(`TimelineController`). Страница пересобирается из исходного файла скриптом
[`tools/build_timeline.py`](tools/build_timeline.py) — все отличия от оригинала там
перечислены точечными правками.

> Активности связываются с флайтом по названию, поэтому название флайта уникально.

## 📁 Структура

```
app/
├── Console/Commands/      planner:import-sheet, planner:create-admin
├── Http/Controllers/      Flight, Context, References, Timeline, SkuImage, User, Settings
├── Models/                Collection, Sku, Direction, Block, Status, ContextType,
│                          Flight, Activity, ContextItem, User (+ журнал изменений)
└── Services/IndexmClient  клиент API indexM
resources/js/Pages/        Flights, Context, References, Users, Settings (Inertia + Vue 3)
resources/views/timeline   страница таймлайна
public/timeline-assets/    JS/CSS таймлайна и PptxGenJS 3.12
tools/build_timeline.py    сборка таймлайна из прежнего index.html
docker/                    nginx (8082 → 8444), php 8.4-fpm
```

## 🚀 Установка

```bash
git clone https://zgit.zeldis.lan/rolsky/planner.git /var/www/planner && cd /var/www/planner
cp .env.example .env                      # задать DB_PASSWORD

# сертификаты: свой (самоподписанный) и сертификат indexM, которому доверяем
mkdir -p docker/nginx/certs
openssl req -x509 -nodes -newkey rsa:2048 -days 3650 \
  -keyout docker/nginx/certs/planner.key -out docker/nginx/certs/planner.crt \
  -subj "/CN=planner.zeldis.ru" -addext "subjectAltName=DNS:planner.zeldis.ru,IP:192.168.7.99"
cp /var/www/indexm/docker/nginx/certs/indexm.crt docker/nginx/certs/

docker compose up -d --build
docker compose exec app composer install --no-dev -o
docker compose exec app php artisan key:generate
docker compose exec app php artisan migrate --force
docker run --rm -v "$PWD":/app -w /app node:22-alpine sh -c 'npm ci && npm run build'
docker compose exec app chown -R www-data:www-data storage bootstrap/cache
docker compose exec app php artisan planner:create-admin admin@zeldis.ru "Администратор"
```

Затем **Настройки → indexM**: адрес и токен подключения «Planner» из indexM
(Настройки → Интеграции → «Внешние API»), кнопка «Проверить соединение».

> ⚠️ С сервера 192.168.7.99 закрыт доступ к packagist.org (GitHub открыт). `composer install`
> работает по `composer.lock`, а `composer update` и `composer require` — нет: lock-файл
> обновлять там, где packagist доступен.

### Перенос данных из Google-таблицы

```bash
curl -L -o _import/sheet.xlsx 'https://docs.google.com/spreadsheets/d/<id>/export?format=xlsx'
docker compose exec app php artisan planner:import-sheet _import/sheet.xlsx
```

Команда идемпотентна: справочники и флайты сопоставляются по названию, SKU — по артикулу или
полному названию, а несопоставленное попадает в отчёт. Активности флайта пересоздаются
целиком, поэтому после начала работы в Planner повторно её не запускают.

## 🔧 Эксплуатация

```bash
docker compose exec app php artisan down
git pull
docker compose exec app php artisan migrate --force
docker run --rm -v "$PWD":/app -w /app node:22-alpine npm run build
docker compose exec app php artisan optimize:clear
docker compose exec app php artisan up
```

| Задача | Как |
|---|---|
| Резервная копия | `docker compose exec postgres pg_dump -U planner_user -Fc planner > planner.dump` |
| Перенос на другой сервер | каталог проекта + дамп базы; адрес и токен indexM меняются в Настройках |
| Сброс пароля администратора | `php artisan planner:create-admin <email> "<имя>"` |
| Сброс кэша картинок | удалить `storage/app/private/sku-images` |

---

<div align="center"><sub>История изменений — <a href="CHANGELOG.md">CHANGELOG.md</a></sub></div>
