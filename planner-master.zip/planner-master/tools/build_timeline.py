"""Собирает страницу таймлайна Planner из прежнего index.html (Librederm Campaign Planner).

Отрисовка (Ганта, контекст, карточка, PPTX) переносится как есть; правки — точечные:
источник данных (Planner вместо Apps Script), ссылки на формы Planner, SKU с картинками.
Запуск: python build_timeline.py <index.html> <каталог проекта planner>
"""
import os
import sys

src, root = sys.argv[1], sys.argv[2]
lines = open(src, encoding='utf-8').read().split('\n')


def block(start_marker, end_marker, after=0):
    s = next(i for i, l in enumerate(lines) if l.strip().startswith(start_marker) and i >= after)
    e = next(i for i, l in enumerate(lines) if l.strip().startswith(end_marker) and i > s)
    return s, e


def patch(text, old, new, count=1):
    assert text.count(old) == count, f'ожидалось {count} вхождений: {old[:80]!r} (найдено {text.count(old)})'
    return text.replace(old, new)


# ── CSS ───────────────────────────────────────────────────────────────────
s, e = block('<style>', '</style>')
css = '\n'.join(lines[s + 1:e])
css += '''

/* ── Planner ─────────────────────────────────────────────────────────── */
.planner-menu { position:relative; }
.planner-menu > summary { list-style:none; cursor:pointer; }
.planner-menu > summary::-webkit-details-marker { display:none; }
.planner-menu-list { position:absolute; right:0; top:calc(100% + 6px); z-index:1100; min-width:190px; background:#fff;
  border:1px solid var(--border, #e5e7eb); border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,.12); padding:6px; display:flex; flex-direction:column; }
.planner-menu-list a, .planner-menu-list button { font:inherit; font-size:12.5px; text-align:left; color:var(--text-secondary, #374151);
  padding:7px 10px; border-radius:6px; text-decoration:none; background:none; border:0; cursor:pointer; }
.planner-menu-list a:hover, .planner-menu-list button:hover { background:#f3f4f6; color:#111827; }
.planner-menu-list hr { border:0; border-top:1px solid var(--border, #e5e7eb); margin:4px 0; }
.sku-cards { display:flex; flex-direction:column; gap:6px; }
.sku-card { display:flex; align-items:center; gap:10px; font-size:12px; color:var(--text-secondary); }
.sku-card img { width:44px; height:44px; object-fit:contain; border-radius:6px; background:#f9fafb; border:1px solid #eef0f3; flex:none; }
.sku-card .sku-noimg { width:44px; height:44px; border-radius:6px; background:#f3f4f6; flex:none; display:flex; align-items:center; justify-content:center; color:#c0c4cc; font-size:16px; }
.sku-card .sku-art { color:var(--text-muted); font-size:11px; }
'''

# ── Разметка ──────────────────────────────────────────────────────────────
s, e = block('<body>', '<script>')
body = '\n'.join(lines[s + 1:e])
body = patch(body, '<div class="topbar-logo">Librederm <span>Planner</span></div>',
             '<a href="/timeline" class="topbar-logo" style="text-decoration:none">Librederm <span>Planner</span></a>')
s2 = body.index('<a id="sheetLink"')
e2 = body.index('</a>', s2) + len('</a>')
# разделы Planner — компактным меню, чтобы не теснить фильтры верхней панели
body = body[:s2] + ('<details class="planner-menu"><summary class="btn">Разделы ▾</summary>\n'
                    '      <div class="planner-menu-list">\n'
                    '        <a href="/flights">Флайты</a><a href="/flights/create" data-writer>+ Новый флайт</a>\n'
                    '        <a href="/context">Контекст</a><a href="/references">Справочники</a>\n'
                    '        <a href="/users" data-admin>Пользователи</a><a href="/settings" data-admin>Настройки</a><hr>\n'
                    '        <form method="POST" action="/logout"><input type="hidden" name="_token" value="__CSRF__">'
                    '<button type="submit">Выйти</button></form>\n'
                    '      </div></details>') + body[e2:]
body = patch(body, 'Загрузка данных из таблицы…', 'Загрузка…')
body = patch(body, '''          Учитывать текущие фильтры
        </label>''', '''          Учитывать текущие фильтры
        </label>
        <label class="modal-check">
          <input type="checkbox" id="expImages" checked>
          Картинки SKU из indexM (полная презентация)
        </label>''')
# разметка идёт в Blade как есть — в ней не должно быть Blade-синтаксиса
assert '@' not in body and '{{' not in body and '{!!' not in body

# ── JS ────────────────────────────────────────────────────────────────────
s = next(i for i, l in enumerate(lines) if l.strip() == '<script>' and i > e - 1)
e = next(i for i, l in enumerate(lines) if l.strip() == '</script>' and i > s)
js = '\n'.join(lines[s + 1:e])

# Данные — из Planner (первая порция встроена в страницу, обновление — /timeline/data)
a = js.index('// ── APPS SCRIPT DATA LOADING')
b = js.index('async function initData() {')
js = js[:a] + '''// ── ДАННЫЕ PLANNER ─────────────────────────────────────────────────
// Формат — как у прежнего Apps Script (строки листов таблицы), см. TimelineController.
async function fetchAllData(fresh) {
  let json = window.PLANNER_DATA;
  if (fresh) {
    const resp = await fetch('/timeline/data', { credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    json = await resp.json();
  }

  const col = parseCollections(json.collections || []);
  allCollections = col.collections;
  colorMap = col.colorMap;
  allFlights = parseFlights(json.flights || []);
  allActivities = parseActivities(json.activities || []);
  allContext = parseContextRows(json.context || []);
}

''' + js[b:]

a = js.index("  if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL === 'ВСТАВЬ_URL_ЗДЕСЬ') {")
b = js.index("  setStatus(false, 'Загрузка...');", a)
js = js[:a] + js[b:]
js = patch(js, '''        await fetchAllData();
        setStatus(true, 'Данные обновлены');''', '''        await fetchAllData(true);
        setStatus(true, 'Данные обновлены');''')
js = patch(js, "${err.message || 'Проверьте URL Apps Script и права доступа'}", "${err.message || 'Обновите страницу'}")
js = patch(js, "    specDocUrl:    (r[26]||'').trim(),\n", "    specDocUrl:    (r[26]||'').trim(),\n    extra:         r[27] || {},\n")

# Карточка флайта: ссылка на форму Planner и SKU с картинками из indexM
js = patch(js, '''  if (flight.claimFinal) sec1.appendChild(mkRow('Клейм', flight.claimFinal));
  body.appendChild(sec1);
''', '''  if (flight.claimFinal) sec1.appendChild(mkRow('Клейм', flight.claimFinal));
  if (flight.extra.id) {
    const link = document.createElement('a');
    link.href = '/flights/' + flight.extra.id;
    link.className = 'btn';
    link.style.cssText = 'display:inline-flex;margin-top:8px';
    link.textContent = flight.extra.can_edit ? 'Редактировать в Planner →' : 'Открыть карточку →';
    sec1.appendChild(link);
  }
  body.appendChild(sec1);
''')
js = patch(js, '''  const skus = [flight.sku1, flight.sku2, flight.sku3].filter(Boolean);
  if (skus.length) {
    const secS = mkSection('SKU');
    const skuList = document.createElement('div');
    skuList.className = 'sku-list';
    skus.forEach(s => {
      const t = document.createElement('div');
      t.className = 'tag';
      t.textContent = s;
      skuList.appendChild(t);
    });
    secS.appendChild(skuList);
    body.appendChild(secS);
  }''', '''  const skuItems = flight.extra.skus || [];
  if (skuItems.length) {
    const secS = mkSection(`SKU (${skuItems.length})`);
    const skuList = document.createElement('div');
    skuList.className = 'sku-cards';
    skuItems.forEach(s => {
      const row = document.createElement('div');
      row.className = 'sku-card';
      const ph = document.createElement('div');
      ph.className = 'sku-noimg';
      ph.textContent = '▢';
      if (s.article) {
        // картинка — главная обложка SKU в indexM (через сервер Planner, с кэшем)
        const img = document.createElement('img');
        img.loading = 'lazy';
        img.alt = '';
        img.src = '/sku-image/' + encodeURIComponent(s.article) + '?size=preview';
        img.onerror = () => img.replaceWith(ph);
        row.appendChild(img);
      } else {
        row.appendChild(ph);
      }
      const t = document.createElement('div');
      t.textContent = s.name;
      if (s.article) {
        const art = document.createElement('div');
        art.className = 'sku-art';
        art.textContent = 'арт. ' + s.article;
        t.appendChild(art);
      }
      row.appendChild(t);
      skuList.appendChild(row);
    });
    secS.appendChild(skuList);
    body.appendChild(secS);
  }''')
# статус в карточке — название из справочника Planner
js = patch(js, "  sec1.appendChild(mkRow('Статус', statusBadgeHtml(flight.status)));",
           "  sec1.appendChild(mkRow('Статус', statusBadgeHtml(flight.status) + (flight.extra.status && norm(flight.extra.status) !== flight.status ? ' <span style=\"color:var(--text-muted)\">' + flight.extra.status + '</span>' : '')));")

# PPTX: картинки SKU в слайдах кампаний (подгружаются заранее; нет картинки — пропуск)
js = patch(js, """function _generatePptx(data) {
  _buildPptx(data);
}""", """// Картинки SKU для слайдов кампаний: article → dataURL (через /sku-image, с кэшем Planner)
let SKU_IMG = {};
async function _loadSkuImages(flights) {
  const arts = [...new Set(flights.flatMap(f => (f.extra && f.extra.skus || []).slice(0, 3).map(s => s.article)).filter(Boolean))];
  const out = {};
  await Promise.all(arts.map(async (a) => {
    try {
      const r = await fetch('/sku-image/' + encodeURIComponent(a) + '?size=preview', { credentials: 'same-origin' });
      if (!r.ok) return;
      const blob = await r.blob();
      out[a] = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(blob); });
    } catch (e) { /* без картинки */ }
  }));
  return out;
}

async function _generatePptx(data) {
  const btn = document.getElementById('exportDoBtn');
  if (btn) btn.disabled = true;
  try {
    SKU_IMG = document.getElementById('expImages') && !document.getElementById('expImages').checked ? {} : await _loadSkuImages(data.flights);
  } finally {
    if (btn) btn.disabled = false;
  }
  _buildPptx(data);
}""")
js = patch(js, r"""      s.addText(skus.join('\n'), {
        x:0.45, y:2.2, w:3.8, h:0.8,
        fontSize:9, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.3,
        isTextBox:true,
      });
    }""", r"""      s.addText(skus.join('\n'), {
        x:0.45, y:2.2, w:3.8, h:0.8,
        fontSize:9, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.3,
        isTextBox:true,
      });
      // Planner: картинки SKU (главная обложка в indexM) правее списка
      ((f.extra && f.extra.skus) || []).slice(0, 3).forEach((sk, i) => {
        const img = sk.article && SKU_IMG[sk.article];
        if (img) s.addImage({ data: img, x: 4.4 + i * 0.95, y: 2.1, w: 0.85, h: 0.85, sizing: { type: 'contain', w: 0.85, h: 0.85 } });
      });
    }""")

# Показ ссылок по ролям
js += '''

// ── Planner: пункты меню по ролям ──────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  const u = (window.PLANNER_DATA || {}).user || {};
  document.querySelectorAll('[data-admin]').forEach(el => { if (!u.is_admin) el.remove(); });
  document.querySelectorAll('[data-writer]').forEach(el => { if (!u.can_write) el.remove(); });
  document.addEventListener('click', (e) => {
    document.querySelectorAll('details.planner-menu[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); });
  });
});
'''

# ── PptxGenJS (как был встроен в index.html) ──────────────────────────────
s = next(i for i, l in enumerate(lines) if l.startswith('/* PptxGenJS'))
pptx = '\n'.join(lines[s:s + 3]).replace('//# sourceMappingURL=pptxgen.bundle.js.map', '')

# ── Запись ────────────────────────────────────────────────────────────────
out = os.path.join(root, 'public', 'timeline-assets')
os.makedirs(out, exist_ok=True)
for name, content in [('timeline.css', css), ('timeline.js', js), ('pptxgen.bundle.js', pptx)]:
    with open(os.path.join(out, name), 'w', encoding='utf-8', newline='\n') as f:
        f.write(content)

blade = '''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Таймлайн · Planner</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/timeline-assets/timeline.css?v={{ $v }}">
</head>
<body>
''' + body.replace('__CSRF__', '{{ csrf_token() }}') + '''
<script>window.PLANNER_DATA = @json($data);</script>
<script src="/timeline-assets/timeline.js?v={{ $v }}"></script>
<script src="/timeline-assets/pptxgen.bundle.js?v=3.12.0"></script>
</body>
</html>
'''
with open(os.path.join(root, 'resources', 'views', 'timeline.blade.php'), 'w', encoding='utf-8', newline='\n') as f:
    f.write(blade)
print('css', len(css), 'js', len(js), 'pptx', len(pptx), 'body', len(body))
