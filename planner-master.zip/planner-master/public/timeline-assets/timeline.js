'use strict';

// ── CONSTANTS ──────────────────────────────────────────────────────
const SHEET_ID = '1fyorvNyY20cQLnVtEbXOvqhygbM9BYaK-uvH1I2YEOk';
const MCP_SERVER = 'Google Sheets';
const TODAY = new Date();
TODAY.setHours(0,0,0,0);

// ── SCALE ────────────────────────────────────────────────────────────
const DAY_PX = 4;

const STATUS_LABELS = {
  'план': 'План',
  'подтверждено': 'Подтверждено',
  'завершено': 'Завершено',
  'отменено': 'Отменено'
};

// Direction color map (visual only, not from sheet)
const DIR_COLORS = {
  'media':    { bg: '#DBEAFE', text: '#1D4ED8' },
  'press':    { bg: '#FCE7F3', text: '#BE185D' },
  'digital':  { bg: '#E0E7FF', text: '#4338CA' },
  'bloggers': { bg: '#D1FAE5', text: '#065F46' },
  'pr':       { bg: '#FEF9C3', text: '#854D0E' },
  'ecom':     { bg: '#F3E8FF', text: '#7E22CE' },
  'offline':  { bg: '#FFEDD5', text: '#9A3412' },
  'med':      { bg: '#F0FDF4', text: '#166534' },
};
function dirColor(dir='') {
  const k = dir.toLowerCase().replace(/[^a-z]/g,'');
  return DIR_COLORS[k] || { bg: '#F3F4F6', text: '#374151' };
}

// ── STATE ──────────────────────────────────────────────────────────
let allFlights = [];
let allActivities = [];
let allContext = [];
let allCollections = [];
let colorMap = {}; // slug → hex

let visibleFlights = [];
let expandedFlights = new Set();
let viewStart = null;
let viewEnd = null;
let totalDays = 0;
let loadCount = 0;
let dataReady = false;

// ── PARSE HELPERS ──────────────────────────────────────────────────
function parseDate(s='') {
  if (!s) return null;
  s = s.trim();
  // DD.MM.YYYY
  const m1 = s.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
  if (m1) return new Date(+m1[3], +m1[2]-1, +m1[1]);
  // YYYY-MM-DD
  const m2 = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m2) return new Date(+m2[1], +m2[2]-1, +m2[3]);
  return null;
}
function fmtDate(d) {
  if (!d) return '—';
  return d.toLocaleDateString('ru-RU', { day:'2-digit', month:'short', year:'numeric' });
}
function fmtShort(d) {
  if (!d) return '—';
  return d.toLocaleDateString('ru-RU', { day:'2-digit', month:'short' });
}
function norm(s='') { return s.trim().toLowerCase(); }

// ── PARSE SHEETS ──────────────────────────────────────────────────
function parseCollections(rows) {
  const out = [];
  const map = {};
  for (const r of rows) {
    if (!r[0]) continue;
    const active = norm(r[5]||'');
    if (active === 'false' || active === '0' || active === 'нет') continue;
    const slug = norm(r[0]);
    const color = (r[1]||'').trim().replace(/^#/,'');
    const hex = color ? '#'+color : '#A0AEC0';
    out.push({ name: r[0].trim(), slug, colorHex: hex, bm: r[2]||'', ta: r[3]||'', claim: r[4]||'' });
    map[slug] = hex;
  }
  return { collections: out, colorMap: map };
}

function parseFlights(rows) {
  return rows.map(r => ({
    name:          (r[0]||'').trim(),
    collection:    norm(r[1]||''),
    dateStart:     parseDate(r[2]),
    dateEnd:       parseDate(r[3]),
    status:        norm(r[4]||''),
    bm:            (r[5]||'').trim(),
    taDefault:     (r[6]||'').trim(),
    taOverride:    (r[7]||'').trim(),
    taFinal:       (r[8]||'').trim(),
    claimDefault:  (r[9]||'').trim(),
    claimOverride: (r[10]||'').trim(),
    claimFinal:    (r[11]||'').trim(),
    sku1:          (r[12]||'').trim(),
    sku2:          (r[13]||'').trim(),
    sku3:          (r[14]||'').trim(),
    brief:         (r[23]||'').trim(),
    materialsUrl:  (r[24]||'').trim(),
    comment:       (r[25]||'').trim(),
    specDocUrl:    (r[26]||'').trim(),
    extra:         r[27] || {},
  })).filter(f => f.name && f.dateStart && f.dateEnd);
}

function parseActivities(rows) {
  return rows.map(r => ({
    flightName:   (r[0]||'').trim(),
    direction:    (r[1]||'').trim(),
    block:        (r[2]||'').trim(),
    dateStart:    parseDate(r[5]) || parseDate(r[3]),
    dateEnd:      parseDate(r[6]) || parseDate(r[4]),
    platforms:    (r[7]||'').trim(),
    format:       (r[8]||'').trim(),
    skuFinal:     (r[12]||'').trim(),
    taFinal:      (r[14]||'').trim(),
    claimFinal:   (r[16]||'').trim(),
    collection:   norm(r[20]||''),
    comment:      (r[21]||'').trim(),
    bm:           (r[22]||'').trim(),
  })).filter(a => a.flightName && a.dateStart && a.dateEnd);
}

function parseContextRows(rows) {
  return rows.map(r => ({
    type:        (r[0]||'').trim(),
    name:        (r[1]||'').trim(),
    dateStart:   parseDate(r[2]),
    dateEnd:     parseDate(r[3]),
    collection:  (r[4]||'').trim(),
    comment:     (r[5]||'').trim(),
    color:       (r[6]||'').trim() || null,
    active:      norm(r[7]||'') !== 'false' && norm(r[7]||'') !== '0' && norm(r[7]||'') !== 'нет'
  })).filter(c => c.name && c.dateStart && c.dateEnd && c.active);
}

function contextColor(type='', fallback='') {
  if (fallback) return fallback.startsWith('#') ? fallback : '#'+fallback;
  const map = {
    'повод': '#fef3c7',
    'сезонность': '#dbeafe',
    'событие': '#ede9fe',
    'лонч': '#d1fae5',
  };
  return map[type.toLowerCase()] || '#E5E7EB';
}

// Short display labels for context items (UI-only, data unchanged)
const CTX_SHORT_LABELS = {
  'Международный женский день': '8 Марта',
  'День защитника Отечества': '23 Фев',
  'День гиалуроновой кислоты': 'Гиалурон',
  'День коллагена': 'Коллаген',
  'Международный день красоты': 'День красоты',
  'Международный день заботы о себе': 'Забота о себе',
  'День губной помады': 'Губная помада',
  'Месяц осведомлённости об алопеции': 'Алопеция',
  'Месяц здорового старения': 'Здоровое старение',
  'Возвращение в школу / 1 сентября': 'Back to school',
  'Возвращение в школу': 'Back to school',
  '1 сентября': 'Back to school',
  'Международный мужской день': 'Мужской день',
  'Черная пятница': 'Черная пятница',
  'Новогодний сезон': 'Новый год',
  // Сезонность — strip "Сезон " prefix via regex, also explicit map
  'Сезон сухой кожи': 'Сухая кожа',
  'Сезон солнца и загара': 'Солнце и загар',
  'Сезон повышенного внимания к пигментации': 'Пигментация',
  'Сезон антиперспирантов': 'Антиперспиранты',
  'Сезон интенсивного ухода за волосами': 'Уход за волосами',
  'Сезон проблемной кожи': 'Проблемная кожа',
  'Сезон педикулёза': 'Педикулёз',
  'Сезон простуд': 'Простуды',
  'Сезон anti-age ухода': 'Anti-age',
  'Сезон ухода за губами': 'Губы',
};

function ctxShortLabel(name, type='') {
  if (!name) return '';
  if (CTX_SHORT_LABELS[name]) return CTX_SHORT_LABELS[name];
  const t = type.toLowerCase();
  if (t === 'сезонность') return name.replace(/^Сезон\s+/i, '');
  if (t === 'лонч') return name.replace(/^Запуск\s+/i, '');
  return name;
}

// Context type display labels and badge colors
const CTX_TYPE_META = {
  'повод':      { label: 'Повод',      bg: '#fef3c7', text: '#92400e', border: '#f59e0b' },
  'сезонность': { label: 'Сезонность', bg: '#dbeafe', text: '#1e40af', border: '#93c5fd' },
  'событие':    { label: 'Событие',    bg: '#ede9fe', text: '#4c1d95', border: '#c4b5fd' },
  'лонч':       { label: 'Лонч',       bg: '#d1fae5', text: '#064e3b', border: '#6ee7b7' },
};
function ctxTypeMeta(type='') {
  return CTX_TYPE_META[type.toLowerCase()] || { label: type, bg: '#f3f4f6', text: '#374151', border: '#d1d5db' };
}

// ── COMPUTE VIEW RANGE ─────────────────────────────────────────────
function computeViewRange() {
  const year = document.getElementById('filterYear').value;

  // Year scale — use data range or selected year
  const dates = [];
  for (const f of visibleFlights) {
    if (f.dateStart) dates.push(f.dateStart);
    if (f.dateEnd) dates.push(f.dateEnd);
  }
  for (const c of allContext) {
    if (c.dateStart) dates.push(c.dateStart);
    if (c.dateEnd) dates.push(c.dateEnd);
  }
  if (!dates.length) {
    const y = year ? +year : TODAY.getFullYear();
    viewStart = new Date(y, 0, 1);
    viewEnd   = new Date(y, 11, 31);
  } else {
    // When year filter is set, show that full year
    if (year) {
      viewStart = new Date(+year, 0, 1);
      viewEnd   = new Date(+year, 11, 31);
    } else {
      viewStart = new Date(Math.min(...dates));
      viewEnd   = new Date(Math.max(...dates));
      viewStart = new Date(viewStart.getTime() - 14*86400000);
      viewEnd   = new Date(viewEnd.getTime() + 14*86400000);
      // snap to month boundaries
      viewStart = new Date(viewStart.getFullYear(), viewStart.getMonth(), 1);
      viewEnd   = new Date(viewEnd.getFullYear(), viewEnd.getMonth()+1, 0);
    }
  }

  totalDays = Math.round((viewEnd - viewStart) / 86400000) + 1;
}

function dayOffset(d) {
  if (!d) return 0;
  return Math.round((d - viewStart) / 86400000);
}
function barLeft(d) { return dayOffset(d) * DAY_PX; }
function barWidth(s, e) {
  const w = (dayOffset(e) - dayOffset(s) + 1) * DAY_PX;
  return Math.max(w, 4);
}

// ── FILTERS ────────────────────────────────────────────────────────
function applyFilters() {
  const year   = document.getElementById('filterYear').value;
  const col    = document.getElementById('filterCollection').value;
  const status = document.getElementById('filterStatus').value;
  const dir    = document.getElementById('filterDirection').value;

  visibleFlights = allFlights.filter(f => {
    // Hide cancelled flights unless user explicitly selected "отменено"
    if (f.status === 'отменено' && status !== 'отменено') return false;
    if (status && f.status !== status) return false;
    if (col && f.collection !== col) return false;
    if (year) {
      const fy = f.dateStart?.getFullYear();
      const ey = f.dateEnd?.getFullYear();
      if (fy != year && ey != year) return false;
    }
    if (dir) {
      const acts = allActivities.filter(a => norm(a.flightName) === norm(f.name));
      if (!acts.some(a => norm(a.direction) === norm(dir))) return false;
    }
    return true;
  });

  computeViewRange();
  renderGantt();
}

// ── POPULATE FILTERS ───────────────────────────────────────────────
function populateFilters() {
  // Years
  const years = [...new Set(allFlights.flatMap(f => {
    const yy = [];
    if (f.dateStart) yy.push(f.dateStart.getFullYear());
    if (f.dateEnd) yy.push(f.dateEnd.getFullYear());
    return yy;
  }))].sort();
  const ySelect = document.getElementById('filterYear');
  ySelect.innerHTML = '<option value="">Все годы</option>';
  years.forEach(y => {
    const o = document.createElement('option');
    o.value = y; o.textContent = y;
    ySelect.appendChild(o);
  });

  // Collections
  const cSelect = document.getElementById('filterCollection');
  cSelect.innerHTML = '<option value="">Все коллекции</option>';
  allCollections.forEach(c => {
    const o = document.createElement('option');
    o.value = c.slug; o.textContent = c.name;
    cSelect.appendChild(o);
  });

  // Directions
  const dirs = [...new Set(allActivities.map(a => a.direction).filter(Boolean))].sort();
  const dSelect = document.getElementById('filterDirection');
  dSelect.innerHTML = '<option value="">Все направления</option>';
  dirs.forEach(d => {
    const o = document.createElement('option');
    o.value = norm(d); o.textContent = d;
    dSelect.appendChild(o);
  });
}

// ── RENDER GANTT ───────────────────────────────────────────────────
function renderGantt() {
  const container = document.getElementById('ganttContainer');
  container.innerHTML = '';
  container.style.display = 'grid';
  container.style.gridTemplateColumns = `300px ${totalDays * DAY_PX}px`;
  container.style.minWidth = `${300 + totalDays * DAY_PX}px`;

  // Header row
  renderHeader(container);

  // Context row
  renderContextRow(container);

  // Flight rows
  const activeDir = document.getElementById('filterDirection').value;
  for (const flight of visibleFlights) {
    renderFlightRow(container, flight);
    if (expandedFlights.has(flight.name)) {
      let acts = allActivities.filter(a => norm(a.flightName) === norm(flight.name));
      // When direction filter is active, show only matching activities in expanded view
      if (activeDir) {
        acts = acts.filter(a => norm(a.direction) === norm(activeDir));
      }
      for (const act of acts) {
        renderActivityRow(container, act, flight);
      }
    }
  }

  if (!visibleFlights.length) {
    const empty = document.createElement('div');
    empty.style.gridColumn = '1/-1';
    empty.innerHTML = '<div class="empty-state">Нет данных для выбранных фильтров</div>';
    container.appendChild(empty);
  }

  // Today line (inside timeline column)
  const tl = document.querySelector('.timeline-header') || container;
  // We inject into the first timeline-cell for overlay
}

function renderHeader(container) {
  // Label col header
  const lh = document.createElement('div');
  lh.className = 'label-header';
  lh.textContent = 'Флайт / Активность';
  container.appendChild(lh);

  // Timeline header
  const th = document.createElement('div');
  th.className = 'timeline-header';
  th.style.width = `${totalDays * DAY_PX}px`;

  const mr = document.createElement('div');
  mr.className = 'months-row';
  mr.style.width = `${totalDays * DAY_PX}px`;
  mr.style.position = 'relative';

  // Generate months
  let cur = new Date(viewStart);
  while (cur <= viewEnd) {
    const monthStart = new Date(cur.getFullYear(), cur.getMonth(), 1);
    const monthEnd = new Date(cur.getFullYear(), cur.getMonth()+1, 0);
    const clampedStart = cur > viewStart ? cur : viewStart;
    const daysInView = Math.min(
      Math.round((monthEnd - clampedStart)/86400000)+1,
      totalDays - dayOffset(clampedStart)
    );
    const left = barLeft(clampedStart);

    const mc = document.createElement('div');
    mc.className = 'month-cell';
    if (cur.getMonth() === TODAY.getMonth() && cur.getFullYear() === TODAY.getFullYear()) {
      mc.classList.add('today-month');
    }
    mc.style.position = 'absolute';
    mc.style.left = left + 'px';
    mc.style.width = (daysInView * DAY_PX) + 'px';

    const ml = document.createElement('div');
    ml.className = 'month-label';
    ml.textContent = cur.toLocaleDateString('ru-RU', { month:'short' }).replace('.','');

    const my = document.createElement('div');
    my.className = 'month-year';
    my.textContent = cur.getFullYear();

    mc.appendChild(ml);
    mc.appendChild(my);
    mr.appendChild(mc);

    // advance to next month
    cur = new Date(cur.getFullYear(), cur.getMonth()+1, 1);
  }

  // Today line in header
  const todayOff = dayOffset(TODAY);
  if (todayOff >= 0 && todayOff <= totalDays) {
    const tline = document.createElement('div');
    tline.style.cssText = `position:absolute;top:0;bottom:0;left:${todayOff*DAY_PX}px;width:2px;background:#EF4444;z-index:20;pointer-events:none;`;
    mr.appendChild(tline);
  }

  th.appendChild(mr);
  container.appendChild(th);
}

// ── CONTEXT BLOCK REDESIGN ────────────────────────────────────────

// Helpers for placing elements on the timeline with lane-stacking
function ctxBarLeft(d) { return barLeft(d); }
function ctxBarWidth(ds, de) { return Math.max(8, barWidth(ds, de)); }

function addTodayLine(tc) {
  const todayOff = dayOffset(TODAY);
  if (todayOff >= 0 && todayOff <= totalDays) {
    const tl = document.createElement('div');
    tl.style.cssText = `position:absolute;top:0;bottom:0;left:${todayOff*DAY_PX}px;width:2px;background:#EF4444;opacity:.35;z-index:1;pointer-events:none;`;
    tc.appendChild(tl);
  }
}

// Place items in lanes to avoid overlap; return array of {item, lane}
function assignLanes(items, getLeft, getRight) {
  const laneEnds = []; // right edge of last item in each lane
  return items.map(item => {
    const left = getLeft(item);
    const right = getRight(item);
    let lane = 0;
    // Find first free lane; create a new one if all are occupied
    while (laneEnds[lane] !== undefined && laneEnds[lane] > left + 2) lane++;
    laneEnds[lane] = right;
    return { item, lane };
  });
}

function renderContextRow(container) {
  if (!allContext.length) return;

  // ── Shared helpers ───────────────────────────────────────────────

  // Display label: use the full name from data — CSS handles truncation via overflow/ellipsis.
  // Full name always shown in popover. No hardcoded dictionary.
  function povodDisplayLabel(name) {
    return name || '';
  }

  // Collection filter: show item if it matches selected collection OR has no collection (general)
  const colFilter = document.getElementById('filterCollection').value;
  function ctxItemVisible(item) {
    if (!item.active) return false;
    if (!colFilter) return true; // "all" — show everything
    const itemCol = (item.collection || '').trim();
    return !itemCol || itemCol === colFilter;
  }

  // Measure text width
  const _measCtx = document.createElement('canvas').getContext('2d');
  _measCtx.font = '500 8.5px system-ui, sans-serif';
  function measureText(str) { return _measCtx.measureText(str).width; }

  // Make arrow SVG
  function makeArrow(cls) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '10'); svg.setAttribute('height', '10');
    svg.setAttribute('viewBox', '0 0 16 16'); svg.setAttribute('fill', 'none');
    svg.classList.add(cls);
    svg.innerHTML = '<path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>';
    return svg;
  }

  // ── Active povod popover management ─────────────────────────────
  let _activePopover = null;
  function closeActivePopover() {
    if (_activePopover) { _activePopover.remove(); _activePopover = null; }
  }
  document.addEventListener('click', function popoverDismiss(e) {
    if (_activePopover && !_activePopover.contains(e.target)) closeActivePopover();
  }, { capture: true });

  function showPovodPopover(dot, ctx) {
    closeActivePopover();
    const pop = document.createElement('div');
    pop.className = 'ctx-povod-popover';
    pop.style.position = 'fixed';

    // Date
    const dateEl = document.createElement('div');
    dateEl.className = 'ctx-povod-popover-date';
    const isSingleDay = !ctx.dateEnd || Math.round((ctx.dateEnd - ctx.dateStart) / 86400000) <= 1;
    const fmtDate = d => d ? d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) : '';
    dateEl.textContent = isSingleDay
      ? fmtDate(ctx.dateStart)
      : fmtDate(ctx.dateStart) + ' — ' + fmtDate(ctx.dateEnd);
    pop.appendChild(dateEl);

    // Name
    const nameEl = document.createElement('div');
    nameEl.className = 'ctx-povod-popover-name';
    nameEl.textContent = ctx.name || '';
    pop.appendChild(nameEl);

    // Collection
    if (ctx.collection && ctx.collection.trim()) {
      const row = document.createElement('div');
      row.className = 'ctx-povod-popover-row';
      const k = document.createElement('span'); k.className = 'ctx-povod-popover-key'; k.textContent = 'Коллекция';
      const v = document.createElement('span'); v.className = 'ctx-povod-popover-val'; v.textContent = ctx.collection;
      row.appendChild(k); row.appendChild(v);
      pop.appendChild(row);
    }

    // Comment
    if (ctx.comment && ctx.comment.trim()) {
      const row = document.createElement('div');
      row.className = 'ctx-povod-popover-row';
      const k = document.createElement('span'); k.className = 'ctx-povod-popover-key'; k.textContent = 'Комментарий';
      const v = document.createElement('span'); v.className = 'ctx-povod-popover-val'; v.textContent = ctx.comment;
      row.appendChild(k); row.appendChild(v);
      pop.appendChild(row);
    }

    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'ctx-povod-popover-close';
    closeBtn.innerHTML = '×';
    closeBtn.addEventListener('click', e => { e.stopPropagation(); closeActivePopover(); });
    pop.appendChild(closeBtn);

    document.body.appendChild(pop);
    _activePopover = pop;

    // Position near dot
    const dotRect = dot.getBoundingClientRect();
    const popW = 220, popH = 120;
    let left = dotRect.left + 8;
    let top = dotRect.bottom + 4;
    if (left + popW > window.innerWidth - 8) left = window.innerWidth - popW - 8;
    if (top + popH > window.innerHeight - 8) top = dotRect.top - popH - 4;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';

    // Stop propagation so the document click handler doesn't immediately close it
    pop.addEventListener('click', e => e.stopPropagation());
  }

  // ── HEADER ROW ──────────────────────────────────────────────────
  const allExpanded = sessionStorage.getItem('ctx_block_expanded') !== 'false';

  const headerLabel = document.createElement('div');
  headerLabel.className = 'ctx-header-label';

  const mainArrow = makeArrow('ctx-toggle-arrow');
  if (!allExpanded) mainArrow.classList.add('collapsed');
  headerLabel.appendChild(mainArrow);
  headerLabel.append('Контекст');
  container.appendChild(headerLabel);

  const headerTimeline = document.createElement('div');
  headerTimeline.className = 'ctx-header-timeline';
  headerTimeline.style.width = `${totalDays * DAY_PX}px`;
  addTodayLine(headerTimeline);
  container.appendChild(headerTimeline);

  // Track all sub-rows for the master toggle
  const allSubEls = [];

  // Helper: create label + timeline cell pair
  function makeSubRow(labelTextNode, isToggleable) {
    const lc = document.createElement('div');
    lc.className = 'ctx-subrow-label' + (isToggleable ? ' ctx-toggleable' : '');
    if (typeof labelTextNode === 'string') lc.textContent = labelTextNode;
    else lc.appendChild(labelTextNode);
    container.appendChild(lc);

    const tc = document.createElement('div');
    tc.className = 'ctx-subrow-timeline';
    tc.style.width = `${totalDays * DAY_PX}px`;
    container.appendChild(tc);

    if (!allExpanded) { lc.classList.add('ctx-hidden'); tc.classList.add('ctx-hidden'); }
    allSubEls.push(lc, tc);
    return { lc, tc };
  }

  // ── SUB-ROW: СЕЗОННОСТЬ (always visible when block expanded, no individual toggle) ──
  const seasonItems = allContext.filter(c => c.type.toLowerCase() === 'сезонность' && ctxItemVisible(c));

  const seasonLabelNode = document.createElement('span');
  seasonLabelNode.textContent = 'Сезонность';
  const { lc: lcS, tc: tcS } = makeSubRow(seasonLabelNode, false);
  addTodayLine(tcS);

  const seasonAssigned = assignLanes(
    seasonItems,
    c => ctxBarLeft(c.dateStart),
    c => ctxBarLeft(c.dateStart) + ctxBarWidth(c.dateStart, c.dateEnd)
  );
  let maxSeasonLane = 0;
  for (const { item: ctx, lane } of seasonAssigned) {
    maxSeasonLane = Math.max(maxSeasonLane, lane);
    const bar = document.createElement('div');
    bar.className = 'ctx-season-bar';
    bar.style.left = ctxBarLeft(ctx.dateStart) + 'px';
    bar.style.width = ctxBarWidth(ctx.dateStart, ctx.dateEnd) + 'px';
    bar.style.top = (2 + lane * 18) + 'px';
    bar.textContent = ctxShortLabel(ctx.name, ctx.type);
    addCtxPopup(bar, ctx);
    tcS.appendChild(bar);
  }
  const seasonH = Math.max(20, (maxSeasonLane + 1) * 18 + 4);
  lcS.style.minHeight = seasonH + 'px';
  tcS.style.minHeight = seasonH + 'px';

  // ── SUB-ROW: ПОВОДЫ ──────────────────────────────────────────────
  const povodAllItems = allContext
    .filter(c => c.type.toLowerCase() === 'повод' && ctxItemVisible(c))
    .sort((a, b) => a.dateStart - b.dateStart);
  const povodCount = povodAllItems.length;
  const povodExpanded = sessionStorage.getItem('ctx_povod_expanded') === 'true';

  // Build Поводы label with counter + arrow
  const povodLabelFrag = document.createElement('span');
  povodLabelFrag.style.display = 'flex';
  povodLabelFrag.style.alignItems = 'center';
  povodLabelFrag.style.gap = '4px';
  povodLabelFrag.style.width = '100%';

  const povodArrow = makeArrow('ctx-section-arrow');
  if (!povodExpanded) povodArrow.classList.add('collapsed');
  povodLabelFrag.appendChild(povodArrow);

  const povodLabelText = document.createTextNode('Поводы');
  povodLabelFrag.appendChild(povodLabelText);

  const povodCountEl = document.createElement('span');
  povodCountEl.className = 'ctx-section-count';
  povodCountEl.textContent = `(${povodCount})`;
  povodLabelFrag.appendChild(povodCountEl);

  const { lc: lcP, tc: tcP } = makeSubRow(povodLabelFrag, true);
  addTodayLine(tcP);

  // Layout constants
  const DOT_Y       = 12;  // dot vertical center in collapsed row
  const LANE_H      = 14;  // px per label lane
  const LANE_PAD    = 2;   // top pad
  const MAX_LABEL_W = 90;
  const LABEL_GAP   = 3;
  const CLUSTER_GAP = 14 * DAY_PX;

  const singleItems = povodAllItems.filter(c => Math.round((c.dateEnd - c.dateStart) / 86400000) <= 1);
  const multiItems  = povodAllItems.filter(c => Math.round((c.dateEnd - c.dateStart) / 86400000) > 1);

  // Group singles into clusters
  const clusters = [];
  for (const ctx of singleItems) {
    const x = ctxBarLeft(ctx.dateStart);
    const last = clusters[clusters.length - 1];
    if (last && x - last.xEnd <= CLUSTER_GAP) {
      last.items.push(ctx);
      last.xEnd = x;
    } else {
      clusters.push({ items: [ctx], xStart: x, xEnd: x });
    }
  }

  // Dynamic lane collision tracker — creates new lanes as needed, no fixed max
  const laneOccupied = []; // array of arrays; grows dynamically
  function laneFits(lane, left, right) {
    if (!laneOccupied[lane]) return true;
    for (const s of laneOccupied[lane]) {
      if (right + LABEL_GAP > s.left && left - LABEL_GAP < s.right) return false;
    }
    return true;
  }
  function laneReserve(lane, left, right) {
    if (!laneOccupied[lane]) laneOccupied[lane] = [];
    laneOccupied[lane].push({ left, right });
  }
  function bestLane(left, right) {
    let i = 0;
    while (!laneFits(i, left, right)) i++;
    return i; // always finds or creates a lane
  }

  // Render dots (always, in both states)
  function renderPovodDots(items) {
    for (const ctx of items) {
      const xPx = ctxBarLeft(ctx.dateStart);
      const dot = document.createElement('div');
      dot.className = 'ctx-povod-dot';
      dot.style.left = xPx + 'px';
      dot.style.top = DOT_Y + 'px';
      dot.addEventListener('click', e => { e.stopPropagation(); showPovodPopover(dot, ctx); });
      tcP.appendChild(dot);
    }
  }

  // Render dots for all clusters (collapsed: dots only; expanded: dots + labels below)
  // Multi-day: always show bracket line
  for (const ctx of multiItems) {
    const xLeft = ctxBarLeft(ctx.dateStart);
    const lineW = Math.max(4, ctxBarWidth(ctx.dateStart, ctx.dateEnd));
    const line = document.createElement('div');
    line.className = 'ctx-povod-line';
    line.style.left = xLeft + 'px';
    line.style.width = lineW + 'px';
    line.style.top = DOT_Y + 'px';
    line.addEventListener('click', e => { e.stopPropagation(); showPovodPopover(line, ctx); });
    tcP.appendChild(line);
  }

  for (const cluster of clusters) {
    renderPovodDots(cluster.items);
    if (cluster.items.length > 1) {
      // "+N" cluster badge in collapsed state
      const lastX = ctxBarLeft(cluster.items[cluster.items.length - 1].dateStart);
      const badge = document.createElement('div');
      badge.className = 'ctx-povod-cluster';
      badge.textContent = '+' + cluster.items.length;
      badge.style.left = (lastX + 6) + 'px';
      badge.style.top = (DOT_Y - 5) + 'px';
      addTooltip(badge, cluster.items.map(c => `• ${povodDisplayLabel(c.name)}`).join('<br>'));
      tcP.appendChild(badge);
    }
  }

  // Collapsed height: just dots
  const povodCollapsedH = DOT_Y + 8;
  lcP.style.minHeight = povodCollapsedH + 'px';
  tcP.style.minHeight = povodCollapsedH + 'px';

  // Extra label lane rows (for expanded state)
  const extraLaneEls = []; // [{lc, tc}, ...]
  let usedLanes = 0;

  function buildExpandedLabels() {
    // Reset lane tracking — clear all lanes
    laneOccupied.length = 0;

    function placeLabelEl(lbl, lLeft, lRight) {
      const lane = bestLane(lLeft, lRight);
      laneReserve(lane, lLeft, lRight);
      const el = document.createElement('div');
      el.className = 'ctx-povod-label';
      el.textContent = lbl;
      el.title = lbl; // full name always accessible
      el.dataset.lane = lane;
      el.style.left = lLeft + 'px';
      el.style.maxWidth = MAX_LABEL_W + 'px';
      tcP.appendChild(el);
      usedLanes = Math.max(usedLanes, lane + 1);
    }

    // Place labels for single-day clusters
    for (const cluster of clusters) {
      const ctx = cluster.items[0];
      const xPx = ctxBarLeft(ctx.dateStart);
      const lbl = cluster.items.length === 1
        ? povodDisplayLabel(ctx.name)
        : povodDisplayLabel(ctx.name) + ' +' + (cluster.items.length - 1);
      const w = Math.min(measureText(lbl) + 6, MAX_LABEL_W);
      placeLabelEl(lbl, xPx + 4, xPx + 4 + w);
    }

    // Labels for multi-day items
    for (const ctx of multiItems) {
      const xLeft = ctxBarLeft(ctx.dateStart);
      const lbl = povodDisplayLabel(ctx.name);
      const w = Math.min(measureText(lbl) + 6, MAX_LABEL_W);
      placeLabelEl(lbl, xLeft, xLeft + w);
    }

    // Position all label elements according to their lane
    tcP.querySelectorAll('.ctx-povod-label[data-lane]').forEach(el => {
      el.style.top = (LANE_PAD + (+el.dataset.lane) * LANE_H) + 'px';
    });

    // Expand main row height to fit all dynamic lanes
    const expandedPovodH = LANE_PAD + usedLanes * LANE_H + 4;
    lcP.style.minHeight = Math.max(povodCollapsedH, expandedPovodH) + 'px';
    tcP.style.minHeight = Math.max(povodCollapsedH, expandedPovodH) + 'px';
  }

  function removeExpandedLabels() {
    tcP.querySelectorAll('.ctx-povod-label[data-lane]').forEach(el => el.remove());
    usedLanes = 0;
    lcP.style.minHeight = povodCollapsedH + 'px';
    tcP.style.minHeight = povodCollapsedH + 'px';
  }

  if (povodExpanded && allExpanded) {
    buildExpandedLabels();
  }

  // Toggle handler for Поводы
  lcP.addEventListener('click', (e) => {
    e.stopPropagation();
    const nowExpanded = sessionStorage.getItem('ctx_povod_expanded') === 'true';
    if (nowExpanded) {
      removeExpandedLabels();
      povodArrow.classList.add('collapsed');
      sessionStorage.setItem('ctx_povod_expanded', 'false');
    } else {
      buildExpandedLabels();
      povodArrow.classList.remove('collapsed');
      sessionStorage.setItem('ctx_povod_expanded', 'true');
    }
  });

  // ── SUB-ROW: СОБЫТИЯ ────────────────────────────────────────────
  const eventAllItems = allContext.filter(c => c.type.toLowerCase() === 'событие' && ctxItemVisible(c));
  const eventCount = eventAllItems.length;
  const eventExpanded = sessionStorage.getItem('ctx_event_expanded') === 'true';

  const eventLabelFrag = document.createElement('span');
  eventLabelFrag.style.display = 'flex'; eventLabelFrag.style.alignItems = 'center';
  eventLabelFrag.style.gap = '4px'; eventLabelFrag.style.width = '100%';
  const eventArrow = makeArrow('ctx-section-arrow');
  if (!eventExpanded) eventArrow.classList.add('collapsed');
  eventLabelFrag.appendChild(eventArrow);
  eventLabelFrag.appendChild(document.createTextNode('События'));
  const eventCountEl = document.createElement('span');
  eventCountEl.className = 'ctx-section-count';
  eventCountEl.textContent = `(${eventCount})`;
  eventLabelFrag.appendChild(eventCountEl);

  const { lc: lcE, tc: tcE } = makeSubRow(eventLabelFrag, true);
  addTodayLine(tcE);

  // Events: collapsed = dots only, expanded = dots + lane labels (same pattern as Поводы)
  const EVENT_DOT_Y   = 12;
  const EVENT_LANE_H  = 14;
  const EVENT_LANE_PAD = 2;
  const EVENT_MAX_W   = 90;
  const EVENT_GAP     = 3;
  const eventCollapsedH = EVENT_DOT_Y + 8;
  lcE.style.minHeight = eventCollapsedH + 'px'; tcE.style.minHeight = eventCollapsedH + 'px';

  // Render dots for all events (always visible in both states)
  for (const ctx of eventAllItems) {
    const xPx = ctxBarLeft(ctx.dateStart);
    const isSingle = Math.round((ctx.dateEnd - ctx.dateStart) / 86400000) <= 1;
    if (isSingle) {
      const dot = document.createElement('div');
      dot.className = 'ctx-event-dot';
      dot.style.left = xPx + 'px';
      dot.style.top = EVENT_DOT_Y + 'px';
      dot.addEventListener('click', e => { e.stopPropagation(); showPovodPopover(dot, ctx); });
      tcE.appendChild(dot);
    } else {
      // Multi-day: bracket line
      const lineW = Math.max(4, ctxBarWidth(ctx.dateStart, ctx.dateEnd));
      const line = document.createElement('div');
      line.className = 'ctx-event-line';
      line.style.left = xPx + 'px';
      line.style.width = lineW + 'px';
      line.style.top = EVENT_DOT_Y + 'px';
      line.addEventListener('click', e => { e.stopPropagation(); showPovodPopover(line, ctx); });
      tcE.appendChild(line);
    }
  }

  let eventUsedLanes = 0;
  const eventLaneOcc = [];

  function eventLaneFits(lane, left, right) {
    if (!eventLaneOcc[lane]) return true;
    for (const s of eventLaneOcc[lane]) {
      if (right + EVENT_GAP > s.left && left - EVENT_GAP < s.right) return false;
    }
    return true;
  }
  function eventLaneReserve(lane, left, right) {
    if (!eventLaneOcc[lane]) eventLaneOcc[lane] = [];
    eventLaneOcc[lane].push({ left, right });
  }
  function eventBestLane(left, right) {
    let i = 0;
    while (!eventLaneFits(i, left, right)) i++;
    return i;
  }

  function buildEventLabels() {
    eventLaneOcc.length = 0;
    eventUsedLanes = 0;
    for (const ctx of eventAllItems) {
      const xLeft = ctxBarLeft(ctx.dateStart);
      const lbl = ctx.name || '';
      const w = Math.min(_measCtx.measureText(lbl).width + 6, EVENT_MAX_W);
      const lane = eventBestLane(xLeft, xLeft + w);
      eventLaneReserve(lane, xLeft, xLeft + w);
      const el = document.createElement('div');
      el.className = 'ctx-event-label';
      el.textContent = lbl;
      el.title = lbl;
      el.dataset.elane = lane;
      el.style.left = xLeft + 'px';
      el.style.maxWidth = EVENT_MAX_W + 'px';
      el.style.top = (EVENT_LANE_PAD + lane * EVENT_LANE_H) + 'px';
      tcE.appendChild(el);
      eventUsedLanes = Math.max(eventUsedLanes, lane + 1);
    }
    const h = Math.max(eventCollapsedH, EVENT_LANE_PAD + eventUsedLanes * EVENT_LANE_H + 4);
    lcE.style.minHeight = h + 'px'; tcE.style.minHeight = h + 'px';
  }

  function removeEventLabels() {
    tcE.querySelectorAll('.ctx-event-label[data-elane]').forEach(el => el.remove());
    eventUsedLanes = 0;
    lcE.style.minHeight = eventCollapsedH + 'px'; tcE.style.minHeight = eventCollapsedH + 'px';
  }

  if (eventExpanded && allExpanded) buildEventLabels();

  lcE.addEventListener('click', (e) => {
    e.stopPropagation();
    const nowExpanded = sessionStorage.getItem('ctx_event_expanded') === 'true';
    if (nowExpanded) {
      removeEventLabels();
      eventArrow.classList.add('collapsed');
      sessionStorage.setItem('ctx_event_expanded', 'false');
    } else {
      buildEventLabels();
      eventArrow.classList.remove('collapsed');
      sessionStorage.setItem('ctx_event_expanded', 'true');
    }
  });

  // ── SUB-ROW: ЛОНЧИ ──────────────────────────────────────────────
  const launchAllItems = allContext.filter(c => c.type.toLowerCase() === 'лонч' && ctxItemVisible(c));
  const launchCount = launchAllItems.length;
  const launchExpanded = sessionStorage.getItem('ctx_launch_expanded') === 'true';

  const launchLabelFrag = document.createElement('span');
  launchLabelFrag.style.display = 'flex'; launchLabelFrag.style.alignItems = 'center';
  launchLabelFrag.style.gap = '4px'; launchLabelFrag.style.width = '100%';
  const launchArrow = makeArrow('ctx-section-arrow');
  if (!launchExpanded) launchArrow.classList.add('collapsed');
  launchLabelFrag.appendChild(launchArrow);
  launchLabelFrag.appendChild(document.createTextNode('Лончи'));
  const launchCountEl = document.createElement('span');
  launchCountEl.className = 'ctx-section-count';
  launchCountEl.textContent = `(${launchCount})`;
  launchLabelFrag.appendChild(launchCountEl);

  const { lc: lcL, tc: tcL } = makeSubRow(launchLabelFrag, true);
  addTodayLine(tcL);
  lcL.style.minHeight = '22px'; tcL.style.minHeight = '22px';

  function buildLaunchBars() {
    tcL.querySelectorAll('.ctx-launch-bar').forEach(el => el.remove());
    const launchAssigned = assignLanes(
      launchAllItems,
      c => ctxBarLeft(c.dateStart),
      c => ctxBarLeft(c.dateStart) + ctxBarWidth(c.dateStart, c.dateEnd)
    );
    let maxLane = 0;
    for (const { item: ctx, lane } of launchAssigned) {
      maxLane = Math.max(maxLane, lane);
      const bar = document.createElement('div');
      bar.className = 'ctx-launch-bar';
      bar.style.left = ctxBarLeft(ctx.dateStart) + 'px';
      bar.style.width = ctxBarWidth(ctx.dateStart, ctx.dateEnd) + 'px';
      bar.style.top = (3 + lane * 22) + 'px';
      bar.textContent = ctxShortLabel(ctx.name, ctx.type);
      addCtxPopup(bar, ctx);
      tcL.appendChild(bar);
    }
    const h = Math.max(22, (maxLane + 1) * 22 + 6);
    lcL.style.minHeight = h + 'px'; tcL.style.minHeight = h + 'px';
  }

  if (launchExpanded && allExpanded) buildLaunchBars();

  lcL.addEventListener('click', (e) => {
    e.stopPropagation();
    const nowExpanded = sessionStorage.getItem('ctx_launch_expanded') === 'true';
    if (nowExpanded) {
      tcL.querySelectorAll('.ctx-launch-bar').forEach(el => el.remove());
      lcL.style.minHeight = '22px'; tcL.style.minHeight = '22px';
      launchArrow.classList.add('collapsed');
      sessionStorage.setItem('ctx_launch_expanded', 'false');
    } else {
      buildLaunchBars();
      launchArrow.classList.remove('collapsed');
      sessionStorage.setItem('ctx_launch_expanded', 'true');
    }
  });

  // ── MASTER TOGGLE (Контекст header) ─────────────────────────────
  headerLabel.addEventListener('click', () => {
    const isNowExpanded = !allSubEls[0]?.classList.contains('ctx-hidden');
    allSubEls.forEach(el => el.classList.toggle('ctx-hidden', isNowExpanded));
    mainArrow.classList.toggle('collapsed', isNowExpanded);
    sessionStorage.setItem('ctx_block_expanded', String(!isNowExpanded));
  });
}

function flightColor(flight) {
  return colorMap[flight.collection] || '#6B7280';
}

function statusClass(status) {
  if (status === 'подтверждено') return 'status-confirmed';
  if (status === 'завершено') return 'status-done';
  if (status === 'отменено') return 'status-cancelled';
  return '';
}

function dotClass(status) {
  if (status === 'подтверждено') return 'dot-confirmed';
  if (status === 'завершено') return 'dot-done';
  if (status === 'отменено') return 'dot-cancelled';
  return 'dot-plan';
}

function toggleStatusLegend(e) {
  e.stopPropagation();
  const pop = document.getElementById('statusLegendPopover');
  pop.classList.toggle('open');
}
document.addEventListener('click', () => {
  const pop = document.getElementById('statusLegendPopover');
  if (pop) pop.classList.remove('open');
});

function renderFlightRow(container, flight) {
  const color = flightColor(flight);
  const acts = allActivities.filter(a => norm(a.flightName) === norm(flight.name));
  const hasActs = acts.length > 0;
  const isExpanded = expandedFlights.has(flight.name);

  // Label cell
  const lc = document.createElement('div');
  lc.className = 'flight-label-cell';
  lc.onclick = () => { toggleExpand(flight.name); };

  const pill = document.createElement('div');
  pill.className = 'flight-color-pill';
  pill.style.background = color;
  lc.appendChild(pill);

  const nameEl = document.createElement('div');
  nameEl.className = 'flight-name';
  nameEl.textContent = flight.name;
  nameEl.style.cursor = 'pointer';
  nameEl.onclick = (e) => { e.stopPropagation(); openFlightDrawer(flight); };
  // Show tooltip only when text is actually truncated
  nameEl.addEventListener('mouseenter', (e) => {
    if (nameEl.scrollWidth > nameEl.clientWidth) {
      tooltip.innerHTML = `<b>${flight.name}</b>`;
      tooltip.classList.add('visible');
      moveTooltip(e);
    }
  });
  nameEl.addEventListener('mousemove', (e) => {
    if (tooltip.classList.contains('visible')) moveTooltip(e);
  });
  nameEl.addEventListener('mouseleave', () => tooltip.classList.remove('visible'));
  lc.appendChild(nameEl);

  if (hasActs) {
    const icon = document.createElement('div');
    icon.className = 'expand-icon' + (isExpanded ? ' open' : '');
    icon.innerHTML = `<svg viewBox="0 0 16 16" fill="currentColor" width="12" height="12"><path d="M6 4l4 4-4 4"/></svg>`;
    lc.appendChild(icon);
  }

  container.appendChild(lc);

  // Timeline cell
  const tc = document.createElement('div');
  tc.className = 'flight-timeline-cell';
  tc.style.width = `${totalDays * DAY_PX}px`;
  tc.onclick = () => openFlightDrawer(flight);

  // Today line
  const todayOff = dayOffset(TODAY);
  if (todayOff >= 0 && todayOff <= totalDays) {
    const tl = document.createElement('div');
    tl.style.cssText = `position:absolute;top:0;bottom:0;left:${todayOff*DAY_PX}px;width:2px;background:#EF4444;opacity:.35;z-index:1;pointer-events:none;`;
    tc.appendChild(tl);
  }

  const bar = document.createElement('div');
  bar.className = 'flight-bar ' + statusClass(flight.status);
  bar.style.left = barLeft(flight.dateStart) + 'px';
  bar.style.width = barWidth(flight.dateStart, flight.dateEnd) + 'px';
  bar.style.background = color;
  bar.style.borderColor = shadeColor(color, -20);

  const dot = document.createElement('span');
  dot.className = 'flight-status-dot ' + dotClass(flight.status);
  addTooltip(dot, `Статус: ${STATUS_LABELS[flight.status]||flight.status}`);
  bar.appendChild(dot);

  const bl = document.createElement('div');
  bl.className = 'flight-bar-label';
  bl.textContent = flight.name;
  bar.appendChild(bl);

  const hint = `${flight.name}\n${fmtDate(flight.dateStart)} – ${fmtDate(flight.dateEnd)}\nСтатус: ${STATUS_LABELS[flight.status]||flight.status}${acts.length ? '\n'+acts.length+' активностей' : ''}`;
  addTooltip(bar, `<b>${flight.name}</b><br>${fmtShort(flight.dateStart)} – ${fmtShort(flight.dateEnd)}<br>Статус: ${STATUS_LABELS[flight.status]||flight.status}${acts.length ? '<br>'+acts.length+' активн.' : ''}`);
  tc.appendChild(bar);
  container.appendChild(tc);
}

function renderActivityRow(container, act, flight) {
  const color = flightColor(flight);
  const dc = dirColor(act.direction);

  const lc = document.createElement('div');
  lc.className = 'activity-label-cell';

  const badge = document.createElement('div');
  badge.className = 'activity-dir-badge';
  badge.style.background = dc.bg;
  badge.style.color = dc.text;
  badge.textContent = act.direction || '—';
  lc.appendChild(badge);

  const name = document.createElement('div');
  name.className = 'activity-name';
  name.textContent = act.block || act.format || act.direction || '—';
  lc.appendChild(name);

  container.appendChild(lc);

  const tc = document.createElement('div');
  tc.className = 'activity-timeline-cell';
  tc.style.width = `${totalDays * DAY_PX}px`;

  const barW = barWidth(act.dateStart, act.dateEnd);
  const bar = document.createElement('div');
  bar.className = 'activity-bar';
  bar.style.left = barLeft(act.dateStart) + 'px';
  bar.style.width = barW + 'px';
  bar.style.background = hexToRgba(color, .18);
  bar.style.borderColor = color;
  bar.style.color = color;
  bar.style.position = 'absolute';
  // Inline label if bar is wide enough
  const labelText = act.block || act.format || '';
  if (labelText && barW >= 50) {
    const lbl = document.createElement('div');
    lbl.className = 'activity-bar-label';
    lbl.textContent = labelText;
    bar.appendChild(lbl);
  }
  addTooltip(bar, `<b>${act.direction}</b>${act.block ? ': '+act.block : ''}<br>${fmtShort(act.dateStart)} – ${fmtShort(act.dateEnd)}${act.platforms ? '<br>'+act.platforms : ''}${act.format ? '<br>'+act.format : ''}`);
  tc.appendChild(bar);

  container.appendChild(tc);
}

function toggleExpand(name) {
  if (expandedFlights.has(name)) {
    expandedFlights.delete(name);
  } else {
    expandedFlights.add(name);
  }
  renderGantt();
}

// ── DRAWER ─────────────────────────────────────────────────────────
function openFlightDrawer(flight) {
  const color = flightColor(flight);
  document.getElementById('drawerStrip').style.background = color;
  document.getElementById('drawerTitle').textContent = flight.name;
  document.getElementById('drawerSubtitle').textContent = fmtDate(flight.dateStart) + ' – ' + fmtDate(flight.dateEnd);

  const body = document.getElementById('drawerBody');
  body.innerHTML = '';

  // Status + collection
  const sec1 = mkSection('Основное');
  sec1.appendChild(mkRow('Статус', statusBadgeHtml(flight.status) + (flight.extra.status && norm(flight.extra.status) !== flight.status ? ' <span style="color:var(--text-muted)">' + flight.extra.status + '</span>' : '')));
  sec1.appendChild(mkRow('Коллекция', flight.collection || '—'));
  sec1.appendChild(mkRow('BM', flight.bm || '—'));
  if (flight.taFinal) sec1.appendChild(mkRow('ЦА', flight.taFinal));
  if (flight.claimFinal) sec1.appendChild(mkRow('Клейм', flight.claimFinal));
  if (flight.extra.id) {
    const link = document.createElement('a');
    link.href = '/flights/' + flight.extra.id;
    link.className = 'btn';
    link.style.cssText = 'display:inline-flex;margin-top:8px';
    link.textContent = flight.extra.can_edit ? 'Редактировать в Planner →' : 'Открыть карточку →';
    sec1.appendChild(link);
  }
  body.appendChild(sec1);

  // SKU
  const skuItems = flight.extra.skus || [];
  if (skuItems.length) {
    const secS = mkSection(`SKU (${skuItems.length})`);
    const skuList = document.createElement('div');
    skuList.className = 'sku-cards';
    skuItems.forEach(s => {
      const row = document.createElement('div');
      row.className = 'sku-card';
      const ph = document.createElement('div');
      ph.className = 'sku-noimg';
      ph.textContent = '▢';
      if (s.article) {
        // картинка — главная обложка SKU в indexM (через сервер Planner, с кэшем)
        const img = document.createElement('img');
        img.loading = 'lazy';
        img.alt = '';
        img.src = '/sku-image/' + encodeURIComponent(s.article) + '?size=preview';
        img.onerror = () => img.replaceWith(ph);
        row.appendChild(img);
      } else {
        row.appendChild(ph);
      }
      const t = document.createElement('div');
      t.textContent = s.name;
      if (s.article) {
        const art = document.createElement('div');
        art.className = 'sku-art';
        art.textContent = 'арт. ' + s.article;
        t.appendChild(art);
      }
      row.appendChild(t);
      skuList.appendChild(row);
    });
    secS.appendChild(skuList);
    body.appendChild(secS);
  }

  // Activities
  const acts = allActivities.filter(a => norm(a.flightName) === norm(flight.name));
  if (acts.length) {
    const secA = mkSection(`Активности (${acts.length})`);
    const list = document.createElement('div');
    list.className = 'activities-list';
    acts.forEach(a => {
      const dc = dirColor(a.direction);
      const card = document.createElement('div');
      card.className = 'activity-card';

      // Show only overridden values; suppress inherited (matching flight-level)
      function overrideOnly(actVal, flightVal, label, icon) {
        if (!actVal) return '';
        if (flightVal && norm(actVal) === norm(flightVal)) return ''; // inherited — skip
        return `<div class="activity-card-row"><span class="override-value">${icon} ${label}: ${actVal}</span></div>`;
      }

      // SKU collapse: show tags, collapse if > SKU_LIMIT
      function skuRowHtml(skuStr, flightSkuStr) {
        if (!skuStr) return '';
        if (flightSkuStr && norm(skuStr) === norm(flightSkuStr)) return ''; // inherited — skip
        const skus = skuStr.split(',').map(s => s.trim()).filter(Boolean);
        const SKU_LIMIT = 3;
        if (skus.length <= SKU_LIMIT) {
          return `<div class="activity-card-row">📦 ${skus.map(s=>`<span class="tag">${s}</span>`).join(' ')}</div>`;
        }
        const visible = skus.slice(0, SKU_LIMIT);
        const hidden = skus.slice(SKU_LIMIT);
        const uid = 'sku_' + Math.random().toString(36).slice(2,8);
        return `<div class="activity-card-row" id="${uid}_wrap">📦 ${visible.map(s=>`<span class="tag">${s}</span>`).join(' ')} <span id="${uid}_hidden" style="display:none">${hidden.map(s=>`<span class="tag">${s}</span>`).join(' ')}</span> <button class="sku-expand-btn" id="${uid}_btn" onclick="(function(){var h=document.getElementById('${uid}_hidden'),b=document.getElementById('${uid}_btn');if(h.style.display==='none'){h.style.display='';b.textContent='скрыть';}else{h.style.display='none';b.textContent='+${hidden.length} SKU';}})()">+${hidden.length} SKU</button></div>`;
      }

      const flightSkuStr = [flight.sku1,flight.sku2,flight.sku3].filter(Boolean).join(', ');
      card.innerHTML = `
        <div class="activity-card-header">
          <div style="display:flex;align-items:center;gap:6px">
            <div class="activity-dir-badge" style="background:${dc.bg};color:${dc.text}">${a.direction||'—'}</div>
            <div class="activity-card-name">${a.block||a.format||'—'}</div>
          </div>
          <div class="activity-card-dates">${fmtShort(a.dateStart)} – ${fmtShort(a.dateEnd)}</div>
        </div>
        ${a.platforms?`<div class="activity-card-row">📱 ${a.platforms}</div>`:''}
        ${a.format?`<div class="activity-card-row">📄 ${a.format}</div>`:''}
        ${overrideOnly(a.taFinal, flight.taFinal, 'ЦА', '👤')}
        ${overrideOnly(a.claimFinal, flight.claimFinal, 'Клейм', '💬')}
        ${skuRowHtml(a.skuFinal, flightSkuStr)}
        ${a.comment?`<div class="activity-card-row" style="color:var(--text-muted);font-style:italic">💭 ${a.comment}</div>`:''}
      `;
      list.appendChild(card);
    });
    secA.appendChild(list);
    body.appendChild(secA);
  }

  // Brief / Materials
  if (flight.brief) {
    const secB = mkSection('Описание');
    const p = document.createElement('div');
    p.style.cssText='font-size:12px;color:var(--text-secondary);line-height:1.5';
    p.textContent = flight.brief;
    secB.appendChild(p);
    body.appendChild(secB);
  }
  if (flight.materialsUrl || flight.specDocUrl) {
    const secM = mkSection('Документы');
    if (flight.materialsUrl) {
      const a = document.createElement('a');
      a.href = flight.materialsUrl;
      a.target = '_blank';
      a.className = 'btn';
      a.textContent = 'Материалы / результаты →';
      a.style.cssText = 'display:inline-flex;margin-bottom:6px';
      secM.appendChild(a);
    }
    if (flight.specDocUrl) {
      const a2 = document.createElement('a');
      a2.href = flight.specDocUrl;
      a2.target = '_blank';
      a2.className = 'btn';
      a2.textContent = 'Спец. документ →';
      a2.style.cssText = 'display:inline-flex';
      secM.appendChild(a2);
    }
    body.appendChild(secM);
  }
  if (flight.comment) {
    const secC = mkSection('Комментарий');
    const p = document.createElement('div');
    p.style.cssText='font-size:12px;color:var(--text-muted);line-height:1.5';
    p.textContent = flight.comment;
    secC.appendChild(p);
    body.appendChild(secC);
  }

  document.getElementById('drawerOverlay').classList.add('open');
  document.getElementById('drawer').classList.add('open');
}

function closeDrawer() {
  document.getElementById('drawerOverlay').classList.remove('open');
  document.getElementById('drawer').classList.remove('open');
}

function mkSection(title) {
  const s = document.createElement('div');
  s.className = 'drawer-section';
  const t = document.createElement('div');
  t.className = 'drawer-section-title';
  t.textContent = title;
  s.appendChild(t);
  return s;
}
function mkRow(label, valueHtml) {
  const r = document.createElement('div');
  r.className = 'detail-row';
  r.innerHTML = `<span class="detail-label">${label}</span><span class="detail-value">${valueHtml}</span>`;
  return r;
}
function statusBadgeHtml(s) {
  const map = { 'план':'status-plan', 'подтверждено':'status-confirmed', 'завершено':'status-done', 'отменено':'status-cancelled' };
  const cls = map[s] || 'status-plan';
  return `<span class="status-badge ${cls}">${STATUS_LABELS[s]||s}</span>`;
}

// ── TOOLTIP ────────────────────────────────────────────────────────
const tooltip = document.getElementById('tooltip');
function addTooltip(el, html) {
  el.addEventListener('mouseenter', (e) => {
    tooltip.innerHTML = html;
    tooltip.classList.add('visible');
    moveTooltip(e);
  });
  el.addEventListener('mousemove', moveTooltip);
  el.addEventListener('mouseleave', () => tooltip.classList.remove('visible'));
}

function moveTooltip(e) {
  let x = e.clientX + 14;
  let y = e.clientY - 10;
  const tw = tooltip.offsetWidth;
  const th = tooltip.offsetHeight;
  if (x + tw > window.innerWidth - 8) x = e.clientX - tw - 14;
  if (y + th > window.innerHeight - 8) y = e.clientY - th - 10;
  tooltip.style.left = x + 'px';
  tooltip.style.top = y + 'px';
}

// ── CONTEXT RICH POPUP ─────────────────────────────────────────────
const ctxPopup = document.getElementById('ctxPopup');
function addCtxPopup(el, ctx) {
  el.addEventListener('mouseenter', (e) => {
    const meta = ctxTypeMeta(ctx.type);
    let html = `<div class="ctx-popup-name">${ctx.name}</div>`;
    html += `<div class="ctx-popup-dates">${fmtDate(ctx.dateStart)} – ${fmtDate(ctx.dateEnd)}</div>`;
    html += `<div class="ctx-popup-collection"><span class="ctx-popup-dot" style="background:${meta.bg};border:1px solid ${meta.border}"></span><span style="color:${meta.text};font-weight:600">${meta.label}</span></div>`;
    if (ctx.collection) {
      const collectionColor = colorMap[ctx.collection] || meta.bg;
      html += `<div class="ctx-popup-collection"><span class="ctx-popup-dot" style="background:${collectionColor}"></span>${ctx.collection}</div>`;
    }
    if (ctx.comment) {
      html += `<div class="ctx-popup-comment">${ctx.comment}</div>`;
    }
    ctxPopup.innerHTML = html;
    ctxPopup.classList.add('visible');
    moveCtxPopup(e);
  });
  el.addEventListener('mousemove', moveCtxPopup);
  el.addEventListener('mouseleave', () => {
    if (!ctxPopup._pinned) ctxPopup.classList.remove('visible');
  });
  el.addEventListener('click', (e) => {
    e.stopPropagation();
    ctxPopup.classList.remove('visible');
    ctxPopup._pinned = false;
    openCtxDrawer(ctx);
  });
}

function openCtxDrawer(ctx) {
  const meta = ctxTypeMeta(ctx.type);
  const drawer = document.getElementById('ctxDetailDrawer');
  const header = drawer.querySelector('.ctx-drawer-header');
  const body = drawer.querySelector('.ctx-drawer-body');

  // Build header
  header.innerHTML = '';
  const headerLeft = document.createElement('div');
  const badge = document.createElement('div');
  badge.className = 'ctx-drawer-type-badge';
  badge.style.background = meta.bg;
  badge.style.color = meta.text;
  badge.style.border = `1px solid ${meta.border}`;
  badge.textContent = meta.label;
  headerLeft.appendChild(badge);
  const nameEl = document.createElement('div');
  nameEl.className = 'ctx-drawer-name';
  nameEl.textContent = ctx.name;
  headerLeft.appendChild(nameEl);
  header.appendChild(headerLeft);

  const closeBtn = document.createElement('button');
  closeBtn.className = 'ctx-drawer-close';
  closeBtn.innerHTML = '&times;';
  closeBtn.addEventListener('click', closeCtxDrawer);
  header.appendChild(closeBtn);

  // Build body
  body.innerHTML = '';
  function addRow(label, val) {
    if (!val) return;
    const row = document.createElement('div');
    row.className = 'ctx-drawer-row';
    row.innerHTML = `<div class="ctx-drawer-row-label">${label}</div><div class="ctx-drawer-row-val">${val}</div>`;
    body.appendChild(row);
  }
  addRow('Период', `${fmtDate(ctx.dateStart)} – ${fmtDate(ctx.dateEnd)}`);
  if (ctx.collection) addRow('Коллекция', ctx.collection);
  if (ctx.comment) addRow('Комментарий', ctx.comment);

  drawer.classList.add('open');
}

function closeCtxDrawer() {
  document.getElementById('ctxDetailDrawer').classList.remove('open');
}

function moveCtxPopup(e) {
  let x = e.clientX + 14;
  let y = e.clientY - 10;
  const pw = ctxPopup.offsetWidth || 200;
  const ph = ctxPopup.offsetHeight || 100;
  if (x + pw > window.innerWidth - 8) x = e.clientX - pw - 14;
  if (y + ph > window.innerHeight - 8) y = e.clientY - ph - 10;
  ctxPopup.style.left = x + 'px';
  ctxPopup.style.top = y + 'px';
}
// Close ctx popup on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('#ctxDetailDrawer')) {
    ctxPopup.classList.remove('visible');
    ctxPopup._pinned = false;
  }
});

// ── COLORS ─────────────────────────────────────────────────────────
function shadeColor(hex, pct) {
  hex = hex.replace('#','');
  if (hex.length === 3) hex = hex.split('').map(c=>c+c).join('');
  let r = parseInt(hex.substr(0,2),16);
  let g = parseInt(hex.substr(2,2),16);
  let b = parseInt(hex.substr(4,2),16);
  r = Math.min(255,Math.max(0,r+pct));
  g = Math.min(255,Math.max(0,g+pct));
  b = Math.min(255,Math.max(0,b+pct));
  return '#'+[r,g,b].map(c=>c.toString(16).padStart(2,'0')).join('');
}
function hexToRgba(hex, alpha) {
  hex = hex.replace('#','');
  if (hex.length === 3) hex = hex.split('').map(c=>c+c).join('');
  const r = parseInt(hex.substr(0,2),16);
  const g = parseInt(hex.substr(2,2),16);
  const b = parseInt(hex.substr(4,2),16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ── STATUS INDICATOR ───────────────────────────────────────────────
function setStatus(live, text) {
  const dot = document.getElementById('statusDot');
  const txt = document.getElementById('statusText');
  dot.className = 'status-dot' + (live ? ' live' : '');
  txt.textContent = text;
}

// ── ДАННЫЕ PLANNER ─────────────────────────────────────────────────
// Формат — как у прежнего Apps Script (строки листов таблицы), см. TimelineController.
async function fetchAllData(fresh) {
  let json = window.PLANNER_DATA;
  if (fresh) {
    const resp = await fetch('/timeline/data', { credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    json = await resp.json();
  }

  const col = parseCollections(json.collections || []);
  allCollections = col.collections;
  colorMap = col.colorMap;
  allFlights = parseFlights(json.flights || []);
  allActivities = parseActivities(json.activities || []);
  allContext = parseContextRows(json.context || []);
}

async function initData() {
  setStatus(false, 'Загрузка...');

  try {
    await fetchAllData();

    document.getElementById('loadingOverlay').style.display = 'none';
    document.getElementById('ganttContainer').style.display = 'grid';
    setStatus(true, 'Данные загружены');
    populateFilters();
    applyFilters();

    // Периодическое обновление каждые 5 минут
    setInterval(async () => {
      try {
        await fetchAllData(true);
        setStatus(true, 'Данные обновлены');
        populateFilters();
        applyFilters();
      } catch(e) {
        console.warn('Refresh error', e);
      }
    }, 300000);

  } catch(err) {
    setStatus(false, 'Ошибка загрузки');
    document.getElementById('loadingOverlay').innerHTML = `
      <div style="text-align:center;color:var(--text-muted)">
        <div style="font-size:24px;margin-bottom:8px">⚠️</div>
        <div style="font-size:13px;font-weight:600;margin-bottom:4px">Ошибка загрузки данных</div>
        <div style="font-size:12px">${err.message || 'Обновите страницу'}</div>
      </div>`;
  }
}

// ══════════════════════════════════════════════════════════════════
// EXPORT MODAL
// ══════════════════════════════════════════════════════════════════

let exportPeriodType = 'year';
let exportPresentationType = 'overview'; // 'overview' | 'full'

// ── Collect all years present in data ─────────────────────────────
function getDataYears() {
  const ySet = new Set();
  for (const f of allFlights) {
    if (f.dateStart) ySet.add(f.dateStart.getFullYear());
    if (f.dateEnd)   ySet.add(f.dateEnd.getFullYear());
  }
  return [...ySet].sort();
}


// ── Open / close ───────────────────────────────────────────────────
function openExportModal() {
  // Populate year dropdown from data
  const years = getDataYears();
  const expYear = document.getElementById('expYear');
  expYear.innerHTML = '';
  years.forEach(y => {
    const o = document.createElement('option');
    o.value = y; o.textContent = y;
    expYear.appendChild(o);
  });

  // Default: match current dashboard year if set
  const dashYear = document.getElementById('filterYear').value;
  if (dashYear && years.includes(+dashYear)) {
    expYear.value = dashYear;
  } else if (years.length) {
    expYear.value = years[years.length - 1]; // latest year
  }

  // Default period = year, type = overview, checks = on
  exportPeriodType = 'year';
  exportPresentationType = 'overview';
  document.getElementById('epYear').classList.add('active');
  ['etOverview','etFull'].forEach(id => document.getElementById(id).classList.remove('active'));
  document.getElementById('etOverview').classList.add('active');
  document.getElementById('expContext').checked = true;
  document.getElementById('expFilters').checked = true;

  updateExportPreview();
  document.getElementById('exportBackdrop').classList.add('open');
}
function closeExportModal(e) {
  if (e && e.target !== document.getElementById('exportBackdrop')) return;
  document.getElementById('exportBackdrop').classList.remove('open');
}

// ── Period switcher ────────────────────────────────────────────────
function setExportPeriod(type) {
  exportPeriodType = type;
  document.getElementById('epYear').classList.toggle('active', type === 'year');
  updateExportPreview();
}
function setExportType(type) {
  exportPresentationType = type;
  ['etOverview','etFull'].forEach(id => document.getElementById(id).classList.remove('active'));
  document.getElementById('et' + type.charAt(0).toUpperCase() + type.slice(1)).classList.add('active');
  updateExportPreview();
}


// ── Preview line ───────────────────────────────────────────────────
function calcExportRange() {
  const year = +document.getElementById('expYear').value;
  if (!year) return null;
  return { start: new Date(year,0,1), end: new Date(year,11,31) };
}

function intersects(dateStart, dateEnd, rangeStart, rangeEnd) {
  return dateStart <= rangeEnd && dateEnd >= rangeStart;
}

function updateExportPreview() {
  const range = calcExportRange();
  const preview = document.getElementById('exportPreview');
  if (!range) { preview.innerHTML = 'Нет данных для выбранного периода'; return; }

  const useFilters   = document.getElementById('expFilters').checked;
  const useContext   = document.getElementById('expContext').checked;

  // Base flight set
  let baseFlights = useFilters ? visibleFlights : allFlights;
  const flights = baseFlights.filter(f =>
    f.dateStart && f.dateEnd && intersects(f.dateStart, f.dateEnd, range.start, range.end)
  );

  // Activities
  const activities = allActivities.filter(a => {
    if (!a.dateStart || !a.dateEnd) return false;
    if (useFilters) {
      const matchFlight = flights.some(f => norm(f.name) === norm(a.flightName));
      if (!matchFlight) return false;
    }
    return intersects(a.dateStart, a.dateEnd, range.start, range.end);
  });

  // Context items
  const contextCount = useContext
    ? allContext.filter(c => c.dateStart && c.dateEnd && intersects(c.dateStart, c.dateEnd, range.start, range.end)).length
    : 0;

  // Period label
  const year = +document.getElementById('expYear').value;
  let periodLabel = String(year);
  let titleLabel  = `Медиаплан ${year}`;
  let fileLabel   = `LIBREDERM_Медиаплан_${year}`;

  // Collection filter active?
  const colFilter = document.getElementById('filterCollection').value;
  if (useFilters && colFilter) {
    const colName = [...document.getElementById('filterCollection').options]
      .find(o => o.value === colFilter)?.textContent || colFilter.toUpperCase();
    fileLabel = `LIBREDERM_${colName.toUpperCase()}_${year}`;
  }

  const typeLabel = exportPresentationType === 'full' ? 'Полная' : 'Обзорная';
  const contextPart = useContext ? ` · ${contextCount} поводов` : '';
  const filterNote = useFilters ? ' · с фильтрами' : '';

  if (!flights.length) {
    preview.innerHTML = `<span class="preview-warn">⚠ Нет флайтов за выбранный период</span>`;
    return;
  }

  preview.innerHTML = `
    <strong>Будет экспортировано:</strong> ${flights.length} флайтов · ${activities.length} активностей${contextPart}<br>
    ${periodLabel} · ${typeLabel} презентация${filterNote}<br>
    <span style="color:var(--text-muted);font-size:10px">${fileLabel}.pptx</span>
  `;

  // Store computed data for actual export
  preview._exportData = { flights, activities, contextCount, titleLabel, fileLabel, range };
}

// ── Actual export ──────────────────────────────────────────────────
function doExportPptx() {
  const preview = document.getElementById('exportPreview');
  const data = preview._exportData;
  if (!data || !data.flights.length) {
    preview.innerHTML = '<span style="color:#e74c3c;font-weight:600">Нет данных для экспорта за выбранный период.</span>';
    return;
  }
  _generatePptx(data);
}

// Картинки SKU для слайдов кампаний: article → dataURL (через /sku-image, с кэшем Planner)
let SKU_IMG = {};
async function _loadSkuImages(flights) {
  const arts = [...new Set(flights.flatMap(f => (f.extra && f.extra.skus || []).slice(0, 3).map(s => s.article)).filter(Boolean))];
  const out = {};
  await Promise.all(arts.map(async (a) => {
    try {
      const r = await fetch('/sku-image/' + encodeURIComponent(a) + '?size=preview', { credentials: 'same-origin' });
      if (!r.ok) return;
      const blob = await r.blob();
      out[a] = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(blob); });
    } catch (e) { /* без картинки */ }
  }));
  return out;
}

async function _generatePptx(data) {
  const btn = document.getElementById('exportDoBtn');
  if (btn) btn.disabled = true;
  try {
    SKU_IMG = document.getElementById('expImages') && !document.getElementById('expImages').checked ? {} : await _loadSkuImages(data.flights);
  } finally {
    if (btn) btn.disabled = false;
  }
  _buildPptx(data);
}

function _buildPptx(data) {
  const { flights, activities, titleLabel, fileLabel, range } = data;
  const useContext  = document.getElementById('expContext').checked;

  const MONTHS_RU_SHORT = ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];
  const MONTHS_RU_FULL  = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  const MONTHS_GEN_RU   = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];

  // ── Helpers ───────────────────────────────────────────────────────
  function fmtDate(d) {
    if (!d) return '';
    return d.getDate() + ' ' + MONTHS_GEN_RU[d.getMonth()] + ' ' + d.getFullYear();
  }
  function fmtDateShort(d) {
    if (!d) return '';
    return MONTHS_RU_SHORT[d.getMonth()] + ' ' + d.getFullYear();
  }
  function fmtRange(ds, de) {
    if (!ds || !de) return '';
    if (ds.getMonth() === de.getMonth() && ds.getFullYear() === de.getFullYear())
      return ds.getDate() + '–' + de.getDate() + ' ' + MONTHS_GEN_RU[ds.getMonth()];
    return fmtDateShort(ds) + ' – ' + fmtDateShort(de);
  }
  // Get collection color hex (no #)
  function collColor(collSlug) {
    const hex = (colorMap[norm(collSlug)] || colorMap[collSlug] || '#6B7280').replace('#','');
    return hex || '6B7280';
  }
  // Get collection display name from slug
  function collName(slug) {
    const c = allCollections.find(c => c.slug === slug || c.slug === norm(slug));
    return c ? c.name : slug;
  }
  // Lighten a hex color (blend toward white)
  function lighten(hex, pct) {
    let r = parseInt(hex.slice(0,2),16), g = parseInt(hex.slice(2,4),16), b = parseInt(hex.slice(4,6),16);
    r = Math.round(r + (255-r)*pct); g = Math.round(g + (255-g)*pct); b = Math.round(b + (255-b)*pct);
    return [r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
  }
  // Detail slide only if flight has real advertising activities with content.
  // Rule: >=2 activities OR (1 activity + 2+ rich fields on that activity).
  function isSubstantive(f) {
    const fActs = activities.filter(a => norm(a.flightName) === norm(f.name));
    if (fActs.length >= 2) return true;
    if (fActs.length === 1) {
      const a = fActs[0];
      let richScore = 0;
      if (a.platforms)  richScore++;
      if (a.format)     richScore++;
      if (a.specDocUrl) richScore++;
      if (a.materialsUrl) richScore++;
      if (a.skuFinal)   richScore++;
      if (a.taFinal)    richScore++;
      if (a.claimFinal) richScore++;
      return richScore >= 2;
    }
    return false; // 0 activities → no detail slide
  }

  const pres = new PptxGenJS();
  pres.layout   = 'LAYOUT_WIDE'; // 13.33" × 7.5"
  pres.author   = 'LIBREDERM';
  pres.subject  = titleLabel;
  pres.title    = titleLabel;

  // ── Color palette ──────────────────────────────────────────────
  const CLR = {
    bg:      'F7F8FA',
    white:   'FFFFFF',
    text:    '1A1D23',
    muted:   '8B93A3',
    border:  'E2E6EC',
    cover:   '1A2B4A',   // dark navy for cover
    gray:    '6B7280',
    green:   '22C55E',
    red:     'E53E3E',
    dimmed:  'A0AEC0',
    amber:   'F59E0B',
    lblue:   'EBF0FD',
  };
  const FONT = 'Calibri';

  // ── Status dot color ─────────────────────────────────────────
  function statusDotColor(st) {
    switch((st||'').toLowerCase()) {
      case 'подтверждено': return CLR.green;
      case 'завершено':    return CLR.dimmed;
      case 'отменено':     return CLR.red;
      default:             return CLR.gray; // план
    }
  }

  // ── Slide header helper ──────────────────────────────────────
  function addSlideHeader(s, title, subtitle) {
    s.background = { color: CLR.white };
    s.addText('LIBREDERM', {
      x:0.45, y:0.22, w:3, h:0.22,
      fontSize:7, bold:true, color:CLR.muted, fontFace:FONT, charSpacing:2,
      isTextBox:true,
    });
    s.addText(title, {
      x:0.45, y:0.42, w:9.5, h:0.55,
      fontSize:22, bold:true, color:CLR.text, fontFace:FONT,
      isTextBox:true,
    });
    if (subtitle) {
      s.addText(subtitle, {
        x:0.45, y:0.95, w:9.5, h:0.28,
        fontSize:10, color:CLR.muted, fontFace:FONT,
        isTextBox:true,
      });
    }
    s.addShape(pres.ShapeType.line, {
      x:0.45, y:1.28, w:12.43, h:0,
      line:{color:CLR.border,width:0.75},
    });
  }

  // ── Timeline builder ─────────────────────────────────────────
  function buildTimelineSlide(s, flightsToShow, rStart, rEnd, headerTitle, showContext) {
    const SLIDE_W = 13.33;
    const LABEL_W = 2.6;
    const TL_LEFT = LABEL_W + 0.4;
    const TL_W    = SLIDE_W - TL_LEFT - 0.4;
    const ROW_H   = 0.26;
    const HDR_H   = 0.32;
    const TOP_Y   = 1.48;
    const BAR_H   = 0.16;
    const totalDays = Math.round((rEnd - rStart) / 86400000) + 1;
    const pxPerDay  = TL_W / totalDays;

    function dOff(d) { return Math.round((d - rStart) / 86400000); }
    function toIn(days) { return days * pxPerDay; }

    // Month header row
    const calYear = rStart.getFullYear();
    for (let m = 0; m < 12; m++) {
      const mStart = new Date(calYear, m, 1);
      const mEnd   = new Date(calYear, m+1, 0);
      if (mEnd < rStart || mStart > rEnd) continue;
      const cs = mStart < rStart ? rStart : mStart;
      const ce = mEnd   > rEnd   ? rEnd   : mEnd;
      const mL = TL_LEFT + toIn(dOff(cs));
      const mW = toIn(Math.round((ce - cs) / 86400000) + 1);
      const isEven = m % 2 === 0;
      s.addShape(pres.ShapeType.rect, {
        x:mL, y:TOP_Y, w:mW, h:HDR_H,
        fill:{color: isEven ? 'F5F7FA' : 'FAFBFC'},
        line:{color:CLR.border,width:0.4},
      });
      s.addText(MONTHS_RU_SHORT[m], {
        x:mL, y:TOP_Y, w:mW, h:HDR_H,
        fontSize:7, color:CLR.muted, align:'center', valign:'middle', fontFace:FONT,
        isTextBox:true,
      });
    }

    // Context strip (thin band above bars)
    if (showContext) {
      const ctxItems = allContext.filter(c =>
        c.dateStart && c.dateEnd && intersects(c.dateStart, c.dateEnd, rStart, rEnd)
      );
      const CTX_Y = TOP_Y + HDR_H;
      ctxItems.slice(0,60).forEach(c => {
        const cs = c.dateStart < rStart ? rStart : c.dateStart;
        const ce = c.dateEnd   > rEnd   ? rEnd   : c.dateEnd;
        const cL = TL_LEFT + toIn(dOff(cs));
        const cW = Math.max(toIn(Math.round((ce-cs)/86400000)+1), 0.03);
        const ctxClr = c.type.toLowerCase() === 'сезонность' ? 'DBEAFE'
                     : c.type.toLowerCase() === 'событие'    ? 'EDE9FE'
                     : c.type.toLowerCase() === 'лонч'       ? 'D1FAE5'
                     : 'FEF3C7';
        s.addShape(pres.ShapeType.rect, {
          x:cL, y:CTX_Y, w:cW, h:0.07,
          fill:{color:ctxClr}, line:{color:CLR.border,width:0.2},
        });
      });
    }

    const BAR_TOP = TOP_Y + HDR_H + (showContext ? 0.1 : 0.05);
    const maxRows = Math.floor((7.2 - BAR_TOP) / ROW_H);

    flightsToShow.slice(0, maxRows).forEach((f, i) => {
      const y = BAR_TOP + i * ROW_H;
      const collHex = collColor(f.collection);
      const dotClr  = statusDotColor(f.status);

      // Status dot
      s.addShape(pres.ShapeType.ellipse, {
        x:0.3, y:y+(ROW_H-0.1)/2, w:0.1, h:0.1,
        fill:{color:dotClr}, line:{color:dotClr,width:0},
      });
      // Label
      const lbl = (collName(f.collection) || f.name).slice(0, 32);
      s.addText(lbl, {
        x:0.45, y, w:LABEL_W-0.2, h:ROW_H,
        fontSize:7.5, color:CLR.text, valign:'middle', fontFace:FONT,
        isTextBox:true,
      });

      // Bar
      const ds = f.dateStart < rStart ? rStart : f.dateStart;
      const de = f.dateEnd   > rEnd   ? rEnd   : f.dateEnd;
      if (ds > de) return;
      const bL = TL_LEFT + toIn(dOff(ds));
      const bW = Math.max(toIn(Math.round((de-ds)/86400000)+1), 0.08);
      s.addShape(pres.ShapeType.roundRect, {
        x:bL, y:y+(ROW_H-BAR_H)/2, w:bW, h:BAR_H,
        fill:{color:collHex}, line:{color:collHex,width:0},
        rectRadius:0.02,
      });
      // Bar label if wide enough
      if (bW > 0.6) {
        const flightLbl = f.name.slice(0, Math.floor(bW*10));
        s.addText(flightLbl, {
          x:bL+0.04, y:y+(ROW_H-BAR_H)/2, w:bW-0.08, h:BAR_H,
          fontSize:6, color:CLR.white, valign:'middle', fontFace:FONT,
          isTextBox:true,
        });
      }
    });

    if (flightsToShow.length > maxRows) {
      s.addText(`+ ещё ${flightsToShow.length - maxRows} кампаний`, {
        x:0.45, y:BAR_TOP + maxRows * ROW_H + 0.05, w:12, h:0.22,
        fontSize:8, color:CLR.muted, fontFace:FONT, isTextBox:true,
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 1 — COVER
  // ═══════════════════════════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: CLR.cover };

    // LIBREDERM label top-left
    s.addText('LIBREDERM', {
      x:0.55, y:0.45, w:6, h:0.35,
      fontSize:11, bold:true, color:'CADCFC', fontFace:FONT, charSpacing:4,
      isTextBox:true,
    });

    // Main title
    s.addText('КОММУНИКАЦИЯ\nИ РЕКЛАМА', {
      x:0.55, y:1.8, w:9, h:2.2,
      fontSize:52, bold:true, color:'FFFFFF', fontFace:FONT,
      isTextBox:true, lineSpacingMultiple:1.05,
    });

    // Subtitle
    s.addText(titleLabel, {
      x:0.55, y:4.1, w:9, h:0.55,
      fontSize:18, color:'CADCFC', fontFace:FONT,
      isTextBox:true,
    });

    // Decorative right block
    s.addShape(pres.ShapeType.rect, {
      x:11.0, y:0, w:2.33, h:7.5,
      fill:{color:'243B5E'}, line:{color:'243B5E',width:0},
    });
    s.addShape(pres.ShapeType.rect, {
      x:10.7, y:5.8, w:2.63, h:1.7,
      fill:{color:'3B6FE8'}, line:{color:'3B6FE8',width:0},
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 2 — ADVERTISING CALENDAR (TIMELINE)
  // ═══════════════════════════════════════════════════════════════
  {
    const s = pres.addSlide();
    const year = range.start.getFullYear();
    const rStart = new Date(year, 0, 1);
    const rEnd   = new Date(year, 11, 31);
    addSlideHeader(s, 'Рекламный календарь ' + year, null);

    // Group flights by collection for display (one row per collection)
    const collSet = [...new Set(flights.map(f=>f.collection).filter(Boolean))];
    const collFlightRows = collSet.map(cs => {
      return flights.filter(f=>f.collection===cs);
    });

    buildTimelineSlide(s, flights, range.start, range.end, 'timeline', useContext);
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 3 — ADVERTISING SUPPORT PRIORITIES
  // ═══════════════════════════════════════════════════════════════
  {
    const s = pres.addSlide();
    addSlideHeader(s, 'Приоритеты рекламной поддержки', null);

    // Group by collection (deduplicate), score by activity count
    const collSlugs = [...new Set(flights.map(f=>f.collection).filter(Boolean))];
    const collScored = collSlugs.map(cs => {
      const cFlights = flights.filter(f=>f.collection===cs);
      const actCount = cFlights.reduce((sum,f) => {
        return sum + activities.filter(a=>norm(a.flightName)===norm(f.name)).length;
      }, 0);
      const minDate = cFlights.reduce((m,f)=>(!m||f.dateStart<m)?f.dateStart:m, null);
      const maxDate = cFlights.reduce((m,f)=>(!m||f.dateEnd>m)?f.dateEnd:m, null);
      const skus = [...new Set(cFlights.flatMap(f=>[f.sku1,f.sku2,f.sku3]).filter(Boolean))];
      return { cs, name: collName(cs), actCount, minDate, maxDate, skus, flights: cFlights };
    });
    collScored.sort((a,b)=>b.actCount-a.actCount);

    // 5-tier system
    const TIERS = [
      { label:'Максимум',             check: x=>x.actCount>=5 },
      { label:'Максимальный сезонный',check: x=>x.actCount>=3 && x.actCount<5 },
      { label:'Высокий',              check: x=>x.actCount>=1 && x.actCount<3 },
      { label:'Поддержка',            check: x=>x.actCount===0 && x.flights.length>=2 },
      { label:'Тест',                 check: x=>x.actCount===0 && x.flights.length<2 },
    ];
    const buckets = TIERS.map(t=>({ ...t, items: collScored.filter(t.check) }));
    const filledBuckets = buckets.filter(b=>b.items.length>0);

    // Render: up to 5 columns, each bucket gets a column
    // If total cards > 20 → split into 2 slides
    const totalCards = collScored.length;
    const COLS = Math.min(filledBuckets.length, 5);
    const TIER_W = (12.43) / COLS - 0.15;
    const CONTENT_Y = 1.55;
    const CARD_H = 0.95;
    const CARD_GAP = 0.12;
    const MAX_ROWS_PER_SLIDE = Math.floor((7.2 - CONTENT_Y - 0.4) / (CARD_H + CARD_GAP));

    // Helper to render one priorities slide
    function renderPrioritiesSlide(slideRef, bucketsToRender, startRows) {
      bucketsToRender.forEach((bucket, bi) => {
        if (!bucket.items.length) return;
        const x = 0.45 + bi * (TIER_W + 0.15);

        // Tier header pill
        slideRef.addShape(pres.ShapeType.roundRect, {
          x, y:CONTENT_Y, w:TIER_W, h:0.28,
          fill:{color:'EBF0FD'}, line:{color:'C7D7F7',width:0.5},
          rectRadius:0.04,
        });
        slideRef.addText(bucket.label, {
          x, y:CONTENT_Y, w:TIER_W, h:0.28,
          fontSize:7.5, bold:true, color:'3B6FE8', align:'center', valign:'middle', fontFace:FONT,
          isTextBox:true,
        });

        const rowStart = startRows[bi] || 0;
        const rowsLeft = MAX_ROWS_PER_SLIDE;
        bucket.items.slice(rowStart, rowStart + rowsLeft).forEach((item, ci) => {
          const cy = CONTENT_Y + 0.36 + ci * (CARD_H + CARD_GAP);
          if (cy + CARD_H > 7.25) return;
          const hex = collColor(item.cs);
          const lightHex = lighten(hex, 0.9);

          slideRef.addShape(pres.ShapeType.roundRect, {
            x, y:cy, w:TIER_W, h:CARD_H,
            fill:{color:lightHex}, line:{color:hex,width:0.6},
            rectRadius:0.06,
          });
          slideRef.addShape(pres.ShapeType.rect, {
            x, y:cy, w:TIER_W, h:0.1,
            fill:{color:hex}, line:{color:hex,width:0},
          });
          slideRef.addText((item.name||item.cs).slice(0,24), {
            x:x+0.1, y:cy+0.14, w:TIER_W-0.2, h:0.26,
            fontSize:8.5, bold:true, color:CLR.text, fontFace:FONT,
            isTextBox:true,
          });
          const period = (item.minDate && item.maxDate) ? fmtRange(item.minDate, item.maxDate) : '';
          if (period) {
            slideRef.addText(period, {
              x:x+0.1, y:cy+0.4, w:TIER_W-0.2, h:0.2,
              fontSize:7.5, color:CLR.muted, fontFace:FONT,
              isTextBox:true,
            });
          }
          if (item.skus.length > 0) {
            slideRef.addText(item.skus.slice(0,2).join(', ').slice(0,35), {
              x:x+0.1, y:cy+0.6, w:TIER_W-0.2, h:0.22,
              fontSize:7, color:CLR.muted, fontFace:FONT,
              isTextBox:true,
            });
          }
        });
      });
    }

    // Check if 2 slides needed
    const maxItemsInBucket = Math.max(...filledBuckets.map(b=>b.items.length));
    if (maxItemsInBucket > MAX_ROWS_PER_SLIDE) {
      // First slide — rows 0..MAX_ROWS_PER_SLIDE-1
      const startRows1 = filledBuckets.map(()=>0);
      renderPrioritiesSlide(s, filledBuckets, startRows1);
      // Second slide
      const s2 = pres.addSlide();
      addSlideHeader(s2, 'Приоритеты рекламной поддержки (продолжение)', null);
      const startRows2 = filledBuckets.map(()=>MAX_ROWS_PER_SLIDE);
      renderPrioritiesSlide(s2, filledBuckets, startRows2);
    } else {
      renderPrioritiesSlide(s, filledBuckets, filledBuckets.map(()=>0));
    }
  }

  // ── Campaign cards helper ────────────────────────────────────
  function _addCampaignCards(pres, s, flightList, acts, startY) {
    // Layout: 3-column responsive grid of compact cards
    const COLS   = 3;
    const CARD_W = 3.9;
    const CARD_H = 1.6;
    const GAP_X  = 0.27;
    const GAP_Y  = 0.22;
    const START_X = 0.45;

    flightList.slice(0, 18).forEach((f, i) => {
      const col = i % COLS;
      const row = Math.floor(i / COLS);
      const cx  = START_X + col * (CARD_W + GAP_X);
      const cy  = startY  + row * (CARD_H + GAP_Y);
      if (cy + CARD_H > 7.3) return;

      const hex      = collColor(f.collection);
      const lightHex = lighten(hex, 0.9);
      const fActs    = acts.filter(a => norm(a.flightName) === norm(f.name));
      const score    = fActs.length;
      const priority = score >= 4 ? 'Максимальный'
                     : score >= 2 ? 'Высокий'
                     : score === 1 ? 'Поддержка'
                     : null; // no badge for 0-activity flights
      const priColors = {
        'Максимальный':'3B6FE8','Высокий':'059669','Поддержка':'F59E0B'
      };
      const priHex = priColors[priority] || CLR.gray;

      // Card background
      s.addShape(pres.ShapeType.roundRect, {
        x:cx, y:cy, w:CARD_W, h:CARD_H,
        fill:{color:lightHex}, line:{color:hex,width:0.6},
        rectRadius:0.07,
      });
      // Top accent strip
      s.addShape(pres.ShapeType.rect, {
        x:cx, y:cy, w:CARD_W, h:0.1,
        fill:{color:hex}, line:{color:hex,width:0},
      });

      // Collection name
      const cName = (collName(f.collection) || f.name).slice(0, 32);
      s.addText(cName, {
        x:cx+0.12, y:cy+0.16, w:CARD_W-0.24, h:0.28,
        fontSize:9, bold:true, color:CLR.text, fontFace:FONT,
        isTextBox:true,
      });

      // Period
      const period = fmtRange(f.dateStart, f.dateEnd);
      if (period) {
        s.addText(period, {
          x:cx+0.12, y:cy+0.45, w:CARD_W-0.24, h:0.22,
          fontSize:8, color:CLR.muted, fontFace:FONT,
          isTextBox:true,
        });
      }

      // Product focus (SKUs or brief)
      const skus = [f.sku1,f.sku2,f.sku3].filter(Boolean);
      const focus = skus.length > 0 ? skus.join(', ') : (f.brief ? f.brief.slice(0,50) : '');
      if (focus) {
        s.addText(focus.slice(0,55), {
          x:cx+0.12, y:cy+0.68, w:CARD_W-0.24, h:0.32,
          fontSize:7.5, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.2,
          isTextBox:true,
        });
      }

      // Priority badge (bottom-right) — only when there are activities
      if (priority) {
        const badgeW = 1.1;
        const badgeX = cx + CARD_W - badgeW - 0.1;
        s.addShape(pres.ShapeType.roundRect, {
          x:badgeX, y:cy+CARD_H-0.3, w:badgeW, h:0.22,
          fill:{color:lighten(priHex, 0.88)}, line:{color:priHex,width:0.4},
          rectRadius:0.11,
        });
        s.addText(priority, {
          x:badgeX, y:cy+CARD_H-0.3, w:badgeW, h:0.22,
          fontSize:6.5, color:priHex, align:'center', valign:'middle', fontFace:FONT,
          isTextBox:true,
        });
      }

      // Status dot (top-right corner)
      const dotC = statusDotColor(f.status);
      s.addShape(pres.ShapeType.ellipse, {
        x:cx+CARD_W-0.2, y:cy+0.16, w:0.1, h:0.1,
        fill:{color:dotC}, line:{color:dotC,width:0},
      });
    });

    if (flightList.length > 18) {
      const moreRow = Math.floor(18 / COLS);
      const moreY   = startY + moreRow * (CARD_H + GAP_Y);
      s.addText(`+ ещё ${flightList.length - 18} кампаний`, {
        x:START_X, y:moreY, w:12, h:0.26,
        fontSize:9, color:CLR.muted, fontFace:FONT, isTextBox:true,
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 4 — H1 CAMPAIGNS (Jan–Jun) — only for year view
  // SLIDE for quarter/month — all campaigns
  // ═══════════════════════════════════════════════════════════════
  {
    // H1 or single period
    const h1Flights = exportPeriodType === 'year'
      ? flights.filter(f => f.dateStart && f.dateStart.getMonth() < 6)
      : flights;

    if (h1Flights.length > 0) {
      const s = pres.addSlide();
      const slideTitle = exportPeriodType === 'year' ? 'Кампании I полугодия' : 'Кампании периода';
      addSlideHeader(s, slideTitle, null);
      _addCampaignCards(pres, s, h1Flights, activities, 1.6);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 5 — H2 CAMPAIGNS (Jul–Dec) — only for year view
  // ═══════════════════════════════════════════════════════════════
  if (exportPeriodType === 'year') {
    const h2Flights = flights.filter(f => f.dateStart && f.dateStart.getMonth() >= 6);
    if (h2Flights.length > 0) {
      const s = pres.addSlide();
      addSlideHeader(s, 'Кампании II полугодия', null);
      _addCampaignCards(pres, s, h2Flights, activities, 1.6);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 6 — MARKETING CONTEXT (only if useContext)
  // ═══════════════════════════════════════════════════════════════
  if (useContext) {
    const ctxInRange = allContext.filter(c =>
      c.dateStart && c.dateEnd && intersects(c.dateStart, c.dateEnd, range.start, range.end)
    );
    if (ctxInRange.length > 0) {
      const s = pres.addSlide();
      addSlideHeader(s, 'Маркетинговый контекст', null);

      const types = ['сезонность','повод','событие','лонч'];
      const typeLabels = { сезонность:'Сезонность', повод:'Поводы', событие:'События', лонч:'Лончи' };
      const typeColors = { сезонность:'DBEAFE', повод:'FEF3C7', событие:'EDE9FE', лонч:'D1FAE5' };
      const typeDotC   = { сезонность:'3B82F6', повод:'F59E0B', событие:'7C3AED', лонч:'059669' };

      let curY = 1.6;
      types.forEach(tp => {
        const items = ctxInRange.filter(c => c.type.toLowerCase() === tp).slice(0, 8);
        if (!items.length) return;

        s.addText(typeLabels[tp], {
          x:0.45, y:curY, w:12, h:0.26,
          fontSize:9, bold:true, color:CLR.muted, fontFace:FONT, charSpacing:1,
          isTextBox:true,
        });
        curY += 0.28;

        items.forEach(c => {
          const dotC = typeDotC[tp];
          s.addShape(pres.ShapeType.ellipse, {
            x:0.45, y:curY+0.06, w:0.1, h:0.1,
            fill:{color:dotC}, line:{color:dotC,width:0},
          });
          const period = fmtRange(c.dateStart, c.dateEnd);
          s.addText(c.name + (period ? '  ' + period : ''), {
            x:0.62, y:curY, w:12.2, h:0.24,
            fontSize:9, color:CLR.text, fontFace:FONT,
            isTextBox:true,
          });
          curY += 0.26;
          if (curY > 6.9) return;
        });
        curY += 0.12;
        if (curY > 6.9) return;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SLIDE 7 — PRODUCT FOCUS
  // ═══════════════════════════════════════════════════════════════
  {
    // Collect collections that have SKU data
    const collWithSkus = [];
    const collSet = [...new Set(flights.map(f=>f.collection).filter(Boolean))];
    collSet.forEach(cs => {
      const cFlights = flights.filter(f=>f.collection===cs);
      const allSkus = [...new Set(
        cFlights.flatMap(f=>[f.sku1,f.sku2,f.sku3]).filter(Boolean)
      )];
      const acts = activities.filter(a=>a.collection===cs && a.skuFinal);
      const actSkus = [...new Set(acts.map(a=>a.skuFinal).filter(Boolean))];
      const skus = [...new Set([...allSkus,...actSkus])];
      const periods = cFlights.map(f=>fmtRange(f.dateStart,f.dateEnd)).filter(Boolean);
      const minDate = cFlights.reduce((m,f)=>(!m||f.dateStart<m)?f.dateStart:m, null);
      const maxDate = cFlights.reduce((m,f)=>(!m||f.dateEnd>m)?f.dateEnd:m, null);
      if (skus.length > 0 || cFlights.length > 0) {
        collWithSkus.push({ cs, name: collName(cs), skus, minDate, maxDate, count: cFlights.length });
      }
    });

    if (collWithSkus.length > 0) {
      const s = pres.addSlide();
      addSlideHeader(s, 'Продуктовый фокус', 'Продукты, получающие рекламную поддержку');

      const CARD_W = 3.8;
      const CARD_H = 2.2;
      const COLS   = 3;
      const START_Y = 1.6;
      const START_X = 0.45;
      const GAP     = 0.22;

      collWithSkus.slice(0,9).forEach((item, i) => {
        const col = i % COLS;
        const row = Math.floor(i / COLS);
        const cx = START_X + col * (CARD_W + GAP);
        const cy = START_Y + row * (CARD_H + GAP);
        if (cy + CARD_H > 7.3) return;
        const hex = collColor(item.cs);
        const lightHex = lighten(hex, 0.9);

        s.addShape(pres.ShapeType.roundRect, {
          x:cx, y:cy, w:CARD_W, h:CARD_H,
          fill:{color:lightHex}, line:{color:hex,width:0.6},
          rectRadius:0.08,
        });
        s.addShape(pres.ShapeType.rect, {
          x:cx, y:cy, w:CARD_W, h:0.14,
          fill:{color:hex}, line:{color:hex,width:0},
        });
        s.addText(item.name, {
          x:cx+0.12, y:cy+0.18, w:CARD_W-0.24, h:0.32,
          fontSize:10, bold:true, color:CLR.text, fontFace:FONT,
          isTextBox:true,
        });
        const pd = (item.minDate && item.maxDate) ? fmtRange(item.minDate, item.maxDate) : '';
        if (pd) {
          s.addText(pd, {
            x:cx+0.12, y:cy+0.5, w:CARD_W-0.24, h:0.22,
            fontSize:8, color:CLR.muted, fontFace:FONT,
            isTextBox:true,
          });
        }
        // Show focus products (SKUs) — from flights and activity data
        const focusLabel = item.skus.length > 0 ? 'ПРОДУКТЫ В ФОКУСЕ' : 'ПЕРИОД ПОДДЕРЖКИ';
        s.addText(focusLabel, {
          x:cx+0.12, y:cy+0.76, w:CARD_W-0.24, h:0.18,
          fontSize:6.5, bold:true, color:CLR.muted, fontFace:FONT, charSpacing:0.5,
          isTextBox:true,
        });
        if (item.skus.length > 0) {
          const skuStr = item.skus.slice(0,4).join('\n');
          s.addText(skuStr, {
            x:cx+0.12, y:cy+0.94, w:CARD_W-0.24, h:1.1,
            fontSize:8, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.3,
            isTextBox:true,
          });
        } else {
          // No SKUs known yet — show the support period prominently
          const cFlightsRef = flights.filter(f=>norm(f.collection)===norm(item.cs)||f.collection===item.cs);
          const periodLines = cFlightsRef.slice(0,3).map(f=>fmtRange(f.dateStart,f.dateEnd)).filter(Boolean);
          const periodText = periodLines.length > 0 ? periodLines.join('\n') : 'Уточняется';
          s.addText(periodText, {
            x:cx+0.12, y:cy+0.94, w:CARD_W-0.24, h:1.1,
            fontSize:8, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.3,
            isTextBox:true,
          });
        }
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // DETAIL SLIDES — only for flights with substantive data
  // ═══════════════════════════════════════════════════════════════
  const substantiveFlights = flights.filter(f => isSubstantive(f));
  substantiveFlights.forEach(f => {
    const fActs = activities.filter(a => norm(a.flightName) === norm(f.name));
    const hex   = collColor(f.collection);
    const lightHex = lighten(hex, 0.92);

    const s = pres.addSlide();
    s.background = { color: CLR.white };

    // ── Top accent bar
    s.addShape(pres.ShapeType.rect, {
      x:0, y:0, w:13.33, h:0.1,
      fill:{color:hex}, line:{color:hex,width:0},
    });

    // ── Collection + flight name
    s.addText((collName(f.collection) || '').toUpperCase(), {
      x:0.45, y:0.2, w:9, h:0.25,
      fontSize:8, bold:true, color:hex, fontFace:FONT, charSpacing:2,
      isTextBox:true,
    });
    s.addText(f.name, {
      x:0.45, y:0.44, w:9, h:0.5,
      fontSize:20, bold:true, color:CLR.text, fontFace:FONT,
      isTextBox:true,
    });

    // ── Chips row (period, TA, status)
    let chipX = 0.45;
    const CHIP_Y  = 1.02;
    const CHIP_H  = 0.28;
    function addChip(label, value, bgHex) {
      const txt = label ? label + ': ' + value : value;
      const w = Math.max(txt.length * 0.073 + 0.2, 0.6);
      s.addShape(pres.ShapeType.roundRect, {
        x:chipX, y:CHIP_Y, w, h:CHIP_H,
        fill:{color:bgHex||'F0F4FF'}, line:{color:'D1D8F5',width:0.4},
        rectRadius:0.14,
      });
      s.addText(txt, {
        x:chipX+0.1, y:CHIP_Y, w:w-0.2, h:CHIP_H,
        fontSize:7.5, color:CLR.text, valign:'middle', fontFace:FONT,
        isTextBox:true,
      });
      chipX += w + 0.1;
    }

    const period = fmtRange(f.dateStart, f.dateEnd);
    if (period) addChip('', period, 'EBF0FD');
    if (f.taFinal) addChip('ЦА', f.taFinal.slice(0,30), 'F5F3FF');
    const dotC = statusDotColor(f.status);
    // Status chip
    const stLbl = f.status ? f.status.charAt(0).toUpperCase()+f.status.slice(1) : 'План';
    addChip('', stLbl, lighten(dotC, 0.88));

    // Claim
    if (f.claimFinal) {
      s.addText(f.claimFinal.slice(0,120), {
        x:0.45, y:1.38, w:8.8, h:0.4,
        fontSize:10, color:CLR.muted, fontFace:FONT, italic:true,
        isTextBox:true,
      });
    }

    s.addShape(pres.ShapeType.line, {
      x:0.45, y:1.85, w:12.43, h:0,
      line:{color:CLR.border,width:0.6},
    });

    // ── Products block
    const skus = [f.sku1,f.sku2,f.sku3].filter(Boolean);
    if (skus.length > 0) {
      s.addText('ПРОДУКТЫ В ФОКУСЕ ПРОДВИЖЕНИЯ', {
        x:0.45, y:1.95, w:8, h:0.24,
        fontSize:7, bold:true, color:CLR.muted, fontFace:FONT, charSpacing:1,
        isTextBox:true,
      });
      s.addText(skus.join('\n'), {
        x:0.45, y:2.2, w:3.8, h:0.8,
        fontSize:9, color:CLR.text, fontFace:FONT, lineSpacingMultiple:1.3,
        isTextBox:true,
      });
      // Planner: картинки SKU (главная обложка в indexM) правее списка
      ((f.extra && f.extra.skus) || []).slice(0, 3).forEach((sk, i) => {
        const img = sk.article && SKU_IMG[sk.article];
        if (img) s.addImage({ data: img, x: 4.4 + i * 0.95, y: 2.1, w: 0.85, h: 0.85, sizing: { type: 'contain', w: 0.85, h: 0.85 } });
      });
    }

    // ── Activities section header
    const actsY = skus.length > 0 ? 3.1 : 2.0;
    if (fActs.length > 0) {
      s.addText('РЕКЛАМНАЯ ПОДДЕРЖКА', {
        x:0.45, y:actsY, w:12, h:0.26,
        fontSize:7, bold:true, color:CLR.muted, fontFace:FONT, charSpacing:1,
        isTextBox:true,
      });

      // Channel cards
      const dirs = [...new Set(fActs.map(a=>a.direction).filter(Boolean))];
      const CARD_W = 1.85;
      const CARD_H = 1.25;
      const GAP    = 0.15;
      const maxCards = 6;
      dirs.slice(0, maxCards).forEach((dir, di) => {
        const cx = 0.45 + di * (CARD_W + GAP);
        const cy = actsY + 0.34;
        if (cx + CARD_W > 13) return;
        const dirActs = fActs.filter(a=>a.direction===dir);
        const platforms = [...new Set(dirActs.map(a=>a.platforms).filter(Boolean))].join(', ');
        const formats   = [...new Set(dirActs.map(a=>a.format).filter(Boolean))].join(', ');

        s.addShape(pres.ShapeType.roundRect, {
          x:cx, y:cy, w:CARD_W, h:CARD_H,
          fill:{color:'F7F8FA'}, line:{color:CLR.border,width:0.6},
          rectRadius:0.07,
        });
        s.addShape(pres.ShapeType.rect, {
          x:cx, y:cy, w:CARD_W, h:0.1,
          fill:{color:hex}, line:{color:hex,width:0},
        });
        s.addText(dir, {
          x:cx+0.1, y:cy+0.14, w:CARD_W-0.2, h:0.26,
          fontSize:9, bold:true, color:CLR.text, fontFace:FONT,
          isTextBox:true,
        });
        if (platforms) {
          s.addText(platforms.slice(0,40), {
            x:cx+0.1, y:cy+0.4, w:CARD_W-0.2, h:0.3,
            fontSize:7.5, color:CLR.muted, fontFace:FONT,
            isTextBox:true,
          });
        }
        if (formats) {
          s.addText(formats.slice(0,40), {
            x:cx+0.1, y:cy+0.7, w:CARD_W-0.2, h:0.3,
            fontSize:7.5, color:CLR.muted, fontFace:FONT,
            isTextBox:true,
          });
        }
        if (dirActs[0] && dirActs[0].dateStart) {
          const actPeriod = fmtRange(dirActs[0].dateStart, dirActs[0].dateEnd);
          s.addText(actPeriod, {
            x:cx+0.1, y:cy+1.0, w:CARD_W-0.2, h:0.2,
            fontSize:7, color:CLR.muted, fontFace:FONT,
            isTextBox:true,
          });
        }
      });
    }

    // ── Brief / comment at bottom
    const note = f.brief || f.comment;
    if (note) {
      s.addShape(pres.ShapeType.line, {
        x:0.45, y:6.7, w:12.43, h:0,
        line:{color:CLR.border,width:0.6},
      });
      s.addText(note.slice(0,180), {
        x:0.45, y:6.78, w:12.43, h:0.5,
        fontSize:8, color:CLR.muted, fontFace:FONT, italic:true,
        isTextBox:true,
      });
    }
  });

  // ── Save ───────────────────────────────────────────────────────
  const btn = document.getElementById('exportDoBtn');
  btn.textContent = 'Генерация…';
  btn.disabled = true;

  pres.write({ outputType: 'blob' })
    .then(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = data.fileLabel + '.pptx';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
      btn.textContent = '✓ Скачано';
      setTimeout(() => {
        btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12l-4-4h2.5V4h3v4H12L8 12zM2 14h12v1.5H2V14z"/></svg> Скачать PPTX';
        btn.disabled = false;
      }, 2500);
    })
    .catch(err => {
      const p = document.getElementById('exportPreview');
      p.innerHTML = '<span style="color:#e74c3c;font-weight:600">Ошибка экспорта: ' + (err.message || err) + '</span>';
      btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12l-4-4h2.5V4h3v4H12L8 12zM2 14h12v1.5H2V14z"/></svg> Скачать PPTX';
      btn.disabled = false;
    });
}

// ── INIT ───────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  initData().catch(err => {
    console.error(err);
    setStatus(false, 'Ошибка загрузки');
    document.getElementById('loadingOverlay').innerHTML = `
      <div style="text-align:center;color:var(--text-muted)">
        <div style="font-size:24px;margin-bottom:8px">⚠️</div>
        <div style="font-size:13px;font-weight:600;margin-bottom:4px">Ошибка загрузки данных</div>
        <div style="font-size:12px">${err.message || 'Проверьте подключение MCP Google Sheets'}</div>
      </div>`;
  });
});

// ── Planner: пункты меню по ролям ──────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  const u = (window.PLANNER_DATA || {}).user || {};
  document.querySelectorAll('[data-admin]').forEach(el => { if (!u.is_admin) el.remove(); });
  document.querySelectorAll('[data-writer]').forEach(el => { if (!u.can_write) el.remove(); });
  document.addEventListener('click', (e) => {
    document.querySelectorAll('details.planner-menu[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); });
  });
});
