<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ContextController;
use App\Http\Controllers\FlightController;
use App\Http\Controllers\ReferencesController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\SkuImageController;
use App\Http\Controllers\TimelineController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/login', [LoginController::class, 'showLogin'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::redirect('/', '/timeline');

    // Таймлайн — перенос прежнего index.html; картинки SKU — из indexM через Planner
    Route::get('/timeline',           [TimelineController::class, 'index'])->name('timeline');
    Route::get('/timeline/data',      [TimelineController::class, 'data'])->name('timeline.data');
    Route::get('/sku-image/{article}', [SkuImageController::class, 'show'])->name('sku-image');

    // ── Чтение — все роли ───────────────────────────────────────────────────
    // ⚠️ /flights/create обязан идти раньше /flights/{flight}
    Route::get('/flights',          [FlightController::class, 'index'])->name('flights.index');
    Route::get('/flights/create',   [FlightController::class, 'create'])->name('flights.create')->middleware('role:writer');
    Route::get('/flights/{flight}', [FlightController::class, 'show'])->name('flights.show');
    Route::get('/context',          [ContextController::class, 'index'])->name('context.index');
    Route::get('/references',       [ReferencesController::class, 'index'])->name('references.index');

    // ── Флайты, активности, контекст — редактор, админ и БМ (БМ — свои коллекции,
    //    проверка в контроллерах) ─────────────────────────────────────────────
    Route::middleware('role:writer')->group(function () {
        Route::post('/flights',                        [FlightController::class, 'store'])->name('flights.store');
        Route::patch('/flights/{flight}',              [FlightController::class, 'update'])->name('flights.update');
        Route::delete('/flights/{flight}',             [FlightController::class, 'destroy'])->name('flights.destroy');
        Route::post('/flights/{flight}/activities',    [FlightController::class, 'storeActivity'])->name('activities.store');
        Route::patch('/activities/{activity}',         [FlightController::class, 'updateActivity'])->name('activities.update');
        Route::delete('/activities/{activity}',        [FlightController::class, 'destroyActivity'])->name('activities.destroy');

        Route::post('/context',                [ContextController::class, 'store'])->name('context.store');
        Route::patch('/context/{contextItem}', [ContextController::class, 'update'])->name('context.update');
        Route::delete('/context/{contextItem}', [ContextController::class, 'destroy'])->name('context.destroy');
    });

    // ── Справочники — editor и admin ────────────────────────────────────────
    Route::middleware('role:editor')->group(function () {
        Route::post('/references/{type}',          [ReferencesController::class, 'store'])->name('references.store');
        Route::patch('/references/{type}/{id}',    [ReferencesController::class, 'update'])->whereNumber('id')->name('references.update');
        Route::delete('/references/{type}/{id}',   [ReferencesController::class, 'destroy'])->whereNumber('id')->name('references.destroy');
    });

    // ── Только admin ────────────────────────────────────────────────────────
    Route::middleware('role:admin')->group(function () {
        Route::get('/users',            [UserController::class, 'index'])->name('users.index');
        Route::post('/users',           [UserController::class, 'store'])->name('users.store');
        Route::patch('/users/{user}',   [UserController::class, 'update'])->name('users.update');
        Route::delete('/users/{user}',  [UserController::class, 'destroy'])->name('users.destroy');

        Route::get('/settings',              [SettingsController::class, 'index'])->name('settings.index');
        Route::patch('/settings',            [SettingsController::class, 'update'])->name('settings.update');
        Route::post('/settings/indexm/test', [SettingsController::class, 'testIndexm'])->name('settings.indexm.test');
    });
});
