<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Справочники и данные медиаплана — 1-в-1 листы Google-таблицы «Librederm Campaign Planner»
 * (СПР_* и ФЛАЙТЫ / АКТИВНОСТИ / КОНТЕКСТ). «Итоговые» поля таблицы (ЦА итог, клейм итог,
 * даты итог, SKU итог) не хранятся — считаются из override и родителя.
 */
return new class extends Migration {
    public function up(): void
    {
        // ── Справочники ─────────────────────────────────────────────────────────
        Schema::create('collections', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('color', 7)->nullable();          // #RRGGBB
            $table->string('bm_name')->nullable();           // «БМ / контакт» из таблицы — текстом
            $table->text('default_audience')->nullable();    // ЦА по умолчанию
            $table->text('default_claim')->nullable();       // клейм по умолчанию
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // БМ коллекции — пользователи Planner с ролью bm
        Schema::create('collection_user', function (Blueprint $table) {
            $table->foreignId('collection_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->primary(['collection_id', 'user_id']);
        });

        Schema::create('skus', function (Blueprint $table) {
            $table->id();
            $table->foreignId('collection_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name', 500);                     // полное название из прайс-листа
            $table->string('article', 50)->nullable()->index(); // артикул 1С — по нему картинка из indexM
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index('name');
        });

        Schema::create('directions', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('blocks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('direction_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['direction_id', 'name']);
        });

        Schema::create('statuses', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            // normal — обычное, bright — ярко, muted — приглушено, hidden — скрыто по умолчанию
            $table->string('behavior', 10)->default('normal');
            $table->string('color', 7)->nullable();
            $table->string('description')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('context_types', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('color', 7)->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        // ── Данные ──────────────────────────────────────────────────────────────
        Schema::create('flights', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->foreignId('collection_id')->nullable()->constrained()->nullOnDelete();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->foreignId('status_id')->nullable()->constrained()->nullOnDelete();
            $table->text('audience_override')->nullable();
            $table->text('claim_override')->nullable();
            $table->text('brief')->nullable();
            $table->text('materials_url')->nullable();
            $table->text('comment')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['start_date', 'end_date']);
        });

        Schema::create('direction_flight', function (Blueprint $table) {
            $table->foreignId('flight_id')->constrained()->cascadeOnDelete();
            $table->foreignId('direction_id')->constrained()->cascadeOnDelete();
            $table->primary(['flight_id', 'direction_id']);
        });

        Schema::create('flight_sku', function (Blueprint $table) {
            $table->foreignId('flight_id')->constrained()->cascadeOnDelete();
            $table->foreignId('sku_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('position')->default(0);
            $table->primary(['flight_id', 'sku_id']);
        });

        Schema::create('activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('flight_id')->constrained()->cascadeOnDelete();
            $table->foreignId('direction_id')->constrained()->restrictOnDelete();
            $table->foreignId('block_id')->nullable()->constrained()->nullOnDelete();
            $table->date('start_date')->nullable();          // override; пусто — даты флайта
            $table->date('end_date')->nullable();
            $table->text('platforms')->nullable();           // площадки / каналы
            $table->text('format')->nullable();              // формат / механика
            $table->text('audience_override')->nullable();
            $table->text('claim_override')->nullable();
            $table->text('materials_url')->nullable();
            $table->text('special_doc_url')->nullable();
            $table->text('comment')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        // SKU override активности; пусто — наследуются SKU флайта
        Schema::create('activity_sku', function (Blueprint $table) {
            $table->foreignId('activity_id')->constrained()->cascadeOnDelete();
            $table->foreignId('sku_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('position')->default(0);
            $table->primary(['activity_id', 'sku_id']);
        });

        Schema::create('context_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('context_type_id')->constrained()->restrictOnDelete();
            $table->string('name');
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->foreignId('collection_id')->nullable()->constrained()->nullOnDelete();
            $table->text('comment')->nullable();
            $table->string('color', 7)->nullable();          // пусто — цвет типа
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['start_date', 'end_date']);
        });
    }

    public function down(): void
    {
        foreach (['context_items', 'activity_sku', 'activities', 'flight_sku', 'direction_flight', 'flights',
                  'context_types', 'statuses', 'blocks', 'directions', 'skus', 'collection_user', 'collections'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
