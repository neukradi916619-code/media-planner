<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        $now = now();
        DB::table('settings')->insertOrIgnore([
            ['key' => 'indexm_url', 'value' => 'https://indexm.zeldis.ru', 'group' => 'indexm',
             'label' => 'Адрес indexM', 'description' => 'Откуда брать картинки SKU по артикулу.',
             'created_at' => $now, 'updated_at' => $now],
            ['key' => 'indexm_api_token', 'value' => '', 'group' => 'indexm',
             'label' => 'Токен API indexM', 'description' => 'indexM → Настройки → Интеграции → «Внешние API», подключение «Planner».',
             'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    public function down(): void
    {
        DB::table('settings')->whereIn('key', ['indexm_url', 'indexm_api_token'])->delete();
    }
};
