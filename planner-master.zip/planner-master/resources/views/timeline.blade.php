<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Таймлайн · Planner</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/timeline-assets/timeline.css?v={{ $v }}">
</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
  <a href="/timeline" class="topbar-logo" style="text-decoration:none">Librederm <span>Planner</span></a>
  <div class="topbar-sep"></div>
  <div class="filters" id="filtersBar">
    <select class="filter-select" id="filterYear" onchange="applyFilters()">
      <option value="">Все годы</option>
    </select>
    <select class="filter-select" id="filterCollection" onchange="applyFilters()">
      <option value="">Все коллекции</option>
    </select>
    <div style="display:inline-flex;align-items:center;gap:4px;position:relative;">
      <select class="filter-select" id="filterStatus" onchange="applyFilters()">
        <option value="">Все статусы</option>
        <option value="план">План</option>
        <option value="подтверждено">Подтверждено</option>
        <option value="завершено">Завершено</option>
        <option value="отменено">Отменено</option>
      </select>
      <button class="status-legend-btn" id="statusLegendBtn" title="Легенда статусов" onclick="toggleStatusLegend(event)">?</button>
      <div class="status-legend-popover" id="statusLegendPopover">
        <div class="status-legend-item"><span class="sli-dot" style="background:#9CA3AF"></span>План</div>
        <div class="status-legend-item"><span class="sli-dot" style="background:#22C55E"></span>Подтверждено</div>
        <div class="status-legend-item"><span class="sli-dot" style="background:#6B7280"></span>Завершено</div>
        <div class="status-legend-item"><span class="sli-dot" style="background:#EF4444"></span>Отменено (скрыты)</div>
      </div>
    </div>
    <select class="filter-select" id="filterDirection" onchange="applyFilters()">
      <option value="">Все направления</option>
    </select>
  </div>
  <div class="topbar-actions">
    <div class="status-dot" id="statusDot"></div>
    <span id="statusText" style="font-size:11px;color:var(--text-muted)">Загрузка...</span>
    <button class="btn btn-primary" onclick="openExportModal()" title="Экспорт в PowerPoint">
      <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M2 14a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V6h-4V2H3a1 1 0 0 0-1 1v11zm8-12.5L13.5 5H10V1.5z"/></svg>
      Экспорт PPTX
    </button>
    <details class="planner-menu"><summary class="btn">Разделы ▾</summary>
      <div class="planner-menu-list">
        <a href="/flights">Флайты</a><a href="/flights/create" data-writer>+ Новый флайт</a>
        <a href="/context">Контекст</a><a href="/references">Справочники</a>
        <a href="/users" data-admin>Пользователи</a><a href="/settings" data-admin>Настройки</a><hr>
        <form method="POST" action="/logout"><input type="hidden" name="_token" value="{{ csrf_token() }}"><button type="submit">Выйти</button></form>
      </div></details>
  </div>
</div>

<!-- EXPORT MODAL -->
<div class="modal-backdrop" id="exportBackdrop" onclick="closeExportModal(event)">
  <div class="modal" onclick="event.stopPropagation()">
    <div class="modal-header">
      <div class="modal-title">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="var(--accent)"><path d="M2 14a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V6h-4V2H3a1 1 0 0 0-1 1v11zm8-12.5L13.5 5H10V1.5z"/></svg>
        Экспорт PPTX
      </div>
      <button class="modal-close" onclick="closeExportModal()">&times;</button>
    </div>

    <!-- Период -->
    <div class="modal-section">
      <div class="modal-label">Период</div>
      <div class="modal-row">
        <div class="modal-seg">
          <button class="seg-btn active" id="epYear"    onclick="setExportPeriod('year')">Год</button>
        </div>
      </div>
      <div class="modal-row" id="exportDateRow">
        <select class="modal-select" id="expYear" onchange="updateExportPreview()">
        </select>
      </div>
    </div>

    <!-- Тип -->
    <div class="modal-section">
      <div class="modal-label">Тип презентации</div>
      <div class="modal-seg">
        <button class="seg-btn active" id="etOverview" onclick="setExportType('overview')">Обзорная</button>
        <button class="seg-btn"        id="etFull"     onclick="setExportType('full')">Полная</button>
      </div>
    </div>

    <!-- Доп. настройки -->
    <div class="modal-section">
      <div class="modal-label">Дополнительно</div>
      <div class="modal-checks">
        <label class="modal-check">
          <input type="checkbox" id="expContext" checked onchange="updateExportPreview()">
          Включить контекст (поводы, сезонность)
        </label>
        <label class="modal-check">
          <input type="checkbox" id="expFilters" checked onchange="updateExportPreview()">
          Учитывать текущие фильтры
        </label>
        <label class="modal-check">
          <input type="checkbox" id="expImages" checked>
          Картинки SKU из indexM (полная презентация)
        </label>
      </div>
    </div>

    <!-- Превью -->
    <div class="export-preview" id="exportPreview">
      Выберите параметры…
    </div>

    <div class="modal-footer">
      <button class="btn" onclick="closeExportModal()">Отмена</button>
      <button class="btn btn-primary" id="exportDoBtn" onclick="doExportPptx()">
        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12l-4-4h2.5V4h3v4H12L8 12zM2 14h12v1.5H2V14z"/></svg>
        Скачать PPTX
      </button>
    </div>
  </div>
</div>

<!-- MAIN -->
<div class="main">
  <div class="gantt-panel">
    <div class="gantt-scroll" id="ganttScroll">
      <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner"></div>
        <div class="loading-text">Загрузка…</div>
      </div>
      <div id="ganttContainer" class="gantt-container" style="display:none"></div>
    </div>
  </div>
</div>

<!-- LEGEND -->
<div class="legend-bar">
  <div class="legend-item">
    <div class="legend-dot" style="background:#3B82F6;opacity:1"></div>
    <span>Подтверждено</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#6B7280;opacity:.6"></div>
    <span>План</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#9CA3AF;opacity:.45"></div>
    <span>Завершено</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#EF4444;opacity:.3"></div>
    <span>Отменено (скрыто)</span>
  </div>
  <div class="legend-sep"></div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#fef3c7;border:1px solid #f59e0b"></div>
    <span>Повод</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#dbeafe;border:1px solid #93c5fd"></div>
    <span>Сезонность</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#ede9fe;border:1px solid #c4b5fd"></div>
    <span>Событие</span>
  </div>
  <div class="legend-item">
    <div class="legend-dot" style="background:#d1fae5;border:1px solid #6ee7b7"></div>
    <span>Лонч</span>
  </div>
</div>

<!-- DRAWER -->
<div class="drawer-overlay" id="drawerOverlay" onclick="closeDrawer()"></div>
<div class="drawer" id="drawer">
  <div class="drawer-header">
    <div class="drawer-color-strip" id="drawerStrip"></div>
    <div class="drawer-title-block">
      <div class="drawer-title" id="drawerTitle">—</div>
      <div class="drawer-subtitle" id="drawerSubtitle">—</div>
    </div>
    <button class="drawer-close" onclick="closeDrawer()">✕</button>
  </div>
  <div class="drawer-body" id="drawerBody"></div>
</div>

<!-- TOOLTIP -->
<div class="tooltip" id="tooltip"></div>
<!-- CONTEXT POPUP -->
<div class="ctx-popup" id="ctxPopup"></div>
<!-- CONTEXT DETAIL DRAWER -->
<div class="ctx-detail-drawer" id="ctxDetailDrawer">
  <div class="ctx-drawer-header"></div>
  <div class="ctx-drawer-body"></div>
</div>

<script>window.PLANNER_DATA = @json($data);</script>
<script src="/timeline-assets/timeline.js?v={{ $v }}"></script>
<script src="/timeline-assets/pptxgen.bundle.js?v=3.12.0"></script>
</body>
</html>
