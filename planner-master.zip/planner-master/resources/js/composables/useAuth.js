import { computed } from 'vue'
import { usePage } from '@inertiajs/vue3'

export const ROLE_LABELS = {
  admin: 'Администратор',
  editor: 'Редактор',
  bm: 'Бренд-менеджер',
  viewer: 'Просмотр',
}

export function useAuth() {
  const page = usePage()
  const user = computed(() => page.props.auth?.user)

  return {
    user,
    isAdmin:  computed(() => user.value?.role === 'admin'),
    // справочники и все данные
    canEdit:  computed(() => ['admin', 'editor'].includes(user.value?.role)),
    // флайты/активности/контекст — хотя бы своих коллекций
    canWrite: computed(() => ['admin', 'editor', 'bm'].includes(user.value?.role)),
    roleLabel: computed(() => ROLE_LABELS[user.value?.role] ?? ''),
  }
}
