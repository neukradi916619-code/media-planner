<template>
  <div class="min-h-screen bg-gray-50">
    <header class="bg-white border-b border-gray-200">
      <div class="max-w-7xl mx-auto px-5 flex items-center justify-between h-14">
        <div class="flex items-center gap-6">
          <a href="/timeline" class="flex items-center gap-2">
            <span class="text-lg">📅</span>
            <span class="font-bold text-gray-900 tracking-tight">Planner</span>
          </a>
          <nav class="flex items-center gap-1">
            <!-- таймлайн — отдельная страница (перенос index.html), не Inertia -->
            <a href="/timeline" class="nav-link">Таймлайн</a>
            <Link href="/flights" class="nav-link" :class="{ 'nav-link-on': isOn('/flights') }">Флайты</Link>
            <Link href="/context" class="nav-link" :class="{ 'nav-link-on': isOn('/context') }">Контекст</Link>
            <Link href="/references" class="nav-link" :class="{ 'nav-link-on': isOn('/references') }">Справочники</Link>
            <Link v-if="isAdmin" href="/users" class="nav-link" :class="{ 'nav-link-on': isOn('/users') }">Пользователи</Link>
            <Link v-if="isAdmin" href="/settings" class="nav-link" :class="{ 'nav-link-on': isOn('/settings') }">Настройки</Link>
          </nav>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-right leading-tight">
            <div class="text-sm font-medium text-gray-800">{{ user?.name }}</div>
            <div class="text-[11px] text-gray-400">{{ roleLabel }}</div>
          </div>
          <button @click="logout" class="text-gray-400 hover:text-gray-700 text-sm" title="Выйти">⏻</button>
        </div>
      </div>
    </header>

    <div v-if="flashSuccess" class="max-w-7xl mx-auto px-5 pt-4">
      <div class="bg-green-50 text-green-700 border border-green-200 rounded-lg px-4 py-2 text-sm">{{ flashSuccess }}</div>
    </div>
    <div v-if="flashError" class="max-w-7xl mx-auto px-5 pt-4">
      <div class="bg-red-50 text-red-700 border border-red-200 rounded-lg px-4 py-2 text-sm">{{ flashError }}</div>
    </div>

    <main class="max-w-7xl mx-auto px-5 py-6">
      <slot />
    </main>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Link, router, usePage } from '@inertiajs/vue3'
import { useAuth } from '@/composables/useAuth'

const { user, isAdmin, roleLabel } = useAuth()
const page = usePage()

const flashSuccess = computed(() => page.props.flash?.success)
const flashError = computed(() => page.props.flash?.error)

function isOn(prefix) {
  return page.url.startsWith(prefix)
}

function logout() {
  router.post('/logout')
}
</script>

<style scoped>
.nav-link { padding: 7px 12px; border-radius: 8px; font-size: 13.5px; font-weight: 500; color: #6b7280; }
.nav-link:hover { background: #f3f4f6; color: #1f2937; }
.nav-link-on { background: #fff7ed; color: #c2410c; font-weight: 600; }
</style>
