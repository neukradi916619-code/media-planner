<template>
  <div>
    <div class="flex flex-wrap gap-1.5" :class="{ 'mb-2': selected.length }">
      <span v-for="s in selected" :key="s.id"
        class="inline-flex items-center gap-1 max-w-full px-2 py-0.5 rounded-md bg-orange-50 border border-orange-100 text-xs text-gray-800">
        <span class="truncate" :title="s.name">{{ s.name }}</span>
        <span v-if="s.article" class="text-gray-400 font-mono">{{ s.article }}</span>
        <button v-if="!disabled" type="button" class="text-gray-400 hover:text-red-600" @click="remove(s.id)">×</button>
      </span>
    </div>
    <div v-if="!disabled" class="relative">
      <input v-model="query" class="input" :placeholder="placeholder" @focus="open = true" @blur="close" @keydown.esc="open = false" />
      <div v-if="open && matches.length" class="absolute z-30 mt-1 w-full max-h-64 overflow-y-auto bg-white border border-gray-200 rounded-lg shadow-lg">
        <button v-for="s in matches" :key="s.id" type="button"
          class="block w-full text-left px-3 py-1.5 text-sm hover:bg-orange-50" @mousedown.prevent="add(s.id)">
          {{ s.name }} <span v-if="s.article" class="text-xs text-gray-400 font-mono">{{ s.article }}</span>
        </button>
      </div>
      <p v-if="open && !matches.length" class="text-xs text-gray-400 mt-1">{{ options.length ? 'Ничего не найдено' : 'В коллекции нет активных SKU' }}</p>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  // SKU, из которых можно выбирать (уже отфильтрованы по коллекции и активности)
  options: { type: Array, default: () => [] },
  // все SKU — чтобы показать уже выбранные, даже если их сняли с активных
  all: { type: Array, default: () => [] },
  disabled: Boolean,
  placeholder: { type: String, default: 'Добавить SKU — поиск по названию или артикулу…' },
})
const emit = defineEmits(['update:modelValue'])

const query = ref('')
const open = ref(false)
const byId = computed(() => Object.fromEntries(props.all.map((s) => [s.id, s])))
const selected = computed(() => props.modelValue.map((id) => byId.value[id]).filter(Boolean))
const matches = computed(() => {
  const q = query.value.trim().toLowerCase()
  return props.options
    .filter((s) => !props.modelValue.includes(s.id))
    .filter((s) => !q || s.name.toLowerCase().includes(q) || (s.article || '').includes(q))
    .slice(0, 60)
})

function add(id) {
  emit('update:modelValue', [...props.modelValue, id])
  query.value = ''
}
function remove(id) {
  emit('update:modelValue', props.modelValue.filter((x) => x !== id))
}
function close() {
  setTimeout(() => { open.value = false }, 120)
}
</script>
