<template>
  <Teleport to="body">
    <div v-if="show" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      @keydown.esc="cancel">
      <div class="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
        <div class="flex items-center gap-2 mb-3">
          <span class="text-red-500 text-xl">⚠</span>
          <h3 class="text-lg font-bold text-gray-900">{{ title }}</h3>
        </div>

        <p class="text-sm text-gray-600 mb-4">
          Это действие необратимо. Чтобы подтвердить удаление, введите
          {{ kindLabel }} <span class="font-semibold text-gray-900">«{{ entityName }}»</span> в поле ниже.
        </p>

        <input v-model="typed" type="text" autofocus autocomplete="off"
          class="input w-full mb-4" :placeholder="entityName"
          @keydown.enter="confirm" />

        <div class="flex gap-3 justify-end">
          <button type="button" class="btn-secondary" @click="cancel">Отмена</button>
          <button type="button" :disabled="!matches || processing"
            class="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            @click="confirm">
            {{ processing ? 'Удаление…' : 'Удалить' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  show:        { type: Boolean, default: false },
  title:       { type: String, required: true },
  entityName:  { type: String, required: true },
  // Родительный падеж того, что удаляем, например "название бренда" / "название коллекции" / "код релиза"
  kindLabel:   { type: String, default: 'точное название' },
  processing:  { type: Boolean, default: false },
})

const emit = defineEmits(['confirm', 'cancel'])

const typed = ref('')
const matches = computed(() => typed.value.trim() === props.entityName)

watch(() => props.show, (v) => { if (v) typed.value = '' })

function confirm() {
  if (matches.value && !props.processing) emit('confirm')
}
function cancel() {
  emit('cancel')
}
</script>
