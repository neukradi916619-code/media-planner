import '../css/app.css';
import axios from 'axios';
import { router } from '@inertiajs/vue3';
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

// Read CSRF token from meta tag at startup
function refreshCsrfToken() {
    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
    if (token) axios.defaults.headers.common['X-CSRF-TOKEN'] = token;
}
refreshCsrfToken();

import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy';

createInertiaApp({
    title: (title) => title ? `${title} · Planner` : 'Planner',
    resolve: (name) => resolvePageComponent(
        `./Pages/${name}.vue`,
        import.meta.glob('./Pages/**/*.vue'),
    ),
    setup({ el, App, props, plugin }) {
        return createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(ZiggyVue)
            .mount(el);
    },
    progress: {
        color: '#6366f1',
    },
});

// Обновляем CSRF токен после каждой Inertia-навигации (актуальный токен из props)
router.on('navigate', (event) => {
    const token = event.detail?.page?.props?.csrf_token;
    if (token) {
        axios.defaults.headers.common['X-CSRF-TOKEN'] = token;
        const meta = document.querySelector('meta[name="csrf-token"]');
        if (meta) meta.setAttribute('content', token);
    } else {
        refreshCsrfToken();
    }
});
