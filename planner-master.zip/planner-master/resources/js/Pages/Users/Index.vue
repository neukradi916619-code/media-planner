<template>
  <AppLayout>
    <Head title="Пользователи" />

    <div class="flex items-center justify-between mb-4">
      <h1 class="text-xl font-bold text-gray-900">Пользователи</h1>
      <button class="btn-primary" @click="openForm()">+ Пользователь</button>
    </div>

    <div class="bg-white border border-gray-200 rounded-xl overflow-hidden">
      <table class="w-full">
        <thead class="border-b border-gray-100">
          <tr><th class="th">Имя</th><th class="th">Email</th><th class="th">Роль</th><th class="th">Коллекции БМ</th><th class="th w-10"></th></tr>
        </thead>
        <tbody>
          <tr v-for="u in users" :key="u.id" class="border-b border-gray-50 hover:bg-orange-50/40">
            <td class="td font-medium text-gray-900">{{ u.name }}</td>
            <td class="td">{{ u.email }}</td>
            <td class="td">{{ roles[u.role] }}</td>
            <td class="td text-xs">
              <template v-if="u.role === 'bm'">
                <span v-if="!u.collection_ids.length" class="text-red-500">не назначены</span>
                <span v-for="id in u.collection_ids" :key="id" class="inline-block mr-1 mb-1 px-2 py-0.5 rounded-full bg-gray-100">{{ collectionsById[id]?.name }}</span>
              </template>
            </td>
            <td class="td text-right"><button class="text-gray-400 hover:text-orange-600" @click="openForm(u)">✎</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="mt-4 text-sm text-gray-500 space-y-1">
      <p><b>Администратор</b> — всё, плюс пользователи и настройки. <b>Редактор</b> — все данные и справочники.</p>
      <p><b>Бренд-менеджер</b> — флайты, активности и контекст своих коллекций; справочники — только просмотр. <b>Просмотр</b> — таймлайн, карточки, выгрузка PPTX.</p>
    </div>

    <Teleport to="body">
      <div v-if="form" class="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" @mousedown.self="form = null">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
          <h3 class="text-lg font-bold text-gray-900 mb-4">{{ editing ? 'Пользователь' : 'Новый пользователь' }}</h3>
          <div class="space-y-3">
            <div><label class="label">Имя</label><input v-model="form.name" class="input" /><p v-if="form.errors.name" class="err">{{ form.errors.name }}</p></div>
            <div><label class="label">Email (логин)</label><input v-model="form.email" class="input" /><p v-if="form.errors.email" class="err">{{ form.errors.email }}</p></div>
            <div>
              <label class="label">{{ editing ? 'Новый пароль (пусто — не менять)' : 'Пароль' }}</label>
              <input v-model="form.password" type="password" autocomplete="new-password" class="input" />
              <p v-if="form.errors.password" class="err">{{ form.errors.password }}</p>
            </div>
            <div>
              <label class="label">Роль</label>
              <select v-model="form.role" class="input"><option v-for="(label, key) in roles" :key="key" :value="key">{{ label }}</option></select>
              <p v-if="form.errors.role" class="err">{{ form.errors.role }}</p>
            </div>
            <div v-if="form.role === 'bm'">
              <label class="label">Коллекции, которые правит БМ</label>
              <input v-model="collectionSearch" class="input mb-2" placeholder="Поиск коллекции…" />
              <div class="max-h-60 overflow-y-auto border border-gray-100 rounded-lg p-2 space-y-1">
                <label v-for="c in filteredCollections" :key="c.id" class="flex items-center gap-2 text-sm">
                  <input type="checkbox" :value="c.id" v-model="form.collection_ids" />
                  <span class="w-3 h-3 rounded-sm" :style="{ background: c.color || '#e5e7eb' }"></span>
                  {{ c.name }} <span v-if="c.bm_name" class="text-xs text-gray-400">· {{ c.bm_name }}</span>
                </label>
              </div>
            </div>
          </div>
          <div class="flex items-center gap-3 mt-6">
            <button v-if="editing && editing.id !== user.id" class="text-sm text-red-600 hover:text-red-700" @click="confirmDelete = true">Удалить</button>
            <div class="ml-auto flex gap-3">
              <button class="btn-secondary" @click="form = null">Отмена</button>
              <button class="btn-primary" :disabled="form.processing" @click="save">Сохранить</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <ConfirmDeleteModal :show="confirmDelete" title="Удалить пользователя" :entity-name="editing?.name || ''"
      kind-label="имя" @confirm="remove" @cancel="confirmDelete = false" />
  </AppLayout>
</template>

<script setup>
import { computed, ref } from 'vue'
import { Head, router, useForm } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'
import ConfirmDeleteModal from '@/Components/ConfirmDeleteModal.vue'
import { useAuth } from '@/composables/useAuth'

const props = defineProps({ users: Array, collections: Array, roles: Object })
const { user } = useAuth()

const collectionsById = computed(() => Object.fromEntries(props.collections.map((c) => [c.id, c])))
const form = ref(null)
const editing = ref(null)
const confirmDelete = ref(false)
const collectionSearch = ref('')
const filteredCollections = computed(() => {
  const q = collectionSearch.value.trim().toLowerCase()
  return props.collections.filter((c) => !q || c.name.toLowerCase().includes(q) || (c.bm_name || '').toLowerCase().includes(q))
})

function openForm(u = null) {
  editing.value = u
  collectionSearch.value = ''
  form.value = useForm({
    name: u?.name ?? '', email: u?.email ?? '', password: '', role: u?.role ?? 'viewer',
    collection_ids: [...(u?.collection_ids ?? [])],
  })
}

function save() {
  const opts = { preserveScroll: true, onSuccess: () => { form.value = null } }
  editing.value ? form.value.patch(`/users/${editing.value.id}`, opts) : form.value.post('/users', opts)
}

function remove() {
  router.delete(`/users/${editing.value.id}`, {
    preserveScroll: true,
    onFinish: () => { confirmDelete.value = false; form.value = null },
  })
}
</script>

<style scoped>
.err { font-size: 12px; color: #dc2626; margin-top: 4px; }
</style>
