<template>
  <AppLayout>
    <Head title="Настройки" />
    <h1 class="text-xl font-bold text-gray-900 mb-4">Настройки</h1>

    <div class="bg-white border border-gray-200 rounded-xl p-6 max-w-2xl">
      <h2 class="font-semibold text-gray-900 mb-1">indexM — картинки SKU</h2>
      <p class="text-sm text-gray-500 mb-4">
        Planner берёт главную картинку SKU по артикулу. Токен — в indexM:
        Настройки → Интеграции → «Внешние API», подключение «Planner».
      </p>
      <div class="space-y-3">
        <div>
          <label class="label">{{ s.indexm_url?.label }}</label>
          <input v-model="form.settings.indexm_url" class="input" placeholder="https://indexm.zeldis.ru" />
        </div>
        <div>
          <label class="label">{{ s.indexm_api_token?.label }}</label>
          <input v-model="form.settings.indexm_api_token" type="password" autocomplete="off" class="input"
            :placeholder="s.indexm_api_token?.is_set ? 'задан — оставьте пустым, чтобы не менять' : 'ixm_…'" />
        </div>
      </div>
      <div class="flex items-center gap-3 mt-5">
        <button class="btn-primary" :disabled="form.processing" @click="save">Сохранить</button>
        <button class="btn-secondary" :disabled="testing" @click="test">{{ testing ? 'Проверка…' : 'Проверить соединение' }}</button>
      </div>
      <p v-if="testResult" class="text-sm mt-3" :class="testResult.ok ? 'text-green-700' : 'text-red-600'">{{ testResult.message }}</p>
    </div>
  </AppLayout>
</template>

<script setup>
import { computed, ref } from 'vue'
import { Head, useForm } from '@inertiajs/vue3'
import axios from 'axios'
import AppLayout from '@/Layouts/AppLayout.vue'

const props = defineProps({ settings: Object })
const s = computed(() => props.settings.indexm ?? {})

const form = useForm({
  settings: {
    indexm_url: s.value.indexm_url?.value ?? '',
    indexm_api_token: '',
  },
})
const testing = ref(false)
const testResult = ref(null)

function save() {
  form.patch('/settings', { preserveScroll: true, onSuccess: () => { form.settings.indexm_api_token = '' } })
}

async function test() {
  testing.value = true
  testResult.value = null
  try {
    const { data } = await axios.post('/settings/indexm/test', form.settings)
    testResult.value = data
  } catch (e) {
    testResult.value = { ok: false, message: e.response?.data?.message || 'Ошибка проверки.' }
  } finally {
    testing.value = false
  }
}
</script>
