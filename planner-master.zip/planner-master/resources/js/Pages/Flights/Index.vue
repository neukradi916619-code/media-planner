<template>
  <AppLayout>
    <Head title="Флайты" />

    <div class="flex items-center justify-between mb-4">
      <h1 class="text-xl font-bold text-gray-900">Флайты</h1>
      <div class="flex items-center gap-3">
        <span class="text-sm text-gray-400">{{ filtered.length }} из {{ flights.length }}</span>
        <Link v-if="can_create" href="/flights/create" class="btn-primary">+ Флайт</Link>
      </div>
    </div>

    <div class="flex flex-wrap items-center gap-2 mb-3">
      <input v-model="search" class="input max-w-sm" placeholder="Поиск по названию, коллекции, БМ…" />
      <select v-model="year" class="filter-select">
        <option value="">Все годы</option>
        <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
      </select>
      <label class="flex items-center gap-1.5 text-sm text-gray-500"><input type="checkbox" v-model="onlyMine" /> только мои (могу править)</label>
    </div>

    <div class="bg-white border border-gray-200 rounded-xl overflow-x-auto">
      <table class="w-full">
        <thead class="border-b border-gray-100">
          <tr>
            <th class="th">Флайт</th><th class="th">Период</th><th class="th">Статус</th>
            <th class="th">БМ</th><th class="th">Направления</th><th class="th">Активн.</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="f in filtered" :key="f.id" class="border-b border-gray-50 align-top hover:bg-orange-50/40 cursor-pointer" @click="router.visit(`/flights/${f.id}`)"
              :class="{ 'opacity-50': f.status?.behavior === 'muted' || f.status?.behavior === 'hidden' }">
            <td class="td">
              <Link :href="`/flights/${f.id}`" class="font-medium text-gray-900 hover:text-orange-700" @click.stop>{{ f.name }}</Link>
              <div v-if="f.collection" class="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5">
                <span class="w-2.5 h-2.5 rounded-sm" :style="{ background: f.collection.color || '#e5e7eb' }"></span>
                {{ f.collection.name }}
              </div>
            </td>
            <td class="td whitespace-nowrap text-xs">{{ fmt(f.start_date) }} — {{ fmt(f.end_date) }}</td>
            <td class="td">
              <span v-if="f.status" class="text-xs px-2 py-0.5 rounded-full text-white whitespace-nowrap"
                :style="{ background: f.status.color || '#94a3b8' }">{{ f.status.name }}</span>
            </td>
            <td class="td text-xs">{{ f.bm }}</td>
            <td class="td text-xs">{{ f.directions.join(', ') }}</td>
            <td class="td text-xs">{{ f.activities_count }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </AppLayout>
</template>

<script setup>
import { computed, ref } from 'vue'
import { Head, Link, router } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'

const props = defineProps({ flights: Array, can_create: Boolean })
const search = ref('')
const onlyMine = ref(false)
const year = ref('')

const years = computed(() => [...new Set(props.flights.flatMap((f) => [f.start_date, f.end_date]).filter(Boolean).map((d) => d.slice(0, 4)))].sort())
const filtered = computed(() => {
  const q = search.value.trim().toLowerCase()
  return props.flights.filter((f) =>
    (!onlyMine.value || f.can_edit)
    && (!q || [f.name, f.collection?.name, f.bm].some((v) => (v || '').toLowerCase().includes(q)))
    && (!year.value || (f.start_date || '') <= `${year.value}-12-31` && (f.end_date || f.start_date || '') >= `${year.value}-01-01`))
})

function fmt(d) {
  return d ? d.split('-').reverse().join('.') : '…'
}
</script>
