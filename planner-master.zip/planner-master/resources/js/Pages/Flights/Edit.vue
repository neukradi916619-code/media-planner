<template>
  <AppLayout>
    <Head :title="flight ? flight.name : 'Новый флайт'" />

    <div class="flex items-center gap-3 mb-4">
      <Link href="/flights" class="text-sm text-gray-400 hover:text-gray-700">← Флайты</Link>
      <h1 class="text-xl font-bold text-gray-900 truncate">{{ flight ? flight.name : 'Новый флайт' }}</h1>
      <span v-if="flight && !canEdit" class="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">только просмотр</span>
      <button v-if="flight && canEdit" class="ml-auto text-sm text-red-600 hover:text-red-700" @click="confirmDelete = true">Удалить флайт</button>
    </div>

    <!-- ── Флайт ─────────────────────────────────────────────────────────── -->
    <fieldset :disabled="!canEdit" class="bg-white border border-gray-200 rounded-xl p-6">
      <div class="grid md:grid-cols-2 gap-x-6 gap-y-4">
        <div class="md:col-span-2">
          <label class="label">Название флайта</label>
          <input v-model="form.name" class="input" />
          <p v-if="form.errors.name" class="err">{{ form.errors.name }}</p>
        </div>

        <div>
          <label class="label">Коллекция</label>
          <select v-model="form.collection_id" class="input">
            <option :value="null" disabled>— выберите —</option>
            <option v-for="c in collectionOptions" :key="c.id" :value="c.id" :disabled="!c.editable">{{ c.name }}{{ c.is_active ? '' : ' (неактивна)' }}</option>
          </select>
          <p v-if="form.errors.collection_id" class="err">{{ form.errors.collection_id }}</p>
          <p v-if="collection" class="hint">БМ / контакт: {{ collection.bm_name || '—' }}</p>
        </div>

        <div>
          <label class="label">Статус</label>
          <select v-model="form.status_id" class="input">
            <option v-for="s in statuses" :key="s.id" :value="s.id">{{ s.name }}</option>
          </select>
          <p v-if="form.errors.status_id" class="err">{{ form.errors.status_id }}</p>
        </div>

        <div>
          <label class="label">Дата начала</label>
          <input v-model="form.start_date" type="date" class="input" />
          <p v-if="form.errors.start_date" class="err">{{ form.errors.start_date }}</p>
        </div>
        <div>
          <label class="label">Дата окончания</label>
          <input v-model="form.end_date" type="date" class="input" />
          <p v-if="form.errors.end_date" class="err">{{ form.errors.end_date }}</p>
        </div>

        <div class="md:col-span-2">
          <label class="label">Направления</label>
          <div class="flex flex-wrap gap-x-5 gap-y-2">
            <label v-for="d in directionOptions" :key="d.id" class="flex items-center gap-1.5 text-sm text-gray-700">
              <input type="checkbox" :value="d.id" v-model="form.direction_ids" /> {{ d.name }}
            </label>
          </div>
          <p v-if="form.errors.direction_ids" class="err">{{ form.errors.direction_ids }}</p>
        </div>

        <div class="md:col-span-2">
          <label class="label">SKU флайта</label>
          <SkuPicker v-model="form.sku_ids" :options="collectionSkus" :all="skus" :disabled="!canEdit || !form.collection_id"
            :placeholder="form.collection_id ? undefined : 'Сначала выберите коллекцию'" />
          <p v-if="form.errors.sku_ids" class="err">{{ form.errors.sku_ids }}</p>
        </div>

        <div>
          <label class="label">ЦА</label>
          <textarea v-model="form.audience_override" rows="2" class="input" :placeholder="inheritHint(collection?.default_audience)"></textarea>
          <p class="hint">{{ form.audience_override ? 'Своя ЦА флайта' : 'Из коллекции' }}</p>
        </div>
        <div>
          <label class="label">Клейм</label>
          <textarea v-model="form.claim_override" rows="2" class="input" :placeholder="inheritHint(collection?.default_claim)"></textarea>
          <p class="hint">{{ form.claim_override ? 'Свой клейм флайта' : 'Из коллекции' }}</p>
        </div>

        <div class="md:col-span-2">
          <label class="label">Общий бриф</label>
          <textarea v-model="form.brief" rows="3" class="input"></textarea>
        </div>
        <div>
          <label class="label">Материалы / общая папка</label>
          <input v-model="form.materials_url" class="input" placeholder="ссылка" />
          <a v-if="isUrl(form.materials_url)" :href="form.materials_url" target="_blank" rel="noopener" class="hint text-orange-600 hover:underline">открыть ↗</a>
        </div>
        <div>
          <label class="label">Комментарий</label>
          <textarea v-model="form.comment" rows="2" class="input"></textarea>
        </div>
      </div>

      <div v-if="canEdit" class="flex justify-end mt-6">
        <button type="button" class="btn-primary" :disabled="form.processing" @click="saveFlight">
          {{ flight ? 'Сохранить флайт' : 'Создать флайт' }}
        </button>
      </div>
    </fieldset>

    <!-- ── Активности ────────────────────────────────────────────────────── -->
    <div v-if="flight" class="mt-6">
      <div class="flex items-center justify-between mb-3">
        <h2 class="text-lg font-bold text-gray-900">Активности <span class="text-gray-400 font-normal">{{ activities.length }}</span></h2>
        <button v-if="canEdit" class="btn-secondary" :disabled="!flightDirections.length" @click="openActivity()"
          :title="flightDirections.length ? '' : 'Отметьте направления флайта и сохраните'">+ Активность</button>
      </div>
      <div class="bg-white border border-gray-200 rounded-xl overflow-x-auto">
        <table class="w-full">
          <thead class="border-b border-gray-100">
            <tr><th class="th">Направление / блок</th><th class="th">Период</th><th class="th">Площадки</th><th class="th">Формат / механика</th><th class="th">SKU</th><th class="th w-10"></th></tr>
          </thead>
          <tbody>
            <tr v-for="a in activities" :key="a.id" class="border-b border-gray-50 align-top hover:bg-orange-50/40">
              <td class="td">
                <div class="font-medium text-gray-900">{{ directionsById[a.direction_id]?.name }}</div>
                <div class="text-xs text-gray-500">{{ blocksById[a.block_id]?.name || '—' }}</div>
              </td>
              <td class="td text-xs whitespace-nowrap" :class="{ 'text-gray-400': !a.start_date && !a.end_date }">
                {{ fmt(a.start_date || form.start_date) }} — {{ fmt(a.end_date || form.end_date) }}
              </td>
              <td class="td text-xs">{{ a.platforms }}</td>
              <td class="td text-xs">{{ a.format }}</td>
              <td class="td text-xs" :class="{ 'text-gray-400': !a.sku_ids.length }">{{ a.sku_ids.length || form.sku_ids.length }}{{ a.sku_ids.length ? '' : ' (флайта)' }}</td>
              <td class="td text-right"><button class="text-gray-400 hover:text-orange-600" @click="openActivity(a)">{{ canEdit ? '✎' : '👁' }}</button></td>
            </tr>
            <tr v-if="!activities.length"><td colspan="6" class="td text-center text-gray-400 py-6">Активностей пока нет</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ── История ───────────────────────────────────────────────────────── -->
    <div v-if="flight?.history?.length" class="mt-6">
      <h2 class="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">История изменений</h2>
      <ul class="text-xs text-gray-500 space-y-1">
        <li v-for="(h, i) in flight.history" :key="i">
          {{ fmtDateTime(h.at) }} · {{ h.user || 'система' }} · {{ actionLabel[h.action] }} {{ h.entity }}<span v-if="h.fields.length">: {{ h.fields.map((f) => fieldLabel[f] || f).join(', ') }}</span>
        </li>
      </ul>
    </div>

    <!-- ── Форма активности ──────────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="act" class="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" @mousedown.self="act = null">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-2xl p-6 max-h-[92vh] overflow-y-auto">
          <h3 class="text-lg font-bold text-gray-900 mb-4">{{ act.id ? 'Активность' : 'Новая активность' }}</h3>
          <fieldset :disabled="!canEdit" class="grid md:grid-cols-2 gap-x-5 gap-y-3">
            <div>
              <label class="label">Направление</label>
              <select v-model="act.direction_id" class="input" @change="act.block_id = null">
                <option v-for="d in flightDirections" :key="d.id" :value="d.id">{{ d.name }}</option>
              </select>
              <p v-if="actErrors.direction_id" class="err">{{ actErrors.direction_id }}</p>
            </div>
            <div>
              <label class="label">Рекламный блок</label>
              <select v-model="act.block_id" class="input">
                <option :value="null">—</option>
                <option v-for="b in actBlocks" :key="b.id" :value="b.id">{{ b.name }}</option>
              </select>
              <p v-if="actErrors.block_id" class="err">{{ actErrors.block_id }}</p>
            </div>
            <div>
              <label class="label">Дата начала</label>
              <input v-model="act.start_date" type="date" class="input" />
              <p class="hint">{{ act.start_date ? 'Своя дата' : `Из флайта: ${fmt(form.start_date)}` }}</p>
            </div>
            <div>
              <label class="label">Дата окончания</label>
              <input v-model="act.end_date" type="date" class="input" />
              <p class="hint">{{ act.end_date ? 'Своя дата' : `Из флайта: ${fmt(form.end_date)}` }}</p>
              <p v-if="actErrors.end_date" class="err">{{ actErrors.end_date }}</p>
            </div>
            <div>
              <label class="label">Площадки / краткое описание</label>
              <textarea v-model="act.platforms" rows="2" class="input"></textarea>
            </div>
            <div>
              <label class="label">Формат / механика</label>
              <textarea v-model="act.format" rows="2" class="input"></textarea>
            </div>
            <div class="md:col-span-2">
              <label class="label">SKU активности</label>
              <SkuPicker v-model="act.sku_ids" :options="collectionSkus" :all="skus" :disabled="!canEdit" />
              <p class="hint">{{ act.sku_ids.length ? 'Свои SKU активности' : `Пусто — SKU флайта (${form.sku_ids.length})` }}</p>
              <p v-if="actErrors.sku_ids" class="err">{{ actErrors.sku_ids }}</p>
            </div>
            <div>
              <label class="label">ЦА</label>
              <textarea v-model="act.audience_override" rows="2" class="input" :placeholder="inheritHint(flightAudience)"></textarea>
              <p class="hint">{{ act.audience_override ? 'Своя ЦА' : 'Из флайта' }}</p>
            </div>
            <div>
              <label class="label">Клейм</label>
              <textarea v-model="act.claim_override" rows="2" class="input" :placeholder="inheritHint(flightClaim)"></textarea>
              <p class="hint">{{ act.claim_override ? 'Свой клейм' : 'Из флайта' }}</p>
            </div>
            <div>
              <label class="label">Материалы / результаты</label>
              <input v-model="act.materials_url" class="input" />
            </div>
            <div>
              <label class="label">Спец. документ</label>
              <input v-model="act.special_doc_url" class="input" />
            </div>
            <div class="md:col-span-2">
              <label class="label">Комментарий</label>
              <textarea v-model="act.comment" rows="2" class="input"></textarea>
            </div>
          </fieldset>
          <p v-if="actErrors._" class="text-sm text-red-600 mt-3">{{ actErrors._ }}</p>
          <div class="flex items-center gap-3 mt-6">
            <button v-if="act.id && canEdit" type="button" class="text-sm text-red-600 hover:text-red-700" @click="removeActivity">Удалить</button>
            <div class="ml-auto flex gap-3">
              <button type="button" class="btn-secondary" @click="act = null">{{ canEdit ? 'Отмена' : 'Закрыть' }}</button>
              <button v-if="canEdit" type="button" class="btn-primary" :disabled="actSaving" @click="saveActivity">Сохранить</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <ConfirmDeleteModal :show="confirmDelete" title="Удалить флайт" :entity-name="flight?.name || ''" kind-label="название флайта"
      @confirm="removeFlight" @cancel="confirmDelete = false" />
  </AppLayout>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { Head, Link, router, useForm } from '@inertiajs/vue3'
import axios from 'axios'
import AppLayout from '@/Layouts/AppLayout.vue'
import ConfirmDeleteModal from '@/Components/ConfirmDeleteModal.vue'
import SkuPicker from '@/Components/SkuPicker.vue'

const props = defineProps({
  flight: Object, collections: Array, statuses: Array, directions: Array, blocks: Array, skus: Array,
})

const canEdit = computed(() => props.flight ? props.flight.can_edit : true)
const index = (list) => Object.fromEntries(list.map((x) => [x.id, x]))
const collectionsById = computed(() => index(props.collections))
const directionsById = computed(() => index(props.directions))
const blocksById = computed(() => index(props.blocks))

const f = props.flight
const form = useForm({
  name: f?.name ?? '',
  collection_id: f?.collection_id ?? null,
  start_date: f?.start_date ?? '',
  end_date: f?.end_date ?? '',
  status_id: f?.status_id ?? props.statuses[0]?.id ?? null,
  audience_override: f?.audience_override ?? '',
  claim_override: f?.claim_override ?? '',
  brief: f?.brief ?? '',
  materials_url: f?.materials_url ?? '',
  comment: f?.comment ?? '',
  direction_ids: [...(f?.direction_ids ?? [])],
  sku_ids: [...(f?.sku_ids ?? [])],
})

const collection = computed(() => collectionsById.value[form.collection_id])
// Неактивные коллекции/направления/SKU не предлагаем, но оставляем уже выбранные
const collectionOptions = computed(() => props.collections.filter((c) => c.is_active || c.id === form.collection_id))
const directionOptions = computed(() => props.directions.filter((d) => d.is_active || form.direction_ids.includes(d.id)))
const collectionSkus = computed(() => props.skus.filter((s) => s.collection_id === form.collection_id && s.is_active))

// При смене коллекции SKU чужой коллекции снимаем
watch(() => form.collection_id, (id, old) => {
  if (old !== undefined && id !== old) {
    const allowed = new Set(props.skus.filter((s) => s.collection_id === id).map((s) => s.id))
    form.sku_ids = form.sku_ids.filter((x) => allowed.has(x))
  }
})

const flightAudience = computed(() => form.audience_override || collection.value?.default_audience)
const flightClaim = computed(() => form.claim_override || collection.value?.default_claim)

function saveFlight() {
  const opts = { preserveScroll: true }
  props.flight ? form.patch(`/flights/${props.flight.id}`, opts) : form.post('/flights', opts)
}

const confirmDelete = ref(false)
function removeFlight() {
  router.delete(`/flights/${props.flight.id}`, { onFinish: () => { confirmDelete.value = false } })
}

// ── Активности ──────────────────────────────────────────────────────────
const activities = ref([...(f?.activities ?? [])])
watch(() => props.flight?.activities, (v) => { if (v) activities.value = [...v] })

// Выбор направления активности — только из СОХРАНЁННЫХ направлений флайта
const flightDirections = computed(() => (props.flight?.direction_ids ?? []).map((id) => directionsById.value[id]).filter(Boolean))

const act = ref(null)
const actErrors = ref({})
const actSaving = ref(false)
const actBlocks = computed(() => props.blocks.filter((b) => b.direction_id === act.value?.direction_id && (b.is_active || b.id === act.value?.block_id)))

function openActivity(a = null) {
  actErrors.value = {}
  act.value = a
    ? { ...a, sku_ids: [...a.sku_ids] }
    : {
        id: null, direction_id: flightDirections.value[0]?.id ?? null, block_id: null, start_date: '', end_date: '',
        platforms: '', format: '', audience_override: '', claim_override: '', materials_url: '', special_doc_url: '', comment: '', sku_ids: [],
      }
}

function actPayload() {
  const out = { ...act.value }
  delete out.id
  for (const k of Object.keys(out)) if (out[k] === '') out[k] = null
  return out
}

async function saveActivity() {
  actSaving.value = true
  actErrors.value = {}
  try {
    const { data } = act.value.id
      ? await axios.patch(`/activities/${act.value.id}`, actPayload())
      : await axios.post(`/flights/${props.flight.id}/activities`, actPayload())
    const i = activities.value.findIndex((x) => x.id === data.activity.id)
    i >= 0 ? activities.value.splice(i, 1, data.activity) : activities.value.push(data.activity)
    act.value = null
  } catch (e) {
    showActErrors(e)
  } finally {
    actSaving.value = false
  }
}

async function removeActivity() {
  if (!confirm('Удалить активность?')) return
  try {
    await axios.delete(`/activities/${act.value.id}`)
    activities.value = activities.value.filter((x) => x.id !== act.value.id)
    act.value = null
  } catch (e) {
    showActErrors(e)
  }
}

function showActErrors(e) {
  const errs = e.response?.data?.errors
  actErrors.value = errs
    ? Object.fromEntries(Object.entries(errs).map(([k, v]) => [k.replace(/\.\d+$/, ''), v[0]]))
    : { _: e.response?.data?.message || 'Не удалось сохранить.' }
}

// ── Форматирование ──────────────────────────────────────────────────────
function fmt(d) { return d ? d.split('-').reverse().join('.') : '…' }
function fmtDateTime(iso) { return iso ? new Date(iso).toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }) : '' }
function inheritHint(v) { return v ? `По умолчанию: ${v}` : 'Не задано' }
function isUrl(v) { return /^https?:\/\//.test(v || '') }

const actionLabel = { created: 'создан(а)', updated: 'изменён(а)', deleted: 'удалён(а)' }
const fieldLabel = {
  name: 'название', collection_id: 'коллекция', start_date: 'начало', end_date: 'окончание', status_id: 'статус',
  audience_override: 'ЦА', claim_override: 'клейм', brief: 'бриф', materials_url: 'материалы', comment: 'комментарий',
  direction_id: 'направление', block_id: 'блок', platforms: 'площадки', format: 'формат', special_doc_url: 'спец. документ',
}
</script>

<style scoped>
.err { font-size: 12px; color: #dc2626; margin-top: 4px; }
.hint { font-size: 11.5px; color: #9ca3af; margin-top: 3px; }
</style>
