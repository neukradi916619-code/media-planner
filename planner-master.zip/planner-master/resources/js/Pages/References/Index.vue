<template>
  <AppLayout>
    <Head title="Справочники" />

    <div class="flex items-center justify-between mb-4">
      <h1 class="text-xl font-bold text-gray-900">Справочники</h1>
      <button v-if="canEdit" class="btn-primary" @click="openForm()">+ Добавить</button>
    </div>

    <div class="flex flex-wrap gap-1 mb-4 border-b border-gray-200">
      <button v-for="t in tabs" :key="t.key" class="tab" :class="{ 'tab-on': tab === t.key }" @click="setTab(t.key)">
        {{ t.label }} <span class="text-gray-400 font-normal">{{ rows[t.key].length }}</span>
      </button>
    </div>

    <div class="flex flex-wrap items-center gap-2 mb-3">
      <input v-model="search" class="input max-w-sm" placeholder="Поиск…" />
      <select v-if="tab === 'skus' || tab === 'blocks'" v-model="parentFilter" class="filter-select">
        <option value="">{{ tab === 'skus' ? 'Все коллекции' : 'Все направления' }}</option>
        <option v-for="o in (tab === 'skus' ? collectionOptions : directionOptions)" :key="o.value" :value="o.value">{{ o.label }}</option>
      </select>
      <label class="flex items-center gap-1.5 text-sm text-gray-500" v-if="hasActive">
        <input type="checkbox" v-model="onlyActive" /> только активные
      </label>
      <span class="text-sm text-gray-400 ml-auto">{{ filtered.length }} шт.</span>
    </div>

    <div class="bg-white border border-gray-200 rounded-xl overflow-x-auto">
      <table class="w-full">
        <thead class="border-b border-gray-100">
          <tr>
            <th v-for="c in current.columns" :key="c.key" class="th">{{ c.label }}</th>
            <th class="th w-10"></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in visible" :key="row.id" class="border-b border-gray-50 hover:bg-orange-50/40"
              :class="{ 'opacity-50': row.is_active === false }">
            <td v-for="c in current.columns" :key="c.key" class="td align-top">
              <template v-if="c.type === 'color'">
                <span v-if="row[c.key]" class="inline-flex items-center gap-2">
                  <span class="w-4 h-4 rounded border border-black/10" :style="{ background: row[c.key] }"></span>
                  <span class="text-xs text-gray-400 font-mono">{{ row[c.key] }}</span>
                </span>
              </template>
              <template v-else-if="c.type === 'bool'">{{ row[c.key] ? 'Да' : 'Нет' }}</template>
              <template v-else-if="c.render">{{ c.render(row) }}</template>
              <template v-else>
                <span :class="c.key === 'name' ? 'font-medium text-gray-900' : ''">{{ row[c.key] }}</span>
              </template>
            </td>
            <td class="td text-right whitespace-nowrap">
              <button v-if="canEdit" class="text-gray-400 hover:text-orange-600" title="Изменить" @click="openForm(row)">✎</button>
            </td>
          </tr>
          <tr v-if="!filtered.length">
            <td :colspan="current.columns.length + 1" class="td text-center text-gray-400 py-8">Ничего не найдено</td>
          </tr>
        </tbody>
      </table>
      <div v-if="filtered.length > limit" class="p-3 text-center">
        <button class="btn-secondary" @click="limit += 200">Показать ещё ({{ filtered.length - limit }})</button>
      </div>
    </div>

    <!-- Форма -->
    <Teleport to="body">
      <div v-if="form" class="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" @mousedown.self="form = null">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
          <h3 class="text-lg font-bold text-gray-900 mb-4">{{ form.id ? 'Изменить' : 'Добавить' }}: {{ current.single }}</h3>
          <div class="space-y-3">
            <div v-for="f in current.fields" :key="f.key">
              <label v-if="f.type !== 'bool'" class="label">{{ f.label }}</label>
              <textarea v-if="f.type === 'textarea'" v-model="form[f.key]" rows="3" class="input"></textarea>
              <select v-else-if="f.type === 'select'" v-model="form[f.key]" class="input">
                <option v-if="!f.required" :value="null">—</option>
                <option v-for="o in f.options()" :key="o.value" :value="o.value">{{ o.label }}</option>
              </select>
              <div v-else-if="f.type === 'color'" class="flex items-center gap-2">
                <input type="color" :value="form[f.key] || '#FFFFFF'" @input="form[f.key] = $event.target.value.toUpperCase()" class="h-9 w-12 rounded border border-gray-200" />
                <input v-model="form[f.key]" class="input font-mono max-w-32" placeholder="#RRGGBB" />
                <button v-if="form[f.key]" type="button" class="text-xs text-gray-400 hover:text-gray-700" @click="form[f.key] = null">сбросить</button>
              </div>
              <label v-else-if="f.type === 'bool'" class="flex items-center gap-2 text-sm text-gray-700">
                <input type="checkbox" v-model="form[f.key]" /> {{ f.label }}
              </label>
              <input v-else v-model="form[f.key]" :type="f.type === 'number' ? 'number' : 'text'" class="input" />
              <p v-if="errors[f.key]" class="text-xs text-red-600 mt-1">{{ errors[f.key] }}</p>
            </div>
          </div>
          <p v-if="errors._" class="text-sm text-red-600 mt-3">{{ errors._ }}</p>
          <div class="flex items-center gap-3 mt-6">
            <button v-if="form.id" type="button" class="text-sm text-red-600 hover:text-red-700" @click="confirmDelete = true">Удалить</button>
            <div class="ml-auto flex gap-3">
              <button type="button" class="btn-secondary" @click="form = null">Отмена</button>
              <button type="button" class="btn-primary" :disabled="saving" @click="save">{{ saving ? 'Сохранение…' : 'Сохранить' }}</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <ConfirmDeleteModal :show="confirmDelete" :title="`Удалить: ${current.single}`" :entity-name="form?.name || ''"
      kind-label="название" :processing="saving" @confirm="remove" @cancel="confirmDelete = false" />
  </AppLayout>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { Head } from '@inertiajs/vue3'
import axios from 'axios'
import AppLayout from '@/Layouts/AppLayout.vue'
import ConfirmDeleteModal from '@/Components/ConfirmDeleteModal.vue'
import { useAuth } from '@/composables/useAuth'

const props = defineProps({
  collections: Array, skus: Array, directions: Array, blocks: Array,
  statuses: Array, contextTypes: Array, behaviors: Object,
})
const { canEdit } = useAuth()

// Локальные копии — правки применяются на месте, без перезагрузки страницы.
const rows = reactive({
  collections: [...props.collections],
  skus: [...props.skus],
  directions: [...props.directions],
  blocks: [...props.blocks],
  statuses: [...props.statuses],
  'context-types': [...props.contextTypes],
})

const byId = (list) => computed(() => Object.fromEntries(list().map((x) => [x.id, x])))
const collectionsById = byId(() => rows.collections)
const directionsById = byId(() => rows.directions)
const collectionOptions = computed(() => rows.collections.map((c) => ({ value: c.id, label: c.name })))
const directionOptions = computed(() => rows.directions.map((d) => ({ value: d.id, label: d.name })))
const behaviorOptions = () => Object.entries(props.behaviors).map(([value, label]) => ({ value, label }))

const tabs = [
  {
    key: 'collections', label: 'Коллекции', single: 'коллекция',
    columns: [
      { key: 'name', label: 'Коллекция' }, { key: 'color', label: 'Цвет', type: 'color' },
      { key: 'bm_name', label: 'БМ / контакт' }, { key: 'default_audience', label: 'ЦА по умолчанию' },
      { key: 'default_claim', label: 'Клейм по умолчанию' },
      { key: 'skus_count', label: 'SKU' }, { key: 'flights_count', label: 'Флайтов' },
    ],
    fields: [
      { key: 'name', label: 'Название' }, { key: 'color', label: 'Цвет', type: 'color' },
      { key: 'bm_name', label: 'БМ / контакт' },
      { key: 'default_audience', label: 'ЦА по умолчанию', type: 'textarea' },
      { key: 'default_claim', label: 'Клейм по умолчанию', type: 'textarea' },
      { key: 'is_active', label: 'Активна', type: 'bool', default: true },
    ],
    search: (r) => [r.name, r.bm_name],
  },
  {
    key: 'skus', label: 'SKU', single: 'SKU', parent: 'collection_id',
    columns: [
      { key: 'name', label: 'SKU (полное название)' }, { key: 'article', label: 'Артикул' },
      { key: 'collection_id', label: 'Коллекция', render: (r) => collectionsById.value[r.collection_id]?.name ?? '—' },
    ],
    fields: [
      { key: 'name', label: 'Полное название из прайс-листа', type: 'textarea' },
      { key: 'article', label: 'Артикул (по нему — картинка из indexM)' },
      { key: 'collection_id', label: 'Коллекция', type: 'select', options: () => collectionOptions.value },
      { key: 'is_active', label: 'Активен', type: 'bool', default: true },
    ],
    search: (r) => [r.name, r.article],
  },
  {
    key: 'directions', label: 'Направления', single: 'направление',
    columns: [{ key: 'sort_order', label: '№' }, { key: 'name', label: 'Направление' }, { key: 'blocks_count', label: 'Блоков' }],
    fields: [
      { key: 'name', label: 'Название' }, { key: 'sort_order', label: 'Порядок', type: 'number', default: 0 },
      { key: 'is_active', label: 'Активно', type: 'bool', default: true },
    ],
    search: (r) => [r.name],
  },
  {
    key: 'blocks', label: 'Рекламные блоки', single: 'рекламный блок', parent: 'direction_id',
    columns: [
      { key: 'direction_id', label: 'Направление', render: (r) => directionsById.value[r.direction_id]?.name ?? '—' },
      { key: 'name', label: 'Рекламный блок' },
    ],
    fields: [
      { key: 'direction_id', label: 'Направление', type: 'select', required: true, options: () => directionOptions.value },
      { key: 'name', label: 'Название' }, { key: 'sort_order', label: 'Порядок', type: 'number', default: 0 },
      { key: 'is_active', label: 'Активен', type: 'bool', default: true },
    ],
    search: (r) => [r.name, directionsById.value[r.direction_id]?.name],
  },
  {
    key: 'statuses', label: 'Статусы', single: 'статус',
    columns: [
      { key: 'name', label: 'Статус' }, { key: 'color', label: 'Цвет', type: 'color' },
      { key: 'behavior', label: 'На таймлайне', render: (r) => props.behaviors[r.behavior] },
      { key: 'description', label: 'Описание' },
    ],
    fields: [
      { key: 'name', label: 'Название' },
      { key: 'behavior', label: 'Поведение на таймлайне', type: 'select', required: true, options: behaviorOptions, default: 'normal' },
      { key: 'color', label: 'Цвет', type: 'color' }, { key: 'description', label: 'Описание' },
      { key: 'sort_order', label: 'Порядок', type: 'number', default: 0 },
    ],
    search: (r) => [r.name],
  },
  {
    key: 'context-types', label: 'Типы контекста', single: 'тип контекста',
    columns: [{ key: 'sort_order', label: '№' }, { key: 'name', label: 'Тип' }, { key: 'color', label: 'Цвет', type: 'color' }],
    fields: [
      { key: 'name', label: 'Название' }, { key: 'color', label: 'Цвет', type: 'color' },
      { key: 'sort_order', label: 'Порядок', type: 'number', default: 0 },
    ],
    search: (r) => [r.name],
  },
]

const initialTab = new URLSearchParams(window.location.search).get('tab')
const tab = ref(tabs.some((t) => t.key === initialTab) ? initialTab : 'collections')
const current = computed(() => tabs.find((t) => t.key === tab.value))
const search = ref('')
const parentFilter = ref('')
const onlyActive = ref(false)
const limit = ref(200)
const hasActive = computed(() => current.value.fields.some((f) => f.key === 'is_active'))

function setTab(key) {
  tab.value = key
  search.value = ''
  parentFilter.value = ''
  limit.value = 200
  window.history.replaceState(null, '', `?tab=${key}`)
}
watch([search, parentFilter, onlyActive], () => { limit.value = 200 })

const filtered = computed(() => {
  const q = search.value.trim().toLowerCase()
  const t = current.value
  return rows[t.key].filter((r) =>
    (!q || t.search(r).some((v) => (v ?? '').toString().toLowerCase().includes(q)))
    && (!parentFilter.value || r[t.parent] === parentFilter.value)
    && (!onlyActive.value || r.is_active !== false))
})
const visible = computed(() => filtered.value.slice(0, limit.value))

// ── Форма ────────────────────────────────────────────────────────────────
const form = ref(null)
const errors = ref({})
const saving = ref(false)
const confirmDelete = ref(false)

function openForm(row = null) {
  errors.value = {}
  const f = {}
  for (const field of current.value.fields) {
    f[field.key] = row ? row[field.key] ?? null : (field.default ?? (field.type === 'select' && field.required ? field.options()[0]?.value : null))
  }
  if (!row && current.value.parent && parentFilter.value) f[current.value.parent] = parentFilter.value
  form.value = { ...f, id: row?.id ?? null }
}

function payload() {
  const out = {}
  for (const field of current.value.fields) {
    const v = form.value[field.key]
    out[field.key] = field.type === 'bool' ? !!v : (v === '' ? null : v)
  }
  return out
}

async function save() {
  saving.value = true
  errors.value = {}
  const key = tab.value
  try {
    const { data } = form.value.id
      ? await axios.patch(`/references/${key}/${form.value.id}`, payload())
      : await axios.post(`/references/${key}`, payload())
    const list = rows[key]
    const i = list.findIndex((x) => x.id === data.item.id)
    i >= 0 ? list.splice(i, 1, data.item) : list.unshift(data.item)
    form.value = null
  } catch (e) {
    showErrors(e)
  } finally {
    saving.value = false
  }
}

async function remove() {
  saving.value = true
  const key = tab.value
  try {
    await axios.delete(`/references/${key}/${form.value.id}`)
    rows[key] = rows[key].filter((x) => x.id !== form.value.id)
    form.value = null
  } catch (e) {
    showErrors(e)
  } finally {
    saving.value = false
    confirmDelete.value = false
  }
}

function showErrors(e) {
  const errs = e.response?.data?.errors
  errors.value = errs
    ? Object.fromEntries(Object.entries(errs).map(([k, v]) => [k, v[0]]))
    : { _: e.response?.data?.message || 'Не удалось сохранить.' }
}
</script>

<style scoped>
.tab { padding: 8px 14px; font-size: 13.5px; font-weight: 500; color: #6b7280; border-bottom: 2px solid transparent; margin-bottom: -1px; }
.tab:hover { color: #1f2937; }
.tab-on { color: #c2410c; border-bottom-color: #f97316; font-weight: 600; }
</style>
