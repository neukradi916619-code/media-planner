<template>
  <div class="min-h-screen bg-gray-50 flex items-center justify-center px-4">
    <div class="w-full max-w-sm">
      <div class="text-center mb-8">
        <div class="text-4xl mb-2">📅</div>
        <div class="text-2xl font-bold text-gray-900">Planner</div>
        <div class="text-sm text-gray-400 mt-1">Справочник дизайнов упаковки</div>
      </div>

      <form @submit.prevent="submit" class="bg-white shadow rounded-xl p-6 space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <input v-model="form.login" type="text" class="input w-full" autofocus />
          <div v-if="form.errors.login" class="text-red-500 text-xs mt-1">{{ form.errors.login }}</div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Пароль</label>
          <input v-model="form.password" type="password" class="input w-full" />
        </div>
        <button type="submit" :disabled="form.processing" class="btn-primary w-full">Войти</button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3'

const form = useForm({ login: '', password: '' })

function submit() {
  form.post('/login')
}
</script>
