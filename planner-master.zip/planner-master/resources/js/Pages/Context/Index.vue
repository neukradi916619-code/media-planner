<template>
  <AppLayout>
    <Head title="Контекст" />

    <div class="flex items-center justify-between mb-4">
      <div>
        <h1 class="text-xl font-bold text-gray-900">Календарь контекста</h1>
        <p class="text-sm text-gray-400">Поводы, сезонность, события и лончи — отдельный слой над кампаниями на таймлайне.</p>
      </div>
      <button v-if="can_create" class="btn-primary" @click="openForm()">+ Добавить</button>
    </div>

    <div class="flex flex-wrap items-center gap-2 mb-3">
      <input v-model="search" class="input max-w-sm" placeholder="Поиск…" />
      <select v-model="typeFilter" class="filter-select">
        <option value="">Все типы</option>
        <option v-for="t in types" :key="t.id" :value="t.id">{{ t.name }}</option>
      </select>
      <select v-model="year" class="filter-select">
        <option value="">Все годы</option>
        <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
      </select>
      <span class="text-sm text-gray-400 ml-auto">{{ filtered.length }} шт.</span>
    </div>

    <div class="bg-white border border-gray-200 rounded-xl overflow-x-auto">
      <table class="w-full">
        <thead class="border-b border-gray-100">
          <tr><th class="th">Тип</th><th class="th">Название</th><th class="th">Период</th><th class="th">Коллекция</th><th class="th">Комментарий</th><th class="th w-10"></th></tr>
        </thead>
        <tbody>
          <tr v-for="i in filtered" :key="i.id" class="border-b border-gray-50 align-top hover:bg-orange-50/40" :class="{ 'opacity-50': !i.is_active }">
            <td class="td whitespace-nowrap">
              <span class="inline-flex items-center gap-1.5 text-xs">
                <span class="w-3 h-3 rounded-sm border border-black/10" :style="{ background: colorOf(i) }"></span>
                {{ typesById[i.context_type_id]?.name }}
              </span>
            </td>
            <td class="td font-medium text-gray-900">{{ i.name }}</td>
            <td class="td text-xs whitespace-nowrap">{{ fmt(i.start_date) }}<template v-if="i.end_date && i.end_date !== i.start_date"> — {{ fmt(i.end_date) }}</template></td>
            <td class="td text-xs">{{ collectionsById[i.collection_id]?.name }}</td>
            <td class="td text-xs text-gray-500">{{ i.comment }}</td>
            <td class="td text-right"><button v-if="i.can_edit" class="text-gray-400 hover:text-orange-600" @click="openForm(i)">✎</button></td>
          </tr>
          <tr v-if="!filtered.length"><td colspan="6" class="td text-center text-gray-400 py-8">Ничего не найдено</td></tr>
        </tbody>
      </table>
    </div>

    <Teleport to="body">
      <div v-if="form" class="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" @mousedown.self="form = null">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
          <h3 class="text-lg font-bold text-gray-900 mb-4">{{ form.id ? 'Контекст' : 'Новая запись контекста' }}</h3>
          <div class="space-y-3">
            <div>
              <label class="label">Тип</label>
              <select v-model="form.context_type_id" class="input"><option v-for="t in types" :key="t.id" :value="t.id">{{ t.name }}</option></select>
              <p v-if="errors.context_type_id" class="err">{{ errors.context_type_id }}</p>
            </div>
            <div><label class="label">Название</label><input v-model="form.name" class="input" /><p v-if="errors.name" class="err">{{ errors.name }}</p></div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="label">Дата начала</label><input v-model="form.start_date" type="date" class="input" /><p v-if="errors.start_date" class="err">{{ errors.start_date }}</p></div>
              <div><label class="label">Дата окончания</label><input v-model="form.end_date" type="date" class="input" /><p v-if="errors.end_date" class="err">{{ errors.end_date }}</p></div>
            </div>
            <div>
              <label class="label">Связанная коллекция {{ isBm ? '' : '(необязательно)' }}</label>
              <select v-model="form.collection_id" class="input">
                <option v-if="!isBm" :value="null">—</option>
                <option v-for="c in collectionOptions" :key="c.id" :value="c.id">{{ c.name }}</option>
              </select>
              <p v-if="errors.collection_id" class="err">{{ errors.collection_id }}</p>
            </div>
            <div><label class="label">Комментарий</label><textarea v-model="form.comment" rows="2" class="input"></textarea></div>
            <div>
              <label class="label">Цвет</label>
              <div class="flex items-center gap-2">
                <input type="color" :value="form.color || typesById[form.context_type_id]?.color || '#FFFFFF'" @input="form.color = $event.target.value.toUpperCase()" class="h-9 w-12 rounded border border-gray-200" />
                <span class="text-xs text-gray-400">{{ form.color ? form.color : 'цвет типа' }}</span>
                <button v-if="form.color" type="button" class="text-xs text-gray-400 hover:text-gray-700" @click="form.color = null">как у типа</button>
              </div>
            </div>
            <label class="flex items-center gap-2 text-sm text-gray-700"><input type="checkbox" v-model="form.is_active" /> Активен (показывать на таймлайне)</label>
          </div>
          <p v-if="errors._" class="text-sm text-red-600 mt-3">{{ errors._ }}</p>
          <div class="flex items-center gap-3 mt-6">
            <button v-if="form.id" type="button" class="text-sm text-red-600 hover:text-red-700" @click="remove">Удалить</button>
            <div class="ml-auto flex gap-3">
              <button type="button" class="btn-secondary" @click="form = null">Отмена</button>
              <button type="button" class="btn-primary" :disabled="saving" @click="save">Сохранить</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </AppLayout>
</template>

<script setup>
import { computed, ref } from 'vue'
import { Head } from '@inertiajs/vue3'
import axios from 'axios'
import AppLayout from '@/Layouts/AppLayout.vue'

const props = defineProps({ items: Array, types: Array, collections: Array, editable_collection_ids: Array, can_create: Boolean })

const rows = ref([...props.items])
const typesById = computed(() => Object.fromEntries(props.types.map((t) => [t.id, t])))
const collectionsById = computed(() => Object.fromEntries(props.collections.map((c) => [c.id, c])))
// null — без ограничений (редактор/админ); у БМ — только свои коллекции
const isBm = computed(() => props.editable_collection_ids !== null)
const collectionOptions = computed(() => isBm.value
  ? props.collections.filter((c) => props.editable_collection_ids.includes(c.id))
  : props.collections)

const search = ref('')
const typeFilter = ref('')
const year = ref('')
const years = computed(() => [...new Set(rows.value.map((i) => i.start_date?.slice(0, 4)).filter(Boolean))].sort())
const filtered = computed(() => {
  const q = search.value.trim().toLowerCase()
  return rows.value
    .filter((i) => !typeFilter.value || i.context_type_id === typeFilter.value)
    .filter((i) => !year.value || i.start_date <= `${year.value}-12-31` && (i.end_date || i.start_date) >= `${year.value}-01-01`)
    .filter((i) => !q || [i.name, i.comment, collectionsById.value[i.collection_id]?.name].some((v) => (v || '').toLowerCase().includes(q)))
    .sort((a, b) => a.start_date.localeCompare(b.start_date))
})

function colorOf(i) { return i.color || typesById.value[i.context_type_id]?.color || '#e5e7eb' }
function fmt(d) { return d ? d.split('-').reverse().join('.') : '' }

const form = ref(null)
const errors = ref({})
const saving = ref(false)

function openForm(i = null) {
  errors.value = {}
  form.value = i
    ? { ...i }
    : { id: null, context_type_id: props.types[0]?.id, name: '', start_date: '', end_date: '', collection_id: isBm.value ? collectionOptions.value[0]?.id ?? null : null, comment: '', color: null, is_active: true }
}

function payload() {
  const out = { ...form.value }
  delete out.id
  delete out.can_edit
  for (const k of Object.keys(out)) if (out[k] === '') out[k] = null
  return out
}

async function save() {
  saving.value = true
  errors.value = {}
  try {
    const { data } = form.value.id
      ? await axios.patch(`/context/${form.value.id}`, payload())
      : await axios.post('/context', payload())
    const i = rows.value.findIndex((x) => x.id === data.item.id)
    i >= 0 ? rows.value.splice(i, 1, data.item) : rows.value.push(data.item)
    form.value = null
  } catch (e) {
    showErrors(e)
  } finally {
    saving.value = false
  }
}

async function remove() {
  if (!confirm(`Удалить «${form.value.name}»?`)) return
  try {
    await axios.delete(`/context/${form.value.id}`)
    rows.value = rows.value.filter((x) => x.id !== form.value.id)
    form.value = null
  } catch (e) {
    showErrors(e)
  }
}

function showErrors(e) {
  const errs = e.response?.data?.errors
  errors.value = errs
    ? Object.fromEntries(Object.entries(errs).map(([k, v]) => [k, v[0]]))
    : { _: e.response?.data?.message || 'Не удалось сохранить.' }
}
</script>

<style scoped>
.err { font-size: 12px; color: #dc2626; margin-top: 4px; }
</style>
